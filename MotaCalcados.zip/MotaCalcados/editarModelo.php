<div id="c5" class="containerTab" style="display:none;background:#F5F5F5;height:50%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>

    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-75">

          <label for="cname">Modelo</label>
          <select class="form-control" name="tipoProduto" style="height:30%;width:100%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT C.CD_tipoProduto as codigo,C.NM_tipoProduto as nome
              FROM TB_tipoProduto AS C
              ";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['nome'].'</option>';
                  }       
              }  
            ?>
          </select>
        <br>
        <br>
        <label for="zip">Nova Modelo</label>
        <input type="text" id="zip" name="novotipoProduto" maxlength="30">
      </div>
      </div>

      <input type="submit" value="Atualizar" class="btn"name="btnAtualizartipoProduto" style="background:#00E676;width:50%;margin-left:25%;margin-top:5%;">

    </form>

</div>

<?php

if(isset($_POST['btnAtualizartipoProduto'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['tipoProduto'] == ""){
        $vazio = 1;
    }else if($_POST['novotipoProduto'] == ""){
      $vazio = 1;
    }
    $consulta = "SELECT NM_tipoProduto as tipoProduto FROM TB_tipoProduto WHERE NM_tipoProduto="."'".$_POST['novotipoProduto']."'";              
    $linhas=mysqli_query($conexao, $consulta);
    mysqli_num_rows($linhas);
    $dados=mysqli_fetch_array($linhas);
    $exists = $dados['tipoProduto'];
    

    if($vazio > 0){
    echo "<div class='divErro'>
    <p>Preencha todos os campos</p>
    <div id='x'>X</div>
    </div>";
    }else if($exists != ""){
    echo "<div class='divErro'>
    <p>Modelo já existente!</p>
    <div id='x'>X</div>
    </div>";     
    }else{
        $novatipoProduto = $_POST['novotipoProduto'];
        $tipoProduto = $_POST['tipoProduto'];
        
        

            
                $query = "UPDATE TB_tipoProduto SET Nm_tipoProduto='$novatipoProduto'
                where CD_tipoProduto=$tipoProduto
                ";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Modelo atualizada com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaEdicao.php' />";

                        

                    }  
            
                
            }     
            
    

   
}

?>    