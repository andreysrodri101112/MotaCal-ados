<div id="c4" class="containerTab" style="display:none;background:#F5F5F5;height:50%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>

    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-75">

          <label for="cname">Cor</label>
          <select class="form-control" name="cor" style="height:30%;width:100%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT C.CD_Cor as codigo,C.NM_Cor as nome
              FROM TB_Cor as C           
              ";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['nome'].'</option>';
                  }       
              }  
            ?>
          </select>
        <br>
        <br>
        <label for="zip">Nova Cor</label>
        <input type="text" id="zip" name="novaCor" maxlength="30">
      </div>
      </div>

      <input type="submit" value="Atualizar" class="btn"name="btnAtualizarCor" style="background:#00E676;width:50%;margin-left:25%;margin-top:5%;">

    </form>

</div>

<?php

if(isset($_POST['btnAtualizarCor'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['cor'] == ""){
        $vazio = 1;
    }else if($_POST['novaCor'] == ""){
      $vazio = 1;
    }
    $consulta = "SELECT NM_Cor as Cor FROM TB_Cor WHERE NM_Cor="."'".$_POST['novaCor']."'";              
    $linhas=mysqli_query($conexao, $consulta);
    mysqli_num_rows($linhas);
    $dados=mysqli_fetch_array($linhas);
    $exists = $dados['Cor'];
    

    if($vazio > 0){
    echo "<div class='divErro'>
    <p>Preencha todos os campos</p>
    <div id='x'>X</div>
    </div>";
    }else if($exists != ""){
    echo "<div class='divErro'>
    <p>Cor já existente!</p>
    <div id='x'>X</div>
    </div>";     
    }else{
        $novaCor = $_POST['novaCor'];
        $cor = $_POST['cor'];
        
        

            
                $query = "UPDATE TB_Cor SET Nm_Cor='$novaCor'
                where CD_Cor=$cor
                ";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Cor atualizada com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaEdicao.php' />";

                        

                    }  
            
                
            }     
            
    

   
}

?>    