<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="style/not/novaVenda.css">

</head>
<body>



  <div class="listaCarrinho">
    <table class="table table-borderless">
      <thead>
        <tr>
          <th scope="col">PRODUTO</th>
          <th scope="col">PREÇO</th>
          <th scope="col">QUANTIDADE</th>
          <th scope="col">SUBTOTAL</th>

        </tr>
      </thead>
      <tbody>

        <tr>
          <td class="produtos">TENIS COCAL AZUL/PRETO 42</th>
            <td class="produtos">99,90</td>
            <td class="produtos" class="quantidade">

              <div class="input-group-prepend">
                <button class="botoes" type="button">-</button>
                <input type="text" id="qt" value="2" >
                <button class="botoes" type="button">+</button>
              </div>
            </td>
            <td class="produtos" >199,90</td>
            <td><button class="produtos-remover">
            <img src="style/edit2.png">
            </button></td>          </tr>
          <tr>
            <td class="produtos" >TENIS COCAL AZUL/PRETO 42</th>
              <td class="produtos">99,90</td>
              <td class="produtos" class="quantidade">

                <div class="input-group-prepend">
                  <button class="botoes" type="button">-</button>
                  <input type="text" id="qt" value="2" >
                  <button class="botoes" type="button">+</button>
                </div>
              </td>
              <td class="produtos">199,90</td>
              <td><button class="produtos-remover">
              <img src="style/edit2.png">
              </button></td>
            </tr>
            <tr>
              <td class="produtos" >TENIS COCAL AZUL/PRETO 42</th>
                <td class="produtos">99,90</td>
                <td class="produtos" class="quantidade">

                  <div class="input-group-prepend">
                    <button class="botoes" type="button">-</button>
                    <input type="text" id="qt" value="2">
                    <button class="botoes" type="button">+</button>
                  </div>
                </td>
                <td class="produtos">199,90</td>
                <td><button class="produtos-remover">
                <img src="style/edit2.png">
                </button></td>        
                      </tr>

              <tr>
                <td class="produtos" >TENIS COCAL AZUL/PRETO 42</th>
                  <td class="produtos">99,90</td>

                  <td class="produtos" class="quantidade">

                    <div class="input-group-prepend">
                      <button class="botoes" type="button">-</button>
                      <input type="text" id="qt" value="2">
                      <button class="botoes" type="button">+</button>
                    </div>
                  </td>
                  <td class="produtos">199,90</td>
                  <td><button class="produtos-remover">
                  <img src="style/edit2.png">
                  </button></td>   
                  </tr>

                <tr>
                  <td class="produtos" >TENIS COCAL AZUL/PRETO 42</th>
                    <td class="produtos">99,90</td>
                    <td class="produtos" class="quantidade">

                      <div class="input-group-prepend">
                        <button class="botoes" type="button">-</button>
                        <input type="text" id="qt" value="2" >
                        <button class="botoes" type="button">+</button>
                      </div>
                    </td>
                    <td class="produtos">199,90</td>
                    <td><button class="produtos-remover">
              <img src="style/edit2.png">
              </button></td>
                  </tr>

                  <tr>
                    <td class="produtos" >TENIS COCAL AZUL/PRETO 42</th>
                      <td class="produtos">99,90</td>
                      <td class="produtos" class="quantidade">

                        <div class="input-group-prepend">
                          <button class="botoes" type="button">-</button>
                          <input type="text" id="qt" value="2">
                          <button class="botoes" type="button">+</button>
                        </div>
                      </td>
                      <td class="produtos">199,90</td>
                      <td><button class="produtos-remover">
              <img src="style/edit2.png">
              </button></td>
                    </tr>
                    <tr>
                      <td class="produtos" >TENIS COCAL AZUL/PRETO 42</th>
                        <td class="produtos">99,90</td>
                        <td class="produtos" class="quantidade">

                          <div class="input-group-prepend">
                            <button class="botoes" type="button">-</button>
                            <input type="text" id="qt" value="2" >
                            <button class="botoes" type="button">+</button>
                          </div>
                        </td>
                        <td class="produtos">199,90</td>
                        <td><button class="produtos-remover">
              <img src="style/edit2.png">
              </button></td>
                      </tr>

                    </tbody>
                  </table>
                </div>

                <div class="areaFinalizacao">

                  <form class="form-inline">
                    <div class="form-group mx-sm-3 mb-2">
                      <label for="inputPassword2" class="sr-only"></label>
                      <input type="password" class="form-control" id="inputPassword2" placeholder="Código do produto">
                    </div>
                    <button type="submit" class="btn btn-primary mb-2" style="background-color:#D32F2F !important; border-color:#D32F2F;">Adicionar</button>
                  </form>



                  <div class="card">
                    <div class="card-body">
                      <span for="" style="font-weight:bold;">Forma de Pagamento</span>
                      <section>
                        <div>
                          <input type="radio" id="control_01" name="select" value="1" checked>
                          <label for="control_01">Dinheiro</label>
                        </div>
                        <div>
                          <input type="radio" id="control_02" name="select" value="2">
                          <label for="control_02">Débito</label>
                        </div>
                        <div>
                          <input type="radio" id="control_03" name="select" value="3">
                          <label for="control_03">Crédito</label>
                        </div>
                      </section>
                      <span for="" style="font-weight:bold;">Cliente</span>
                      <select class="form-control" class="cliente" style="margin-bottom: 1rem;">
                        <option></option>
                      </select>

                        <div class="card-header" class="total"><h4>Valor Total: <span style="float:right;">R$ 199,00</span></h4></div>




                      <button type="button" class="btn btn-primary btn-lg" style="background-color:#D32F2F !important; border-color:#D32F2F;">Cancelar</button>
                      <button type="button" class="btn btn-secondary btn-lg" style="background-color:#00C853 !important; border-color:#00C853;">Finalizar</button>

                    </div>
                  </div>

              </div>



<script type="text/javascript">
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});
</script>




              </body>
              </html>
