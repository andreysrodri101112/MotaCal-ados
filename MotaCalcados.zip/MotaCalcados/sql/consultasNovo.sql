use tcc;
select * FROM TB_PRODUTO;
select * from tb_entrada;
select * from tb_REFERENCIA;
select * from tb_MARCA;
select * from tb_cor;
select * from tb_venda;
select * from tb_itemvenda;
select * from tb_cliente;
select * from tb_tipoproduto;

SELECT desc_referencia as ref FROM tb_referencia where cd_marca=1;

/*   PÁGINA VENDAS

lista vendas: hoje*/
select * from tb_venda where dt_operacao='now()';
/*lista vendas: dia especifico*/
select *,(select nm_cliente from tb_cliente where cd_cliente=tb_venda.cd_cliente) as cliente 
from tb_venda where dt_operacao='2018-08-01';
/*lista vendas: intervalo de tempo*/
select * from tb_venda where dt_operacao BETWEEN '2018-07-9' AND '2018-08-21';

/*produto dentro da venda: mais informações*/
SELECT 
tb_produto.cd_produto as codigo,
(SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
(SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
(SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
tb_produto.tm_tamanho as tamanho,
vl_venda as valor
FROM tb_produto
WHERE cd_produto=10;

SELECT qt_venda,cd_produto from tb_itemvenda where id_venda=10;



/*                PÁGINA FINANCEIRO             */

/*cores mais vendidas*/
SELECT 
(select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao = '2018-08-01'
group by cd_cor order by tot desc;



/*tamanhos mais vendidas*/
SELECT tm_tamanho as tamanho,sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao = '2018-08-01'
group by tm_tamanho order by tot desc;


/*marcas mais vendidas*/

SELECT (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao = '2018-08-01'
group by cd_marca order by tot desc;




/*trimestre: colocar intervalo de trimestres a mão*/
SELECT (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao between '2018-01-01' and '2018-03-01'
group by cd_marca order by tot desc;
												
                                                
/*ano*/
SELECT (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where YEAR(tb_venda.dt_operacao) = '2018'
group by cd_marca order by tot desc;

/*mes*/
SELECT (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where MONTH(tb_venda.dt_operacao) = '08' AND YEAR(tb_venda.dt_operacao) = '2018'
group by cd_marca order by tot desc;
										

													  
/*valor total comprado dos produtos vendidos*/															  
SELECT sum(vl_compra  * tb_itemvenda.qt_venda) as tot FROM tb_entrada
LEFT JOIN tb_itemvenda
ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao='2018-08-01';


/*valor total vendidos dos produtos vendidos*/		
SELECT sum(vl_venda) FROM tb_venda where dt_operacao='2018-08-01';


													  
/*lucro*/
SELECT (	
(SELECT sum(vl_venda) FROM tb_venda where dt_operacao='2018-08-01')
	-
(

SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
LEFT JOIN tb_itemvenda
ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao='2018-08-01'
and (select max(Qt_Compra) from tb_entrada)
order by dt_entrada desc

)
		
)	as lucro;

											  
/*total vendido: por lote(data mais antiga e maior quantidade do lote)*/                                              
SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
LEFT JOIN tb_itemvenda
ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao='2018-08-01'
and (select max(Qt_Compra) from tb_entrada)
order by dt_entrada desc;
/*ou*/
SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada,tb_itemvenda,tb_venda
WHERE
tb_venda.dt_operacao='2018-08-01'
and 
tb_entrada.cd_produto = tb_itemvenda.cd_produto
and 
tb_venda.id_venda = tb_itemvenda.id_venda
ORDER BY dt_entrada desc;
/*segundo modo de uso
 tb_entrada.dt_entrada = (
   select max(tb2.dt_entrada) from tb_entrada tb2
   where Cd_Produto = tb_entrada.Cd_Produto
   and tb2.Qt_Compra >= 1 qtcompra
);

se colocar min ele pega o valor do produto 
cadastrado na data mais antiga*/
													  

/*produtos mais vendidos*/
SELECT 
tb_produto.cd_produto as codigo,
(SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
(SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
(SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
(SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,

tb_produto.tm_tamanho as tamanho,
sum(tb_itemvenda.qt_venda) as quant, 
sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor

FROM tb_produto,tb_itemvenda,tb_venda
WHERE
tb_venda.dt_operacao = '2018-08-01'
AND
tb_venda.id_venda = tb_itemvenda.id_venda
AND
tb_produto.cd_produto = tb_itemvenda.cd_produto
group by tb_produto.cd_produto order by quant desc;

/*forma de pagamento*/
select fl_operacao as forma,sum(vl_venda) as valor from tb_venda where dt_operacao='2018-08-01' group by fl_operacao;

/*clientes que mais compram*/															  
SELECT 
(select nm_cliente from tb_cliente where cd_cliente=(tb_venda.cd_cliente)) as cliente,
sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
sum(tb_itemvenda.qt_venda) as quant FROM tb_venda,tb_itemvenda
where tb_venda.dt_operacao = '2018-08-01'
and tb_venda.id_venda = tb_itemvenda.id_venda
group by cd_cliente order by valor desc;

/*quantidade total*/
SELECT 
sum(tb_itemvenda.qt_venda) as quant FROM tb_itemvenda,tb_venda
WHERE tb_venda.dt_operacao = '2018-08-01' 
AND tb_venda.id_venda = tb_itemvenda.id_venda;


/*lista de produtos no estoque*/
SELECT 
   tb_produto.cd_produto as codigo,
   (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as ref,
   (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
   (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
   (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
   tb_produto.tm_tamanho as tamanho,
   tb_produto.fl_sexo as sexo,
   vl_venda as valor,
   qt_produto as quant
   FROM tb_produto;