<?php



  $conexao = mysqli_connect("localhost","root","","tcc");
  if (!$conexao) {
    die("Erro".mysql_error());

  }

                    $html = "";
                    $cod = $_GET['cod'];

                    $consulta = "SELECT R.CD_MARCA,R.CD_REFERENCIA as cod, R.DESC_REFERENCIA as ref
                    FROM TB_REFERENCIA AS R                    
                    WHERE CD_MARCA=$cod";
                    // echo $consulta;
                    // echo $consulta;
                    $linhas=mysqli_query($conexao, $consulta);
                    if(mysqli_affected_rows($conexao) > 0){
                      while ($dados=mysqli_fetch_array($linhas)){
                        
        $options ="<option value='".$dados['cod']."'>".$dados['ref']."</option>";
        echo $options; // com o echo, o valor da variável é o retorno da minha função ajax do tipo HTML.
        
   
       // com o echo, o valor da variável é o retorno da minha função ajax do tipo HTML.


}
}




 ?>
