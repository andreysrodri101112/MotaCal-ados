<div id="c4" class="containerTab" style="display:none;background:#F5F5F5;height:40%;">
    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
    <br>
    <br>

      <form class="" action="#" method="post">

        <div class="row">
            <div class="col-50">
              <label for="cname">Cor</label>
              <input class="form-control" name="inputCor" style="height:15%;width:100%;" maxlength="30">

            </div>
        </div>

        <input type="submit" value="Cadastrar" class="btn" name="cadastrarCor" id="btnCadastrar" >

      </form>
    </div>
<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}

if(isset($_POST['cadastrarCor'])){
    $vazio = 0;
    
    if($_POST['inputCor'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    
    }else{
        $erro = 0;
        $cor = $_POST['inputCor'];

        $consulta = "SELECT nm_cor as cor from tb_cor";
        $linhas=mysqli_query($conexao, $consulta);
        if(mysqli_num_rows($linhas) > 0){
            while ($dados=mysqli_fetch_array($linhas)){
                    if($dados['cor']==$cor){
                         $erro = 1;
                    }
            }       
        }

        if($erro == 0) {
            $query = "INSERT INTO `tb_cor`(`cd_cor`,`nm_cor`) VALUES(null,'$cor')";
                if (!mysqli_query($conexao, $query)) {
                    echo "erro ao inserir".$query."<br><br><br>";
                }else{
                    echo "<div class='divErro'>
                    <p>Cor cadastrada com sucesso</p>
                    <div id='x'>X</div>
                    </div>";
                    echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=cadastroNovo.php' />";


                    
                    
                }  
        }else{
            echo "<div class='divErro'>
        <p>Cor já existente</p>
        <div id='x'>X</div>
        </div>";
        }     
            
    }

}


?>    