<?php
session_start();


if (isset($_GET['remover']) && $_GET['remover']=="remover")  {

  $idProduto = $_GET['cod'];
  unset($_SESSION['itens'][$idProduto]);


echo "<meta HTTP-EQUIV='REFRESH' CONTENT='0;url=pedido.php' />";


}else {
  echo "nao bate";
}

 ?>
