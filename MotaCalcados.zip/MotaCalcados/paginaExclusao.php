
<?php

session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="adm") {
    $sessao = "Administrador";
  }elseif ($_SESSION['username']=="func") {
    header("Location: listagemfuncionario.php");
  }
  // echo $sessao;
}else {
  header("Location: index.php");
}


if (isset($_POST['logout'])) {
  header("Location:index.php");
}
?>

<!DOCTYPE html>

<html>
<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style/not/exclusao.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="js/bootstrap-datepicker.js"></script>
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />
  

</head>
<body>



  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Mota Calçados</a>
      </div>
      <ul class="nav navbar-nav">
              <li><a href="cadastroNovo.php">Cadastro</a></li>
              <li ><a href="listagem.php">Estoque</a></li>
              <li><a href="vendas.php">Vendas</a></li>
              <li ><a href="financeiro.php">Financeiro</a></li>
              <li class="position"><div class="dropdown">
                <button  class="dropbtn" style="background:none;color:black;">Configurações</button>
                <div id="myDropdown1" class="dropdown-content">
                  <a href="paginaEdicao.php">Editar</a>
                  <a href="paginaExclusao.php">Excluir</a>                  
                </div>
             
            </li>
      </ul>

      <style media="screen">

      </style>

      <div class="dropdown" style="mar:right;">
        <?php
        echo "<button class='dropbtn'>$sessao</button>";
        ?>
        <div class="dropdown-content">
          <a href="logout.php">Sair</a>

        </div>
      </div>

    </nav>







<form class="data" action="#" method="post">
  <label for="">Escolha o que você deseja excluir:</label>
  <select id="op" onchange="editar()" class="form-control" name="mes" style="width:10%;">
    <option value=""></option>
    <option value="c1">Entrada</option>
    <option value="c2">Referencia</option>
    <option value="c3">Marca</option>
    <option value="c4">Cor</option>
    <option value="c5">Modelo</option>
    <option value="c6">Cliente</option>
    <option value="c7">Produto</option>
  </select>  
</form>

<?php
include_once('opExcluir.php');
?>


<script type="text/javascript">

function editar() {
  var i, x,y;


  var x = document.getElementById("op");
  Array.from(document.getElementsByClassName("containerTab")).forEach(elemento => elemento.style.display = "none");
  var container = document.getElementById(x.value);
  container.style.display = "block";
}
</script>

    <script type="text/javascript">
    if ( $( ".divErro" ).is( ":hidden" ) ) {
      $( ".divErro" ).slideDown(1000);
    }
    else {
      $( "#divErro" ).hide();
    }



    $('#x').click(function(){
      if ( $(".divErro").slideUp(1000)) {

      }
      return true;
    });
    </script>
    
</body>
</html>






</body>
</html>
