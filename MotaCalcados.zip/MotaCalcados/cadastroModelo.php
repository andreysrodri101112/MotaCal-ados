<div id="c5" class="containerTab" style="display:none;background:#F5F5F5;height:40%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <br>
  <br>

    <form class="" action="#" method="post">

      <div class="row">
          <div class="col-50">
            <label for="cname">Modelo</label>
            <input class="form-control" name="inputModelo" style="height:15%;width:100%;" maxlength="30">
      </div>
      </div>

      <input type="submit" value="Cadastrar" class="btn" name="cadastrarmodelo" id="btnCadastrar"/>

    </form>

</div>
<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}

if(isset($_POST['cadastrarmodelo'])){
    $vazio = 0;
    
    if($_POST['inputModelo'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";   
    }else{
        $erro = 0;
        $modelo = $_POST['inputModelo'];

            $consulta = "SELECT nm_tipoProduto as tipoProduto from tb_tipoProduto";
            $linhas=mysqli_query($conexao, $consulta);
            if(mysqli_num_rows($linhas) > 0){
                while ($dados=mysqli_fetch_array($linhas)){
                        if($dados['tipoProduto']==$modelo){
                            $erro = 1;
                        }
                }       
            }

            if($erro == 0) {
                $query = "INSERT INTO `tb_tipoProduto`(`cd_tipoProduto`,`nm_tipoProduto`) VALUES(null,'$modelo')";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao inserir".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Modelo cadastrado com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=cadastroNovo.php' />";

                    }  
            }else{
                
                echo "<div class='divErro'>
                <p>Modelo já existente</p>
                <div id='x'>X</div>
                </div>";   
            }     
        }          
    

}


?>    