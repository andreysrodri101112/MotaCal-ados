
<div id="c4" class="containerTab" >
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>

  <form class="" action="#" method="post">

    <div class="row">
      <div class="col-50">

        <label for="cname">Cor</label>
        <select class="form-control" name="cor" style="height:50%;">
          <option value=""></option>
          <?php
              $consulta = "SELECT C.CD_COR AS codigo,C.NM_COR as nome 
              FROM TB_COR AS C
              WHERE NOT EXISTS(SELECT CD_COR FROM TB_PRODUTO AS P WHERE P.CD_COR = C.CD_COR)";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['nome'].'</option>';
                  }       
              }  
            ?>  
        </select>
      <br>
      <br>
 
    </div>
    </div>

    <input type="submit" value="Excluir" class="btn" name="btnExcluirCor" id="excluir">

  </form>

</div>

<?php



if(isset($_POST['btnExcluirCor'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['cor'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['cor'];
        
        

            
                $query = "DELETE FROM tb_cor where cd_cor=$codigo";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Cor excluída com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaExclusao.php' />";

                    }  
            
                
            }     
            
    

   
}

?>    