
SELECT * FROM TB_PRODUTO;
select * from tb_entrada;
select * from tb_REFERENCIA;
select * from tb_MARCA;
select * from tb_cor;
select * from tb_venda;
select * from tb_itemvenda;
select * from tb_cliente;
select * from tb_tipoproduto;

/*
Pagina vendas

lista vendas: hoje*/
select * from tb_venda where dt_operacao='now()';
/*lista vendas: dia especifico*/
select * from tb_venda where dt_operacao='2018-08-22';
/*lista vendas: intervalo de tempo*/
select * from tb_venda where dt_operacao BETWEEN '2018-07-9' AND '2018-08-21';

/*produto dentro da venda: mais informações*/
select qt_venda,cd_produto from tb_itemvenda where id_venda=18;
select * from tb_produto where cd_produto=10; 

/*Pagina financeiro*/


/*cores mais vendidas
hoje*/
SELECT (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao = now()
group by cd_cor order by tot desc;

/*dia especifico*/
SELECT (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao = '2018-02-02'
group by cd_cor order by tot desc;
/*intervalo de tempo*/
SELECT (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao between  '2018-02-02' and '2018-08-01'
group by cd_cor order by tot desc;

/*marcas mais vendidas
hoje*/
SELECT (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao = now()
group by cd_marca order by tot desc;
/*dia especifico*/
SELECT (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao = '2018-02-02'
group by cd_marca order by tot desc;
/*intervalo de tempo*/
SELECT (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)),sum(tb_itemvenda.qt_venda) as tot FROM tb_produto
LEFT JOIN tb_itemvenda
ON tb_produto.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao between '2018-02-02' and '2018-08-01'
group by cd_marca order by tot desc;
												

/*fazer iguais para os outros*/
													  
select* from tb_entrada;
select* from tb_itemvenda;
													  
/*valor total comprado dos produtos vendidos*/															  
SELECT sum(vl_compra  * tb_itemvenda.qt_venda) as tot FROM tb_entrada
LEFT JOIN tb_itemvenda
ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao='2018-08-01';

/*valor total vendidos dos produtos vendidos*/		
SELECT sum(vl_venda) FROM tb_venda where dt_operacao='2018-08-01';
													  
/*lucro*/

SELECT (	
(SELECT sum(vl_venda) FROM tb_venda where dt_operacao='2018-08-01')
	-
(

SELECT (vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
LEFT JOIN tb_itemvenda
ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao='2018-08-01'
and tb_entrada.dt_entrada = (
   select min(tb2.dt_entrada) from tb_entrada tb2
   where Cd_Produto = tb_entrada.Cd_Produto
   and tb2.Qt_Compra >= 5 /*qtcompra*/
)
)
		
)	as lucro;


select * from tb_entrada;
select * from tb_produto;
select * from tb_itemvenda;
											  
/*valor da data mais antiga para calculo do lucro*/                                              
SELECT (vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
LEFT JOIN tb_itemvenda
ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
LEFT JOIN tb_venda
ON tb_venda.id_venda = tb_itemvenda.id_venda
where tb_venda.dt_operacao='2018-08-01'
and tb_entrada.dt_entrada = (
   select max(tb2.dt_entrada) from tb_entrada tb2
   where Cd_Produto = tb_entrada.Cd_Produto
   and tb2.Qt_Compra >= 5 /*qtcompra*/
);
													  
												
