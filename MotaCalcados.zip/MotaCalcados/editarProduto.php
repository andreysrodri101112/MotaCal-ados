<div id="c7" class="containerTab" style="display:none;background:#F5F5F5;height:70%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  
  <br>
  <br>


        <form action="#" method="post">

          <div class="row">
            <div class="col-50">
              <label for="fname">Código</label>
              <select class="form-control" name="codigoProduto" style="height:75%;">
                <option value=""></option>
                <?php
                  $consulta = "SELECT cd_produto AS codigo FROM TB_PRODUTO";
                  $linhas=mysqli_query($conexao, $consulta);
                  if(mysqli_num_rows($linhas) > 0){
                      while ($dados=mysqli_fetch_array($linhas)){
                        echo '<option value="'.$dados['codigo'].'">'.$dados['codigo'].'</option>';
                      }       
                    }  
                   ?>
              </select>
            </div>
            <div class="col-50">
              <label for="fname">Cor</label>
              <select class="form-control" name="corProduto" style="height:75%;">
                <option value=""></option>
                <?php
                  $consulta = "SELECT cd_cor AS codigo, nm_cor as cor FROM TB_Cor";
                  $linhas=mysqli_query($conexao, $consulta);
                  if(mysqli_num_rows($linhas) > 0){
                      while ($dados=mysqli_fetch_array($linhas)){
                        echo '<option value="'.$dados['codigo'].'">'.$dados['cor'].'</option>';
                      }       
                    }  
                   ?>
              </select>
            </div>
          </div>
          <br>
          
          <div class="row">
              <div class="col-50">
                <label for="cname">Marca</label>
                  <select class="form-control" name="marcaProduto" id="marcaProduto" style="height:75%;" >
                    <option value=""></option>
                    <?php
                      $consulta = "SELECT cd_marca AS codigo, nm_marca AS marca FROM tb_marca";
                      $linhas=mysqli_query($conexao, $consulta);
                      if(mysqli_num_rows($linhas) > 0){
                      while ($dados=mysqli_fetch_array($linhas)){
                        echo '<option value="'.$dados['codigo'].'">'.$dados['marca'].'</option>';
                      }       
                    }  
                   ?>
                  </select>
              </div>  
              <div class="col-50">
                <label for="cname">Referência</label>
                  <select class="form-control" name="referenciaProduto" id="refProduto" style="height:75%;">
                    <option value=""></option>
                    </select>
                    <script type="text/javascript">
                                $('#marcaProduto').on("change",function(){
                                    var codigo = $('#marcaProduto').val();
                                    
                                            
                                            $.ajax({    
                                            type: "GET", //método escolhido
                                            url: "busca_todasReferencia.php?cod="+codigo, //arquivo php chamado                        
                                            dataType: "html",//tipo de função a ser retornada
                                                beforeSend: function(){
                                                    $("#bt").text("Carregando...");
                                                },
                                                error: function(){
                                                    $("#ref").html("Erro ao carregar HTML! Tente de novo!");
                                                },
                                                success: function(html){
                                                    $("#refProduto").html(html);
                                                    
                                                    
                                                }
                                            });

                                });
                </script>
              </div>  
            </div> 
            <br>
            <div class="row">
                <div class="col-50">
                  <label for="state">Tamanho</label>
                  <input type="text" id="state" name="tamanhoProduto" style="height:50%;" maxlength="2">
                </div>
                <div class="col-50">
                  <label for="zip">Valor</label>
                  <input type="text" id="zip" name="valorProduto" style="height:50%;" maxlength="6">
                </div>
            </div>
            
            
            <div class="row">
              <div class="col-50">
                <label for="cname">Modelo</label>
                  <select class="form-control" name="modeloProduto" style="height:75%;">
                    <option value=""></option>
                    <?php
                      $consulta = "SELECT cd_tipoProduto AS codigo, nm_tipoProduto AS tipo FROM tb_tipoProduto";
                      $linhas=mysqli_query($conexao, $consulta);
                      if(mysqli_num_rows($linhas) > 0){
                      while ($dados=mysqli_fetch_array($linhas)){
                        echo '<option value="'.$dados['codigo'].'">'.$dados['tipo'].'</option>';
                      }       
                    }  
                   ?>
                  </select>
              </div>  
              <div class="col-50">
                <label for="cname">Sexo</label>
                  <select class="form-control" name="sexoProduto" style="height:75%;">
                    <option value=""></option>
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                  </select>
              </div>  
            </div> 
            <br>

          <input type="submit" value="Atualizar" class="btn" name="btnAtualizarProduto" style="background:#00E676;width:50%;margin-left:25%;margin-top:5%;">

    </form>
</div>

<?php

if(isset($_POST['btnAtualizarProduto'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['codigoProduto'] == ""){
        $vazio = 1;
    }else if($_POST['corProduto'] == ""){
        $vazio = 1;
    }else if($_POST['marcaProduto'] == ""){
      $vazio = 1;
    }else if($_POST['referenciaProduto'] == ""){
      $vazio = 1;
    }else if($_POST['tamanhoProduto'] == ""){
      $vazio = 1;
    }else if($_POST['valorProduto'] == ""){
      $vazio = 1;
    }else if($_POST['modeloProduto'] == ""){
      $vazio = 1;
    }else if($_POST['sexoProduto'] == ""){
      $vazio = 1;
    }

    if($vazio > 0){
    echo "<div class='divErro'>
    <p>Preencha todos os campos</p>
    <div id='x'>X</div>
    </div>";
    }else{
    $codigo  = $_POST['codigoProduto'];
    $cor     = $_POST['corProduto'];
    $marca   = $_POST['marcaProduto'];
    $ref     = $_POST['referenciaProduto'];
    $tamanho = $_POST['tamanhoProduto'];
    $valor   = $_POST['valorProduto'];
    $modelo  = $_POST['modeloProduto'];
    $sexo    = $_POST['sexoProduto'];
      
            
                $query = "UPDATE TB_PRODUTO SET cd_marca=$marca,cd_referencia=$ref,
                tm_tamanho=$tamanho,vl_venda='$valor',fl_sexo='$sexo',cd_tipoProduto='$modelo'
                ,cd_cor=$cor
                where cd_produto=$codigo
                ";
                
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Produto atualizado com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaEdicao.php' />";

                        

                    }  
            
                
            }     
            
    

   
}

?>    