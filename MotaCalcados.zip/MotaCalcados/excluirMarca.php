
<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}
?>
<div id="c3" class="containerTab" >
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>

    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-50">

          <label for="cname">Marca</label>
          <select class="form-control" name="marca" style="height:50%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT C.CD_MARCA AS codigo,C.NM_MARCA as nome 
              FROM TB_MARCA AS C
              WHERE NOT EXISTS(SELECT CD_MARCA FROM TB_PRODUTO AS P WHERE P.CD_MARCA = C.CD_MARCA)
              AND
              WHERE NOT EXISTS(SELECT CD_MARCA FROM TB_REFERENCIA AS R WHERE R.CD_MARCA = C.CD_MARCA)
              ";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['nome'].'</option>';
                  }       
              }  
            ?>

          </select>
        <br>
        <br>
        
      </div>
      </div>

      <input type="submit" value="Excluir" class="btn" name="btnExcluirMarca" id="excluir">

    </form>

</div>

<?php



if(isset($_POST['btnExcluirMarca'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['marca'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['marca'];
        
        

            
                $query = "DELETE FROM tb_marca where cd_marca=$codigo";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Marca excluída com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaExclusao.php' />";

                    }  
            
                
            }     
            
    

   
}

?>    