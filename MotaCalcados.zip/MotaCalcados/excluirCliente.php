<div id="c6" class="containerTab" >
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
    <form class="" action="#" method="post">

      <div class="row">
          <div class="col-50">
            <label for="cname">Cliente</label>
            <select class="form-control" name="cliente" style="height:75%;">
              <option value=""></option>
              <?php
              $consulta = "SELECT C.CD_CLIENTE AS codigo,C.NM_CLIENTE AS cliente,C.CPF AS cpf
              FROM TB_CLIENTE AS C
              WHERE NOT EXISTS(SELECT CD_CLIENTE FROM TB_VENDA AS V WHERE V.CD_CLIENTE = C.CD_CLIENTE);";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['cliente'].' - '.$dados['cpf'].'</option>';
                  }       
                }  
              ?>               
             </select>
          </div>

      </div>

        <input type="submit" value="Excluir" class="btn" name="btnExcluirCliente" id="excluir">

  </form>
</div>
</div>

<?php



if(isset($_POST['btnExcluirCliente'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['cliente'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['cliente'];
        
        

            
                $query = "DELETE FROM tb_cliente where cd_cliente=$codigo";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Cliente excluída com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaExclusao.php' />";

                    }  
            
                
            }     
            
    

   
}

?>    