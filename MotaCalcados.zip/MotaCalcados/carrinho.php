<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}



session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="adm") {
    header("Location: index.php");
  }
}

   

$totalvenda=0;



// unset($_SESSION['itens']);

      if (!isset($_SESSION['itens'])) {
        $_SESSION['itens'] = array();
      }

    if (isset($_POST['add'])){

      if($_POST['cod']==""){
        echo "<div class='divErro'>
        <p>Campo vazio. Insira um codigo de produto existente!</p>
        <div id='x'>X</div>
        </div>";
      }else{



      $consulta1 = "SELECT cd_produto as cod from tb_produto where cd_produto=". $_POST['cod'];
      $linhas1=mysqli_query($conexao, $consulta1);
      mysqli_num_rows($linhas1);
      $dados1=mysqli_fetch_array($linhas1);
      $cd = $dados1['cod'];
      if ($cd == "") {
        echo "<div class='divErro'>
        <p>Produto Inexistente</p>
        <div id='x'>X</div>
        </div>";     
      }else{


    
      //Adiciona no carrinho
      $idProduto = $_POST['cod'];

      $consulta = "SELECT qt_produto as quant from tb_produto where cd_produto=".$idProduto;
      $linhas=mysqli_query($conexao, $consulta);
      mysqli_num_rows($linhas);
      $dados=mysqli_fetch_array($linhas);
      $estoque = $dados['quant'];
      


      if (!isset($_SESSION['itens'][$idProduto])){
            if ($estoque > 0){
                $_SESSION['itens'][$idProduto] = 1;
                }else{
                    echo "<div class='divErro'>
                    <p>Produto Indisponível</p>
                    <div id='x'>X</div>
                    </div>";     
            }
      }else{
        echo "<div class='divErro'>
        <p>Produto ja inserido no carrinho de compras</p>
        <div id='x'>X</div>
        </div>";     
      }
    }
  }  
} 

echo '
  <div class="listaCarrinho">
    <table class="table table-borderless">
      <thead>
        <tr>
          <th scope="col">CÓDIGO</th>
          <th scope="col">DESCRIÇÃO</th>
          <th scope="col">PREÇO</th>
          <th scope="col">QUANTIDADE</th>
          <th scope="col">SUBTOTAL</th>

        </tr>
      </thead>
      <tbody>          
    ';


    


                               

  if (count($_SESSION['itens']) == 0) {
    echo '<div class="vazio">Carrinho Vazio.</div>';
  }else{

    $_SESSION['dados'] = array();



         
  
  
    if (isset($_POST['mais'])) {
  
      $consulta = "SELECT qt_produto as quant from tb_produto where cd_produto=".$_POST['cd'];
          $linhas=mysqli_query($conexao, $consulta);
          mysqli_num_rows($linhas);
          $dados=mysqli_fetch_array($linhas);
          $estoque = $dados['quant'];

      if ($_SESSION['itens'][$_POST['cd']] < $estoque) {
        $_SESSION['itens'][$_POST['cd']] += 1;       

      }else{
        echo "<div class='divErro'>
        <p>Número máximo de produtos disponivis em estoque</p>
        <div id='x'>X</div>
        </div>";     
      }              
      
    
    }
    if (isset($_POST['menos'])) {
        if ( $_SESSION['itens'][$_POST['cd']] > 0) {
          $_SESSION['itens'][$_POST['cd']] -= 1; 
                                           
        }else{
          echo "<div class='divErro'>
          <p>Quantidade não permitida</p> 
          <div id='x'>X</div>
          </div>";     
        $_SESSION['itens'][$_POST['cd']] = 0; 
        } 
    }
    


  foreach($_SESSION['itens'] as $idProduto =>$quantidade) {

  

    $conexao = new PDO('mysql:host=localhost;dbname=tcc',"root","");
          $select = $conexao->prepare("SELECT 
          tb_produto.cd_produto as codigo,
          (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
          (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
          (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
          (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
          
          tb_produto.tm_tamanho as tamanho,
          tb_produto.vl_venda as valor
          
          FROM tb_produto
          WHERE tb_produto.cd_produto=?");

          $select-> bindParam(1,$idProduto);
          $select->execute();
          $produtos = $select->fetchAll();
          
          $total = $quantidade * $produtos[0]["valor"];

          echo '
            <tr>
            <td class="produtos">'.$idProduto.'</td>
            <td class="produtos">'.$produtos[0]["modelo"].' '.$produtos[0]["marca"].' '.$produtos[0]["cor"].' '.$produtos[0]["tamanho"].'</th>
              <td class="produtos">'.$produtos[0]["valor"].'</td>
              <td class="produtos" class="quantidade">

                <div class="input-group-prepend">


                  <form action="#" method="post">                    
                    <button class="botoes" type="submit" id="menos" name="menos">-</button>
                    <input type="hidden" name="cd" value='.$idProduto.'>
                  </form>
                  <input type="text" id="qt" name="quant" value="'.$quantidade.'" >
                  <form action="#" method="post">
                    <button class="botoes" type="submit" id="mais" name="mais">+</button>
                    <input type="hidden" name="cd" value='.$idProduto.'>
                  </form>


                </div>
              </td>
              <td class="produtos" >'.number_format($total,2,",",".").'</td>
              
              <td>
              <a href="remover.php?remover=remover&cod='.$idProduto.'"><button class="produtos-remover">
              <img src="style/not/edit2.png">
              </button></a>
              </td>          

          </tr>';

              $totalvenda = $totalvenda + $total;

              date_default_timezone_set('America/Sao_paulo');
              $dataHora = date('Y-m-d H:i:s');
              $data = date('Y-m-d');
               
              if (isset($_POST['finalizar'])) {
                array_push(
                  $_SESSION['dados'],
                  array(
                    'codigo' => $idProduto,                
                    'quantidade' => $quantidade,
                    'valor' => $produtos[0]["valor"],                
                    'data' => $dataHora,
                    'subtotal' => $total,                
    
                  )
                );
    
              }             
              
          
    }

  }



                    
                    echo '
                    </tbody>
                  </table>
                </div>

                <div class="areaFinalizacao">

                  <form class="form-inline" method="post" action="#">
                    <div class="form-group mx-sm-3 mb-2">
                      <label  class="sr-only"></label>
                      <input type="text" class="form-control" name="cod" autocomplete="off" placeholder="Código do produto">
                    </div>
                    <button type="submit" name="add" class="btn btn-primary mb-2" id="add" style="background-color:#D32F2F !important; border-color:#D32F2F;">Adicionar</button>
                  </form>


                <form method="post" action="#">
                  <div class="card">
                    <div class="card-body">
                      <span for="" style="font-weight:bold;">Forma de Pagamento</span>
                      <section>
                        <div>
                          <input type="radio" id="control_01" name="pagamento" value="di" checked>
                          <label for="control_01">Dinheiro</label>
                        </div>
                        <div>
                          <input type="radio" id="control_02" name="pagamento" value="cd">
                          <label for="control_02">Débito</label>
                        </div>
                        <div>
                          <input type="radio" id="control_03" name="pagamento" value="cc" id="cc">
                          <label for="control_03">Crédito</label>
                                  
                        </div>
                                                
                        
                        
                        
                      </section>
                      
                      <span for="" style="font-weight:bold;">Cliente</span>
                      <select class="form-control" class="cliente" name="cliente" style="margin-bottom: 1rem;">                        
                        <option value=""></option>
                        ';
                        $conexao = mysqli_connect("localhost","root","","tcc");
                          if (!$conexao) {
                            die("Erro".mysql_error());

                          }
                        $consulta = "SELECT nm_cliente as cliente, cd_cliente as codigo FROM tb_cliente";
                            $linhas=mysqli_query($conexao, $consulta);                            
                            if(mysqli_num_rows($linhas) > 0){                              
                                while ($dados=mysqli_fetch_array($linhas)){
                                  echo '<option value="'.$dados['codigo'].'">'.$dados['cliente'].'</option>';
                                }       
                            } 
                      echo '      
                      </select>   

                      <div class="card-header" class="total"><h4>Valor Total: <span style="float:right;">'.number_format($totalvenda,2,",",".").'</span></h4></div>';
                            

                       echo '<button type="submit" name="cancelar" class="btn btn-primary btn-lg" style="background-color:#D32F2F !important; border-color:#D32F2F;">Cancelar</button>';
                       echo '<button type="submit" name="finalizar" class="btn btn-secondary btn-lg" style="background-color:#00C853 !important; border-color:#00C853;">Finalizar</button>';
                          echo '    
                          </div>
                      </div>
                </form>  
            </div>
           '; 




                  
        if (isset($_POST['cancelar'])) {            
            unset($_SESSION['itens']);
            unset($_SESSION['dados']);
            echo '<script>window.location = "listagemFuncionario.php";</script>';
          }
        

        

        // </div>
        // <select class="form-control" id="vezes" name="pagamento" >                        
        //     <option value="">Crédito</option>
        //     <option value="1x">1x</option>
        //     <option value="2x">2x</option>
        //     <option value="3x">3x</option>
        //     <option value="4x">4x</option>
        //     <option value="5x">5x</option>
        //     <option value="6x">6x</option>                        
        //     <option value="7x">7x</option>
        //     <option value="8x">8x</option>
        //     <option value="9x">9x</option>
        //     <option value="10x">10x</option>
        //     <option value="11x">11x</option>
        //     <option value="12x">12x</option>
        // </select>  

        if (isset($_POST['finalizar'])) {          
          $fc = 0;
          $erro = 0;
   

                   
                    if(!isset($_SESSION['dados'])){
                      $erro = 2;
                    }

             if($erro == 2){
                echo "<div class='divErro'>
                <p>Não é possivil finalizar a venda sem produtos no carrinho.</p>
                <div id='x'>X</div>
                </div>";          
              } else{

                $pagamento = $_POST['pagamento'];
                $cliente   = $_POST['cliente'];
                        
                  if($cliente != ""){
                  
                    $insertvenda = "INSERT INTO tb_venda(`cd_cliente`,`fl_operacao`,`dt_operacao`) VALUES ('$cliente','$pagamento','$dataHora')";
                      if(!mysqli_query($conexao, $insertvenda)) {
                        echo "erro insert vendas. code: | ".mysqli_errno($conexao)." |";
                        $fc = 0;
                      }else{
                        $fc += 1;
                        echo $insertvenda;
                      }


                  }else{

                    $insertvenda = "INSERT INTO tb_venda(`fl_operacao`,`dt_operacao`) VALUES ('$pagamento','$dataHora')";
                      if(!mysqli_query($conexao, $insertvenda)) {
                        echo "erro insert vendas. code: | ".mysqli_errno($conexao)." |";
                        $fc = 0;
                      }else{
                        $fc += 1;
                        
                      }
                  }
                  
                  $consulta = "SELECT id_venda from tb_venda ORDER BY id_venda DESC LIMIT 1";
                  $linhas=mysqli_query($conexao, $consulta);
                  mysqli_num_rows($linhas);
                  $dados=mysqli_fetch_array($linhas);
                  $idVenda = $dados['id_venda'];  

              foreach ($_SESSION['dados'] as $produtos) {
                  $insert = "INSERT INTO tb_itemVenda(`id_venda`,`cd_produto`,`qt_venda`,`vl_item`) VALUES ('$idVenda',".$produtos['codigo'].",".$produtos['quantidade'].",".$produtos['valor'].")";
                    if(!mysqli_query($conexao, $insert)) {
                      echo "erro insert item venda. code: | ".mysqli_errno($conexao)." |";
                      $fc = 0;

                    }else{
                      $fc += 1;
                    }
              }
              
              echo $fc;

              if($fc > 0){             
        
              unset($_SESSION['itens']);
              unset($_SESSION['dados']);
              echo '<script>window.location = "listagemFuncionario.php";</script>';

              }
          }
        }    
?>

