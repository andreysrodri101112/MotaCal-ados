

<div id="c7" class="containerTab" style="display:none;background:#F5F5F5;">
    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
    <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
    <br>
    <br>


          <form action="#" method="post">

             <div class="row">
                    <div class="col-50">
                            <label >Código</label>
                            <input type="text" id="fname" name="codigo" >
                    </div>        
                    <div class="col-50">
                        <label >Cor</label>
                        <select class="form-control" name="cor" style="height:9.5%;">
                        <option value=""></option>
                        <?php
                            $consulta = "SELECT cd_cor,nm_cor from tb_cor";
                            $linhas=mysqli_query($conexao, $consulta);
                            if(mysqli_num_rows($linhas) > 0){
                                while ($dados=mysqli_fetch_array($linhas)){
                                    echo '<option value="'.$dados['cd_cor'].'">'.$dados['nm_cor'].'</option>';
                                }       
                            }  
                        ?>
                        </select>
                    </div>
            </div>

                <div class="row">
                    <div class="col-50">
                        <label >Marca</label>
                        <select class="form-control" name="marca" id="marca" style="height:9.5%;">
                        <option value=""></option>
                        <?php
                            $consulta = "SELECT cd_marca,nm_marca from tb_marca";
                            $linhas=mysqli_query($conexao, $consulta);
                            if(mysqli_num_rows($linhas) > 0){
                                while ($dados=mysqli_fetch_array($linhas)){
                                    echo '<option value="'.$dados['cd_marca'].'">'.$dados['nm_marca'].'</option>';
                                }       
                            }  
                        ?>
                        </select>
                    </div> 

                    <div class="col-50">            
                        <label >Referencia</label>
                        <select class="form-control" name="ref" id="ref" style="height:9.5%;"></select>
                            <script type="text/javascript">
                                $('#marca').on("change",function(){
                                    var cd_marca = $('#marca').val();                        
                                            $.ajax({
                                            type: "GET", //método escolhido
                                            url: "busca_todasReferencia.php?cod="+cd_marca, //arquivo php chamado                        
                                            dataType: "html",//tipo de função a ser retornada
                                                beforeSend: function(){
                                                    $("#bt").text("Carregando...");
                                                },
                                                error: function(){
                                                    $("#ref").html("Erro ao carregar HTML! Tente de novo!");
                                                },
                                                success: function(html){
                                                    $("#ref").html(html);

                                                }
                                            });

                                });
                            </script>        
                    </div>
                </div>       




                <div class="row">
                <div class="col-50">             
                        <label >Tamanho</label>
                        <input type="text" id="zip" name="tamanho" maxlength="2">
                    </div>
                    <div class="col-50">             
                        <label >Valor</label>
                        <input type="text" id="zip" name="valor" maxlength="6">
                    </div>
                </div>


             


                <div class="row">
                    <div class="col-50">             
                        <label >Tipo</label>
                        <select class="form-control" name="modelo" style="height:9.5%;">
                        <option value=""></option>
                        <?php
                            $consulta = "SELECT cd_tipoproduto,nm_tipoproduto from tb_tipoproduto";
                            $linhas=mysqli_query($conexao, $consulta);
                            if(mysqli_num_rows($linhas) > 0){
                                while ($dados=mysqli_fetch_array($linhas)){
                                    echo '<option value="'.$dados['cd_tipoproduto'].'">'.$dados['nm_tipoproduto'].'</option>';
                                }       
                            }  
                            ?>
                        </select>
                    </div>
                    <div class="col-50">            
                         <label >Sexo</label>
                            <select class="form-control" name="sexo" style="height:9.5%;">
                                <option value=""></option>
                                <option value="M">Masculino</option>
                                <option value="F">Feminino</option>                  
                            </select>           
                    </div>     
                </div>


                
                


            

            <input type="submit" value="Cadastrar" class="btn" name="cadastrarProduto" id="btnCadastrar">

          </div>
          </form>
  </div>

<?php



if(isset($_POST['cadastrarProduto'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['codigo'] == ""){
        $vazio = 1;
    }else if($_POST['marca'] == ""){
        $vazio = 1;
    }else if($_POST['ref'] == ""){
        $vazio = 1;
    }else if($_POST['valor'] == ""){
        $vazio = 1;
    }else if($_POST['cor'] == ""){
        $vazio = 1;
    }else if($_POST['sexo'] == ""){
        $vazio = 1;
    }else if($_POST['modelo'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['codigo'];
        $marca = $_POST['marca'];
        $ref = $_POST['ref'];        
        $tm = $_POST['tamanho'];
        $cor = $_POST['cor'];
        $mdl = $_POST['modelo'];
        $vl = $_POST['valor'];
        $sx = $_POST['sexo'];


            $consulta = "SELECT cd_produto from tb_produto WHERE cd_produto=".$codigo;
            $linhas=mysqli_query($conexao, $consulta);
            if(mysqli_num_rows($linhas) > 0){
                $erro = 1;
            }else{
                $erro = 0;
            }

            if($erro == 0) {
              
                
                $query = "INSERT INTO `tb_produto`(`cd_produto`,`cd_marca`,`cd_referencia`,`qt_produto`,`tm_tamanho`,
                `vl_venda`,`fl_sexo`,`cd_tipoproduto`,`cd_cor`)
                VALUES('$codigo','$marca','$ref','0','$tm','$vl','$sx','$mdl','$cor')";
                   
                   if (!mysqli_query($conexao, $query)) {
                        echo "erro ao inserir".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Produto cadastrado com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=cadastroNovo.php' />";

                    } 
            }else{
                echo "<div class='divErro'>
                <p>Código já existente</p>
                <div id='x'>X</div>
                </div>";
            }     
            
    

    }
}

?>    