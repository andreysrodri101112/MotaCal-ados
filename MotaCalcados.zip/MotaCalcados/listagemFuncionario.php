
<?php
session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="func") {
    $sessao = "Funcionário";
  }elseif ($_SESSION['username']=="adm") {
    header("Location: paginaAdm.php");
  }
  // echo $sessao;
}else {
  header("Location: index.php");
}
 ?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">

  <link rel="stylesheet" type="text/css" href="boot/datatables.css">
<script type="text/javascript" charset="utf8" src="boot/datatables.js"></script>


  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style/not/listfuncionario.css">
</head>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Mota Calçados</a>
    </div>
    <div class="dropdown" style="mar:right;">
        <?php
         echo "<button class='dropbtn'>$sessao</button>";
        ?>
        <div class="dropdown-content">
          <a href="logout.php">Sair</a>

        </div>
      </div>
  </div>
</nav>


<div class="form2">
    <form class="" action="#" method="post">
      <input type="text" class="form-control" name="pesquisa" value="" placeholder="O que você procura?">
      <button type="submit" class="btn btn-pesquisa" name="filtrogeral" >Pesquisar</button>
    </form>



<form  action="#" method="post">
  <button type="submit" class="btn btn-defaulta"  name="novoPedido">Novo Pedido</button>
</form>
</div>



<body>

  <?php

  $conexao = mysqli_connect("localhost","root","","tcc");
  if (!$conexao) {
    die("Erro".mysql_error());

  }



        if (isset($_POST['logout'])) {
          header("Location:index.php");
        }


        
  if (isset($_POST['novoPedido'])) {
    
    header("Location:pedido.php");    
  }

  
if (isset($_POST['filtrogeral'])) {


  if ($_POST['pesquisa']!="") {

  $pesquisa = "WHERE 
  (
  tb_produto.cd_produto LIKE '%" . $_POST['pesquisa'] . "%'   
  OR tb_marca.nm_marca LIKE '%" . $_POST['pesquisa'] . "%'
  OR tb_cor.nm_cor LIKE '%" . $_POST['pesquisa'] . "%' 
  OR tb_referencia.desc_referencia LIKE '%" . $_POST['pesquisa'] . "%' 
  OR tb_tipoproduto.nm_tipoproduto LIKE '%" . $_POST['pesquisa'] . "%' 
  OR tb_cor.nm_cor LIKE '%" . $_POST['pesquisa'] . "%' 
  OR tb_produto.tm_tamanho LIKE '%" . $_POST['pesquisa'] . "%' 
  )
  and tb_produto.cd_cor = tb_cor.cd_cor
  and tb_produto.cd_referencia = tb_referencia.cd_referencia
  and tb_produto.cd_marca = tb_marca.cd_marca
  and tb_produto.cd_tipoProduto = tb_tipoProduto.cd_tipoProduto";

 
$consulta="SELECT 
tb_produto.cd_produto as codigo,
tb_referencia.desc_referencia as ref,
tb_marca.nm_marca as marca,
tb_produto.tm_tamanho as tamanho,
tb_cor.nm_cor as cor,
tb_produto.fl_sexo as sexo,
tb_tipoproduto.nm_tipoproduto as modelo ,
vl_venda as valor,
qt_produto as quant
FROM tb_produto,tb_cor,tb_referencia,tb_tipoproduto,tb_marca
$pesquisa  order by qt_produto desc,cd_produto desc";

// echo $consulta;

    $linhas=mysqli_query($conexao, $consulta);
  if(mysqli_affected_rows($conexao) > 0){

    
    echo "<table class='table table-bordered' id='todos'>";
    echo "<tr class='corlinha' class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Sexo</td><td>Modelo</td><td>Quantidade</td><td>Valor</td></tr>";
    while ($dados=mysqli_fetch_array($linhas)){

      if($dados['sexo']=="F"){
        $sexo = "Feminino";
      }else if($dados['sexo']=="M"){
        $sexo = "Masculino";
      }
      echo "<tr><td>".$dados['codigo']."</td>";
      echo "<td>".$dados['ref']."</td>";
      echo "<td>".$dados['marca']."</td>";
      echo "<td>".$dados['tamanho']."</td>";
      echo "<td>".$dados['cor']."</td>";
      echo "<td>".$sexo."</td>";
      echo "<td>".$dados['modelo']."</td>";
      echo "<td>".$dados['quant']."</td>";
      echo "<td>".$dados['valor']."</td>";
      

      echo "</tr>";
    }
  }else{
    echo '<div class="errobusca">Sem Registros.</div>';
  }
  echo "</td></tr>";
  echo "</table>";

}else{



        

      $consulta = " SELECT 
      tb_produto.cd_produto as codigo,
      (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as ref,
      (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
      (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
      (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
      tb_produto.tm_tamanho as tamanho,
      tb_produto.fl_sexo as sexo,
      vl_venda as valor,
      qt_produto as quant
      FROM tb_produto  order by qt_produto desc,cd_produto desc
      ";
                            

      $linhas=mysqli_query($conexao, $consulta);
      if(mysqli_affected_rows($conexao) > 0){      
        
        echo "<table class='table table-bordered' id='todos'>";
        echo "<tr class='corlinha' class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Sexo</td><td>Modelo</td><td>Quantidade</td><td>Valor</td></tr>";
        while ($dados=mysqli_fetch_array($linhas)){
          
          if($dados['quant']==0){
            $color = "#BDBDBD";
          }else{
            $color = "black";
          }

          if($dados['sexo']=="F"){
            $sexo = "Feminino";
          }else if($dados['sexo']=="M"){
            $sexo = "Masculino";
          }
          echo "<tr style='color:$color';><td>".$dados['codigo']."</td>";
          echo "<td>".$dados['ref']."</td>";
          echo "<td>".$dados['marca']."</td>";
          echo "<td>".$dados['tamanho']."</td>";
          echo "<td>".$dados['cor']."</td>";
          echo "<td>".$sexo."</td>";
          echo "<td>".$dados['modelo']."</td>";
          echo "<td >".$dados['quant']."</td>";
          echo "<td>".$dados['valor']."</td>";
          

          echo "</tr>";
        }
      }
      echo "</td></tr>";
      echo "</table>";


}
}


?>


  <script type="text/javascript">



// var quant = document.getElementById("quant").innerHTML;
// alert(quant);
    // if (quant> 0) {
    //   document.getElementById("quant").style.color = "white";

    // }
    // for (i = 0; i < quant.length; i++) {
    //     alert(quant[i]);
    // }




  if ( $( ".divErro" ).is( ":hidden" ) ) {
    $( ".divErro" ).slideDown(1000);
  }
  else {
    $( "#divErro" ).hide();
  }



  $('#x').click(function(){
    if ( $(".divErro").slideUp(1000)) {

    }
    return true;
  });
  </script>



</body>
</html>
