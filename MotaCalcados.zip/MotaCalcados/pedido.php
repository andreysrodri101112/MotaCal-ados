
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="style/not/pedido.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>

</head>
<body>
<?php

include_once("carrinho.php");
?>


    <script type="text/javascript">


    if ( $( ".divErro" ).is( ":hidden" ) ) {
      $( ".divErro" ).slideDown(1000);
    }
    else {
      $( "#divErro" ).hide();
    }



    $('#x').click(function(){
      if ( $(".divErro").slideUp(1000)) {

      }
      return true;
    });

    
    </script>

     </body>
  </html>