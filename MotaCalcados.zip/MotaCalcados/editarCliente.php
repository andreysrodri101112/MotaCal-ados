
<div id="c6" class="containerTab" style="display:none;background:#F5F5F5;height:70%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
    <form class="" action="#" method="post">


    <div class="row">
          <div class="col-50">
            <label for="cname">Cliente</label>
            <select class="form-control" name="codigoCliente" id="codigoCliente" style="height:80%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT C.CD_CLIENTE AS codigo,C.NM_CLIENTE AS cliente,C.CPF AS cpf
              FROM TB_CLIENTE AS C
              WHERE NOT EXISTS(SELECT CD_CLIENTE FROM TB_VENDA AS V WHERE V.CD_CLIENTE = C.CD_CLIENTE)";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['cliente'].'</option>';
                  }       
              }  
             ?>
          </select>
          </div>
          <div class="col-50">
            <label for="cname">CPF</label>
            <select class="form-control" name="cpf" id="cpf" style="height:80%;">
            <option value=""></option>
            </select>
            
          <script type="text/javascript">
                                $('#codigoCliente').on("change",function(){
                                    var codigo = $('#codigoCliente').val();
                                    
                                            $.ajax({
                                            type: "GET", //método escolhido
                                            url: "busca_cpf.php?cod="+codigo, //arquivo php chamado                        
                                            dataType: "html",//tipo de função a ser retornada
                                                beforeSend: function(){
                                                    $("#bt").text("Carregando...");
                                                },
                                                error: function(){
                                                    $("#cpf").html("Erro ao carregar HTML! Tente de novo!");
                                                },
                                                success: function(html){
                                                    $("#cpf").html(html);
                                                    
                                                    
                                                }
                                            });

                                });
            </script>

          </div>
    </div>  
    <br>
    <br>
    <br>

      <div class="row">
          <div class="col-50">
            <label for="cname">Novo Nome</label>
            <input type="text" name="novoNomeCliente" value="" maxlength="60">
          </div>

          <div class="col-50">
            <label for="state">Novo CEP</label>
            <input type="text" id="state" name="novoCep" maxlength="8">
          </div>
          
      </div>

    
    <div class="row">
      <div class="col-50">
        <label for="cname">Novo Email</label>
        <input class="form-control" name="novoEmail" style="height:50%;" maxlength="60">
      </div>

        <div class="col-25">
          <label for="state">Novo Telefone</label>
          <input type="text" id="state" name="novoTelefone" maxlength="11">
        </div>
        <div class="col-25">
          <label for="zip">Nova Data Aniversário</label>
          <input type="text" id="zip" class="datepicker" name="novaDataAniver">
        </div>
      
    </div>

    <input type="submit" value="Atualizar" class="btn" name="btnAtualizarCliente" style="background:#00E676;width:50%;margin-left:25%;margin-top:5%;">

  </form>
</div>
</div>


<?php

if(isset($_POST['btnAtualizarCliente'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['codigoCliente'] == ""){
        $vazio = 1;
    }else if($_POST['cpf'] == ""){
        $vazio = 1;
    }else if($_POST['novoNomeCliente'] == ""){
      $vazio = 1;
    }else if($_POST['novoCep'] == ""){
      $vazio = 1;
    }else if($_POST['novoEmail'] == ""){
      $vazio = 1;
    }else if($_POST['novoTelefone'] == ""){
      $vazio = 1;
    }else if($_POST['novaDataAniver'] == ""){
      $vazio = 1;
    }
    $consulta = "SELECT ds_email as email FROM TB_CLIENTE
    WHERE ds_email="."'".$_POST['novoEmail']."'";
    
    $linhas=mysqli_query($conexao, $consulta);
    mysqli_num_rows($linhas);
    $dados=mysqli_fetch_array($linhas);
    $exists = $dados['email'];
    

    if($vazio > 0){
    echo "<div class='divErro'>
    <p>Preencha todos os campos</p>
    <div id='x'>X</div>
    </div>";
    }else if($exists != ""){
    echo "<div class='divErro'>
    <p>Email já existente!</p>
    <div id='x'>X</div>
    </div>";     
    }else{
        $codigo = $_POST['codigoCliente'];
        $cpf = $_POST['cpf'];
        $novoNome = $_POST['novoNomeCliente'];
        $novoCep = $_POST['novoCep'];
        $novoEmail = $_POST['novoEmail'];
        $novoTelefone = $_POST['novoTelefone'];
        $novoAniver = $_POST['novaDataAniver'];
            
                $query = "UPDATE TB_CLIENTE SET nm_cliente='$novoNome',ds_email='$novoEmail',
                tl_telefone='$novoTelefone',cep='$novoCep',dt_aniversario='$novoAniver'
                where cd_cliente=$codigo and cpf='$cpf'
                ";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Cliente atualizado com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaEdicao.php' />";

                        

                    }  
            
                
            }     
            
    

   
}

?>    