<?php



                    $qt = $_GET['qt'];
                    $preco = $_GET['preco'];

                    $total = $qt * $preco;                    
                    $final = number_format($total,2,",",".");
                    
                    // $totalVenda = $totalVenda + $total; 


                        
       echo json_encode(array(
           'total' => $final,
           'qt' => $qt
       ));






 ?>

