<?php

function consultaFinanceiroHoje($tipoConsulta,$p1 = '',$p2 = ''){
        
        if($tipoConsulta == "totComprado"){
                $consulta = "SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
                LEFT JOIN tb_itemvenda
                ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
                LEFT JOIN tb_venda
                ON tb_venda.id_venda = tb_itemvenda.id_venda                
                WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
                and (select max(Qt_Compra) from tb_entrada)
                order by dt_entrada desc";

                return $consulta;
        }
        

        else if($tipoConsulta == "totVendido"){    
            $consulta = "SELECT sum(vl_venda) as tot FROM tb_venda WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
            ";
            return $consulta;
        }
        

        else if($tipoConsulta == "totQt"){
            $consulta = "SELECT 
            sum(tb_itemvenda.qt_venda) as totquant FROM tb_itemvenda,tb_venda
            WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
            AND tb_venda.id_venda = tb_itemvenda.id_venda";
            return $consulta;
        }
        else if($tipoConsulta == "lucro"){
                $consulta = "SELECT (	
                (SELECT sum(vl_venda) FROM tb_venda WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE())
                  -
                (
                
                SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
                LEFT JOIN tb_itemvenda
                ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
                LEFT JOIN tb_venda
                ON tb_venda.id_venda = tb_itemvenda.id_venda
                WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
                and (select max(Qt_Compra) from tb_entrada)
                order by dt_entrada desc
                
                )
                    
                )	as lucro;";   

                return $consulta;     
        }
        else if($tipoConsulta == "produtosMaisVendidos"){
            

            $consulta = "SELECT 
            tb_produto.cd_produto as codigo,
            (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
            (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
            (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
            (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
            
            tb_produto.tm_tamanho as tamanho,
            sum(tb_itemvenda.qt_venda) as quant, 
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
            
            FROM tb_produto,tb_itemvenda,tb_venda
            WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()

            AND
            tb_venda.id_venda = tb_itemvenda.id_venda
            AND
            tb_produto.cd_produto = tb_itemvenda.cd_produto
            group by tb_produto.cd_produto order by quant desc;";

            return $consulta;
            
        }
        else if($tipoConsulta == "formaPagamento"){
            

            $consulta = "SELECT fl_operacao as forma,sum(vl_venda) as valor from tb_venda WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
            group by fl_operacao";
            return $consulta;           
        }
        else if($tipoConsulta == "clientes"){
                $consulta = "SELECT 
                (select nm_cliente from tb_cliente where cd_cliente=(tb_venda.cd_cliente)) as cliente,
                sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
                sum(tb_itemvenda.qt_venda) as quant FROM tb_venda,tb_itemvenda
                WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
                and tb_venda.id_venda = tb_itemvenda.id_venda
                and cd_cliente != ''
                group by cd_cliente order by valor desc;";
            return $consulta;
            
        }


        else if($tipoConsulta == "cores"){
                $consulta = "SELECT 
                (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
                sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
                sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
                LEFT JOIN tb_itemvenda
                ON tb_produto.cd_produto = tb_itemvenda.cd_produto
                LEFT JOIN tb_venda
                ON tb_venda.id_venda = tb_itemvenda.id_venda
                WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
                group by cd_cor order by quant desc;";
            return $consulta;
            
        }


        else if($tipoConsulta == "modelos"){
            $consulta = "SELECT 
            (select nm_tipoproduto from tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
            group by cd_tipoproduto order by quant desc;";
            return $consulta;            
        }


        else if($tipoConsulta == "tamanhos"){        
            $consulta = "SELECT tm_tamanho as tamanho,
            sum(tb_itemvenda.qt_venda) as quant ,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
            FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
            group by tm_tamanho order by quant desc;";
            return $consulta;            
        }


        else if($tipoConsulta == "marcas"){            
            $consulta = "SELECT 
            (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE()
            group by cd_marca order by quant desc;
            ";
            return $consulta;            
        }


}



//-----------------------------------------------------------------------------------------------------------------




function consultaFinanceiroEspecifico($tipoConsulta,$p1 = '',$p2 = ''){
        
    if($tipoConsulta == "totComprado"){
            $consulta = "SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao='$p1'
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc;";

            return $consulta;
    }
    

    else if($tipoConsulta == "totVendido"){    
        $consulta = "SELECT sum(vl_venda) as tot FROM tb_venda where dt_operacao='$p1'";
  

        return $consulta;
    }
    

    else if($tipoConsulta == "totQt"){
        $consulta = "SELECT 
        sum(tb_itemvenda.qt_venda) as totquant FROM tb_itemvenda,tb_venda
        WHERE tb_venda.dt_operacao = '$p1'
        AND tb_venda.id_venda = tb_itemvenda.id_venda";
        return $consulta;
    }
    else if($tipoConsulta == "lucro"){
            $consulta = "SELECT (	
            (SELECT sum(vl_venda) FROM tb_venda where dt_operacao='$p1')
              -
            (
            
            SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao= '$p1'
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc
            
            )
                
            )	as lucro;";   

            return $consulta;     
    }
    else if($tipoConsulta == "produtosMaisVendidos"){
        

        $consulta = "SELECT 
        tb_produto.cd_produto as codigo,
        (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
        (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
        (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        
        tb_produto.tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant, 
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        
        FROM tb_produto,tb_itemvenda,tb_venda
        WHERE
        tb_venda.dt_operacao = '$p1'
        AND
        tb_venda.id_venda = tb_itemvenda.id_venda
        AND
        tb_produto.cd_produto = tb_itemvenda.cd_produto
        group by tb_produto.cd_produto order by quant desc;";

        return $consulta;
        
    }
    else if($tipoConsulta == "formaPagamento"){
        

        $consulta = "SELECT fl_operacao as forma,sum(vl_venda) as valor from tb_venda where dt_operacao='$p1' group by fl_operacao";
        return $consulta;           
    }
    else if($tipoConsulta == "clientes"){
            $consulta = "SELECT 
            (select nm_cliente from tb_cliente where cd_cliente=(tb_venda.cd_cliente)) as cliente,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_venda,tb_itemvenda
            where tb_venda.dt_operacao = '$p1'
            and tb_venda.id_venda = tb_itemvenda.id_venda
            and cd_cliente != ''
            group by cd_cliente order by valor desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "cores"){
            $consulta = "SELECT 
            (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao = '$p1'
            group by cd_cor order by quant desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "modelos"){
        $consulta = "SELECT 
        (select nm_tipoproduto from tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao = '$p1'
        group by cd_tipoproduto order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "tamanhos"){        
        $consulta = "SELECT tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant ,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao = '$p1'
        group by tm_tamanho order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "marcas"){            
        $consulta = "SELECT 
        (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao = '$p1'
        group by cd_marca order by quant desc;
        ";
        return $consulta;            
    }


}

//-----------------------------------------------------------------------------------------------------------------


function consultaFinanceiroIntervalo($tipoConsulta, $p1 = '',$p2 =''){
        

    if($tipoConsulta == "totComprado"){
            $consulta = "SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc;";

            return $consulta;
    }
    
    else if($tipoConsulta == "totVendido"){    
        $consulta = "SELECT sum(vl_venda) as tot FROM tb_venda where dt_operacao BETWEEN '$p1' and '$p2'";
  

        return $consulta;
    }
    

    else if($tipoConsulta == "totQt"){
        $consulta = "SELECT 
        sum(tb_itemvenda.qt_venda) as totquant FROM tb_itemvenda,tb_venda
        where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
        AND tb_venda.id_venda = tb_itemvenda.id_venda";
        return $consulta;
    }
    else if($tipoConsulta == "lucro"){
            $consulta = "SELECT (	
            (SELECT sum(vl_venda) FROM tb_venda where dt_operacao BETWEEN '$p1' and '$p2')
              -
            (

            SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc
            
            )
                
            )	as lucro;";   

            return $consulta;     
    }
    else if($tipoConsulta == "produtosMaisVendidos"){
        

        $consulta = "SELECT 
        tb_produto.cd_produto as codigo,
        (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
        (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
        (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        
        tb_produto.tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant, 
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        
        FROM tb_produto,tb_itemvenda,tb_venda
            where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
        AND
        tb_venda.id_venda = tb_itemvenda.id_venda
        AND
        tb_produto.cd_produto = tb_itemvenda.cd_produto
        group by tb_produto.cd_produto order by quant desc";

        return $consulta;
        
    }
    else if($tipoConsulta == "formaPagamento"){
        

        $consulta = "SELECT fl_operacao as forma,sum(vl_venda) as valor from tb_venda where dt_operacao BETWEEN '$p1' and '$p2' group by fl_operacao";
        return $consulta;           
    }
    else if($tipoConsulta == "clientes"){
            $consulta = "SELECT 
            (select nm_cliente from tb_cliente where cd_cliente=(tb_venda.cd_cliente)) as cliente,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_venda,tb_itemvenda
            where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
            and tb_venda.id_venda = tb_itemvenda.id_venda
            and cd_cliente != ''
            group by cd_cliente order by valor desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "cores"){
            $consulta = "SELECT 
            (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
            group by cd_cor order by quant desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "modelos"){
        $consulta = "SELECT 
        (select nm_tipoproduto from tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
        group by cd_tipoproduto order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "tamanhos"){        
        $consulta = "SELECT tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant ,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
        group by tm_tamanho order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "marcas"){            
        $consulta = "SELECT 
        (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao BETWEEN '$p1' and '$p2'
        group by cd_marca order by quant desc;
        ";
        return $consulta;            
    }


}

//-----------------------------------------------------------------------------------------------------------------


function consultaFinanceiroMes($tipoConsulta,$p1 = '',$p2 = ''){
        

    if($tipoConsulta == "totComprado"){
            $consulta = "SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc;";

            return $consulta;
    }
    
    else if($tipoConsulta == "totVendido"){    
        $consulta = "SELECT sum(vl_venda) as tot FROM tb_venda 
        WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'";
        return $consulta;
    }
    

    else if($tipoConsulta == "totQt"){
        $consulta = "SELECT 
        sum(tb_itemvenda.qt_venda) as totquant FROM tb_itemvenda,tb_venda
        WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
        AND tb_venda.id_venda = tb_itemvenda.id_venda";
        return $consulta;
    }
    else if($tipoConsulta == "lucro"){
            $consulta = "SELECT (	
            (SELECT sum(vl_venda) FROM tb_venda 
            WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
            )
              -
            (

            SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc
            
            )
                
            )	as lucro;";   

            return $consulta;     
    }
    else if($tipoConsulta == "produtosMaisVendidos"){
        

        $consulta = "SELECT 
        tb_produto.cd_produto as codigo,
        (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
        (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
        (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        
        tb_produto.tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant, 
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        
        FROM tb_produto,tb_itemvenda,tb_venda
        WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
        AND
        tb_venda.id_venda = tb_itemvenda.id_venda
        AND
        tb_produto.cd_produto = tb_itemvenda.cd_produto
        group by tb_produto.cd_produto order by quant desc";

        return $consulta;
        
    }
    else if($tipoConsulta == "formaPagamento"){
        

        $consulta = "SELECT fl_operacao as forma,sum(vl_venda) as valor from tb_venda
        WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'";
        return $consulta;           
    }
    else if($tipoConsulta == "clientes"){
            $consulta = "SELECT 
            (select nm_cliente from tb_cliente where cd_cliente=(tb_venda.cd_cliente)) as cliente,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_venda,tb_itemvenda
            WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
            and tb_venda.id_venda = tb_itemvenda.id_venda
            and cd_cliente != ''
            group by cd_cliente order by valor desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "cores"){
            $consulta = "SELECT 
            (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
            group by cd_cor order by quant desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "modelos"){
        $consulta = "SELECT 
        (select nm_tipoproduto from tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
        group by cd_tipoproduto order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "tamanhos"){        
        $consulta = "SELECT tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant ,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
        group by tm_tamanho order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "marcas"){            
        $consulta = "SELECT 
        (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'
        group by cd_marca order by quant desc;
        ";
        return $consulta;            
    }


}

//-----------------------------------------------------------------------------------------------------------------


function consultaFinanceiroTrimestre($tipoConsulta,$p1 = '',$p2 = ''){


    if($tipoConsulta == "totComprado"){
            $consulta = "SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao $p1
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc;";

            return $consulta;
    }
    
    else if($tipoConsulta == "totVendido"){    
        $consulta = "SELECT sum(vl_venda) as tot FROM tb_venda 
        where tb_venda.dt_operacao $p1";
        return $consulta;
    }
    

    else if($tipoConsulta == "totQt"){
        $consulta = "SELECT 
        sum(tb_itemvenda.qt_venda) as totquant FROM tb_itemvenda,tb_venda
        where tb_venda.dt_operacao $p1
        AND tb_venda.id_venda = tb_itemvenda.id_venda";
        return $consulta;
    }
    else if($tipoConsulta == "lucro"){
            $consulta = "SELECT (	
            (SELECT sum(vl_venda) FROM tb_venda 
            where tb_venda.dt_operacao $p1
            )
              -
            (

            SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao $p1
            order by dt_entrada desc
            
            )
                
            )	as lucro;";   

            return $consulta;     
    }
    else if($tipoConsulta == "produtosMaisVendidos"){
        

        $consulta = "SELECT 
        tb_produto.cd_produto as codigo,
        (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
        (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
        (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        
        tb_produto.tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant, 
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        
        FROM tb_produto,tb_itemvenda,tb_venda
        where tb_venda.dt_operacao $p1
        AND
        tb_venda.id_venda = tb_itemvenda.id_venda
        AND
        tb_produto.cd_produto = tb_itemvenda.cd_produto
        group by tb_produto.cd_produto order by quant desc";

        return $consulta;
        
    }
    else if($tipoConsulta == "formaPagamento"){
        

        $consulta = "SELECT fl_operacao as forma,sum(vl_venda) as valor from tb_venda
        where tb_venda.dt_operacao $p1";
        return $consulta;           
    }
    else if($tipoConsulta == "clientes"){
            $consulta = "SELECT 
            (select nm_cliente from tb_cliente where cd_cliente=(tb_venda.cd_cliente)) as cliente,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_venda,tb_itemvenda
            where tb_venda.dt_operacao $p1
            and tb_venda.id_venda = tb_itemvenda.id_venda
            and cd_cliente != ''
            group by cd_cliente order by valor desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "cores"){
            $consulta = "SELECT 
            (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            where tb_venda.dt_operacao $p1
            group by cd_cor order by quant desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "modelos"){
        $consulta = "SELECT 
        (select nm_tipoproduto from tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao $p1
        group by cd_tipoproduto order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "tamanhos"){        
        $consulta = "SELECT tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant ,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao $p1
        group by tm_tamanho order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "marcas"){            
        $consulta = "SELECT 
        (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        where tb_venda.dt_operacao $p1
        group by cd_marca order by quant desc;
        ";
        return $consulta;            
    }


}

//-----------------------------------------------------------------------------------------------------------------


function consultaFinanceiroAno($tipoConsulta,$p1 = '',$p2 = ''){


    if($tipoConsulta == "totComprado"){
            $consulta = "SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE YEAR(tb_venda.dt_operacao) = '$p1'
            and (select max(Qt_Compra) from tb_entrada)
            order by dt_entrada desc;";

            return $consulta;
    }
    
    else if($tipoConsulta == "totVendido"){    
        $consulta = "SELECT sum(vl_venda) as tot FROM tb_venda 
       WHERE YEAR(tb_venda.dt_operacao) = '$p1'";
        return $consulta;
    }
    

    else if($tipoConsulta == "totQt"){
        $consulta = "SELECT 
        sum(tb_itemvenda.qt_venda) as totquant FROM tb_itemvenda,tb_venda
        WHERE YEAR(tb_venda.dt_operacao) = '$p1'
        AND tb_venda.id_venda = tb_itemvenda.id_venda";
        return $consulta;
    }
    else if($tipoConsulta == "lucro"){
            $consulta = "SELECT (	
            (SELECT sum(vl_venda) FROM tb_venda 
            WHERE YEAR(tb_venda.dt_operacao) = '$p1'
            )
              -
            (

            SELECT sum(vl_compra * tb_itemvenda.qt_venda) as tot FROM tb_entrada
            LEFT JOIN tb_itemvenda
            ON tb_entrada.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE YEAR(tb_venda.dt_operacao) = '$p1'
            order by dt_entrada desc
            
            )
                
            )	as lucro;";   

            return $consulta;     
    }
    else if($tipoConsulta == "produtosMaisVendidos"){
        

        $consulta = "SELECT 
        tb_produto.cd_produto as codigo,
        (SELECT desc_referencia FROM tb_referencia where cd_referencia=(tb_produto.cd_referencia)) as referencia,
        (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
        (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        
        tb_produto.tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant, 
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        
        FROM tb_produto,tb_itemvenda,tb_venda
        WHERE YEAR(tb_venda.dt_operacao) = '$p1'
        AND
        tb_venda.id_venda = tb_itemvenda.id_venda
        AND
        tb_produto.cd_produto = tb_itemvenda.cd_produto
        group by tb_produto.cd_produto order by quant desc";

        return $consulta;
        
    }
    else if($tipoConsulta == "formaPagamento"){
        

        $consulta = "SELECT fl_operacao as forma,sum(vl_venda) as valor from tb_venda
        WHERE YEAR(tb_venda.dt_operacao) = '$p1'";
        return $consulta;           
    }
    else if($tipoConsulta == "clientes"){
            $consulta = "SELECT 
            (select nm_cliente from tb_cliente where cd_cliente=(tb_venda.cd_cliente)) as cliente,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_venda,tb_itemvenda
            WHERE YEAR(tb_venda.dt_operacao) = '$p1'
            and tb_venda.id_venda = tb_itemvenda.id_venda
            and cd_cliente != ''
            group by cd_cliente order by valor desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "cores"){
            $consulta = "SELECT 
            (select nm_cor from tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
            sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
            sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
            LEFT JOIN tb_itemvenda
            ON tb_produto.cd_produto = tb_itemvenda.cd_produto
            LEFT JOIN tb_venda
            ON tb_venda.id_venda = tb_itemvenda.id_venda
            WHERE YEAR(tb_venda.dt_operacao) = '$p1'
            group by cd_cor order by quant desc;";
        return $consulta;
        
    }


    else if($tipoConsulta == "modelos"){
        $consulta = "SELECT 
        (select nm_tipoproduto from tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        WHERE YEAR(tb_venda.dt_operacao) = '$p1'
        group by cd_tipoproduto order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "tamanhos"){        
        $consulta = "SELECT tm_tamanho as tamanho,
        sum(tb_itemvenda.qt_venda) as quant ,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor
        FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        WHERE YEAR(tb_venda.dt_operacao) = '$p1'
        group by tm_tamanho order by quant desc;";
        return $consulta;            
    }


    else if($tipoConsulta == "marcas"){            
        $consulta = "SELECT 
        (select nm_marca from tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
        sum(tb_itemvenda.vl_item  * tb_itemvenda.qt_venda) as valor,
        sum(tb_itemvenda.qt_venda) as quant FROM tb_produto
        LEFT JOIN tb_itemvenda
        ON tb_produto.cd_produto = tb_itemvenda.cd_produto
        LEFT JOIN tb_venda
        ON tb_venda.id_venda = tb_itemvenda.id_venda
        WHERE YEAR(tb_venda.dt_operacao) = '$p1'
        group by cd_marca order by quant desc;
        ";
        return $consulta;            
    }


}
?>