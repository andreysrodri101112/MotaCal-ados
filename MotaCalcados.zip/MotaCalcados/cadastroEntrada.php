<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}
?>

<div id="c1" class="containerTab" style="display:none;background:#F5F5F5;height:60%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
  <div class="col-50">
    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-50">
          <label for="cname">Codigo</label>
          <select  class="form-control" name="codigoEntrada" style="height:10%;" >
            <option value=""></option>
            <?php
              $consulta = "SELECT cd_produto from tb_produto";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['cd_produto'].'">'.$dados['cd_produto'].'</option>';
                  }       
              }  
            ?>

          </select>

        </div>
        <div class="col-50">
          <label for="zip" >Data</label>
          <input type="text" id="zip" class="datepicker" name="dataEntrada" autocomplete="off">
        </div>
      </div>
      <div class="row">
        <div class="col-50">
          <label for="state">Valor de compra </label>
          <input type="text" id="state" name="valorEntrada">
        </div>
        <div class="col-50">
          <label for="zip">Quantidade</label>
          <input type="text" id="zip" name="quantidadeEntrada" maxlength="4">
        </div>
      </div>
     </div>
        <input type="submit" value="Cadastrar" class="btn" name="cadastrarEntrada"  id="btnCadastrar">


  </form>
</div>


<?php



if(isset($_POST['cadastrarEntrada'])){

    $erro = 0;
    $vazio = 0;


    if(!is_numeric($_POST['quantidadeEntrada']) || !is_numeric($_POST['valorEntrada'])){
       echo "<div class='divErro'>
       <p>São aceitos somente numeros nos campos valor e quantidade de entrada.</p>
       <div id='x'>X</div>
       </div>";
    }else {           
            if($_POST['codigoEntrada'] == ""){
                $vazio = 1;
            }else if($_POST['valorEntrada'] == ""){
                $vazio = 1;
            }else if($_POST['dataEntrada'] == ""){
                $vazio = 1;
            }else if($_POST['quantidadeEntrada'] == ""){
                $vazio = 1;
            }

       
    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['codigoEntrada'];
        $valor = $_POST['valorEntrada'];
        $dt = $_POST['dataEntrada'];
        $quant = $_POST['quantidadeEntrada'];

        $nova_data = explode("/", $dt);
        $data = $nova_data[2] . "-" . $nova_data[1] . "-" . $nova_data[0];

            $consulta = "SELECT dt_entrada as dt from tb_entrada WHERE cd_produto=".$codigo;
            // echo "<script>alert($consulta);</script>";
            $linhas=mysqli_query($conexao, $consulta);
            if(mysqli_num_rows($linhas) > 0){
                while ($dados=mysqli_fetch_array($linhas)){
                        if($dados['dt']==$data){
                            $erro = 1;
                        }
                }       
            }
            

            if($erro == 0) {
                $query = "INSERT INTO `tb_entrada`(`cd_produto`,`dt_entrada`,`vl_compra`,`qt_compra`) VALUES('$codigo','$data','$valor','$quant')";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao inserir".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Entrada cadastrada com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=cadastroNovo.php' />";

                    }  
            }else{
                echo "<div class='divErro'>
                <p>Não é possivel cadastrar mais de uma entrada com a mesma data</p>
                <div id='x'>X</div>
                </div>";
            }     
            
    

    }
  }  
}

?>    