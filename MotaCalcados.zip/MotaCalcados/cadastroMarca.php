<div id="c3" class="containerTab" style="display:none;background:#F5F5F5;height:40%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>

    <form class="" action="#" method="post">

      <div class="row">
        

          <div class="col-50">
            <label for="cname">Marca</label>
            <input class="form-control" name="inputMarca" style="height:15%;" maxlength="30">


          </div>

     
      </div>
        
      <input type="submit" value="Cadastrar" class="btn" name="cadastrarMarca" id="btnCadastrar" />

    </form>

</div>
<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}

if(isset($_POST['cadastrarMarca'])){

    $vazio = 0;
    
    if($_POST['inputMarca'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $erro = 0;
        $marca = $_POST['inputMarca'];

            $consulta = "SELECT nm_marca as marca from tb_marca";
            $linhas=mysqli_query($conexao, $consulta);
            if(mysqli_num_rows($linhas) > 0){
                while ($dados=mysqli_fetch_array($linhas)){
                        if($dados['marca']==$marca){
                            $erro = 1;
                        }
                }       
            }

            if($erro == 0) {
                $query = "INSERT INTO `tb_marca`(`cd_marca`,`nm_marca`) VALUES(null,'$marca')";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao inserir".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Marca cadastrada com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=cadastroNovo.php' />";

                    }  
            }else{
                
                echo "<div class='divErro'>
                <p>Marca já existente</p>
                <div id='x'>X</div>
                </div>";
            }     
                
        }    

}


?>    