<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}
?>

<div id="c2" class="containerTab" style="display:none;background:#F5F5F5;height:40%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-50">
          <label for="zip">Marca</label>

          <select class="form-control" name="inputMarca" style="height:15%;" >
          <option value=""></option>
            <?php
              $consulta = "SELECT cd_marca,nm_marca from tb_marca";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['cd_marca'].'">'.$dados['nm_marca'].'</option>';
                  }       
              }  
            ?>

          </select>

        </div>
        <div class="col-50">
          <label for="zip">Referência</label>
          <input type="text" id="zip" name="inputReferencia" maxlength="30">
        </div>
      </div>

      <input type="submit" value="Cadastrar" class="btn"name="cadastrarReferencia"  id="btnCadastrar">

    </form>
  </div>
</div>
<?php



if(isset($_POST['cadastrarReferencia'])){
  $vazio = 0;


        if($_POST['inputMarca'] == ""){
            $vazio = 1;
        }else if($_POST['inputReferencia'] == ""){
          $vazio = 1;
        }


  if($vazio > 0){
    echo "<div class='divErro'>
    <p>Preencha todos os campos</p>
    <div id='x'>X</div>
    </div>";
  }else{
        $erro = 0;
        $referencia = $_POST['inputReferencia'];
        $marca = $_POST['inputMarca'];

            $consulta = "SELECT desc_referencia as ref from tb_referencia";
            $linhas=mysqli_query($conexao, $consulta);
            if(mysqli_num_rows($linhas) > 0){
                while ($dados=mysqli_fetch_array($linhas)){
                        if($dados['ref']==$referencia){
                            $erro = 1;
                        }
                }       
            }

            if($erro == 0) {
                $query = "INSERT INTO `tb_referencia`(`cd_marca`,`cd_referencia`,`desc_referencia`) VALUES('$marca',null,'$referencia')";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao inserir".$query."<br><br><br>";
                    }else{
                      echo "<div class='divErro'>
                      <p>Referencia cadastrada com sucesso</p>
                      <div id='x'>X</div>
                      </div>";
                      echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=cadastroNovo.php' />";

                  }  
            }else{
              echo "<div class='divErro'>
              <p>Referencia ja existente</p>
              <div id='x'>X</div>
              </div>";           
             }     
      }          
    
    
}


?>    