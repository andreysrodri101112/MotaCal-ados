
<?php

include("funcoesFinanceiro.php");

session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="adm") {
    $sessao = "Administrador";
  }elseif ($_SESSION['username']=="func") {
    header("Location: listagemfuncionario.php");
  }
  // echo $sessao;
}else {
  header("Location: index.php");
}


if (isset($_POST['logout'])) {
  header("Location:index.php");
}
?>

<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}

?>

<!DOCTYPE html>

<html>
        <head>
          <meta charset="utf-8">
          <title></title>
          <link rel="stylesheet" href="boot/bootstrap.min.css">
          <script src="boot/jquery.min.js"></script>
          <script src="boot/bootstrap.min.js"></script>
          <link rel="stylesheet" href="style/not/financeiro.css">
          <meta charset="utf-8">
          <script src="js/bootstrap-datepicker.js"></script>
          <link href="css/bootstrap-datepicker.css" rel="stylesheet" />

          <script>

          </script>
        </head>
  <body>



      <nav class="navbar navbar-default">
          <div class="container-fluid">
            <div class="navbar-header">
              <a class="navbar-brand" href="#">Mota Calçados</a>
            </div>
            <ul class="nav navbar-nav">

              <li><a href="cadastroNovo.php">Cadastro</a></li>
              <li ><a href="listagem.php">Estoque</a></li>
              <li><a href="vendas.php">Vendas</a></li>
              <li class="position"><a href="financeiro.php">Financeiro</a></li>
              <li ><div class="dropdown">
                <button  class="dropbtn" style="background:none;color:black;">Configurações</button>
                <div id="myDropdown1" class="dropdown-content">
                  <a href="paginaEdicao.php">Editar</a>
                  <a href="paginaExclusao.php">Excluir</a>                  
                </div>
             
            </li>

            </ul>



                    <div class="dropdown" style="mar:right;">
                      <?php
                      echo "<button class='dropbtn'>$sessao</button>";
                      ?>
                      <div class="dropdown-content">
                        <a href="logout.php">Sair</a>

                      </div>
                    </div>

          </nav>
          <script type="text/javascript">
            $(document).ready(function () {
              $('.datepicker').datepicker({
                format: 'dd/mm/yyyy',
                language: 'pt-BR'
              });
            });
            </script>

           <form action="#" method="post" id="optionFiltro">
              <label for="">Selecione a data para a busca</label> <br><br> 
                  <select name="filtro" class="form-control" style="width:20%;">
                    <option value=""></option>
                    <option value="hoje">Hoje</option>
                      <option value="especifico">Específico</option>
                      <option value="intervalo">Período</option>
                      <option value="mes">Mês</option>
                      <option value="trimestre">Trimestre</option>
                      <option value="ano">Ano</option>
                      
                    </select>
                <button type="submit" name="action" value="" class="btn btn-pesquisa" >buscar</button>
          </form>



<?php


if(isset($_POST['action'])){
    if($_POST['filtro']==""){
      echo "<div class='divErro'>
      <p>Selecione alguma opção para o faturamento</p>
      <div id='x'>X</div>
      </div>"; 
    
    }else{
    ?>  
    <style>
    #optionFiltro{
      display: none;
    } 
    </style>
    <?php  
  
      if($_POST['filtro']=="hoje"){
        
        ?>  
        <style>
        #optionFiltro{
          display: block;
        } 
        </style>
        <?php 
        echo '
        <form class="data" action="#" method="post">               
            <input type="hidden" name="verificador" value="hoje"/>
            <button type="submit" class="btn" style="background:#00C853;" name="btnbusca">FATURAMENTO ATÉ O MOMENTO</button>
        </form>
        ';
      
      }else if($_POST['filtro']=="especifico"){
      echo '     
      <form class="data" action="#" method="post">
        <label for="">Data</label>
        <input type="text" name="dt_inicial" class="datepicker" autocomplete="off"/>
        <input type="hidden" name="verificador" value="especifico"/>
        <button type="submit" class="btn btn-pesquisa" name="btnbusca" >Buscar</button>
      </form>
      ';  
      
      }else if($_POST['filtro']=="intervalo"){
        

        echo '
        <form class="data" action="#" method="post">
          <label for="">Data Inicial</label>
          <input type="text" name="dt_inicial" class="datepicker" autocomplete="off"/>
          <label for="">Data Final</label>
          <input type="text" name="dt_final" class="datepicker" autocomplete="off"/>
          <input type="hidden" name="verificador" value="intervalo"/>
          <button type="submit" class="btn btn-pesquisa" name="btnbusca" >Buscar</button>
        </form>';  
        
      }else if($_POST['filtro']=="mes"){
        

        echo '
                <form class="data" action="#" method="post">
                  <label for="">Escolha o ano/mês:</label>
                    <select class="form-control" name="ano" style="width:10%;">
                      <option value="">Ano</option>
                      <option value="2018">2018</option>
                      <option value="2019">2019</option>
                      <option value="2020">2020</option>
                      <option value="2021">2021</option>
                      <option value="2022">2022</option>
                      
                    </select>
              
                  
                  <select class="form-control" name="mes" style="width:10%;">
                      <option value="">Mês</option>
                      <option value="01">Janeiro</option>
                      <option value="02">Fevereiro</option>
                      <option value="03">Março</option>
                      <option value="04">Abril</option>
                      <option value="05">Maio</option>
                      <option value="06">Junho</option>
                      <option value="07">Julho</option>
                      <option value="08">Agosto</option>
                      <option value="09">Setembro</option>
                      <option value="10">Outubro</option>
                      <option value="11">Novembro</option>
                      <option value="12">Dezembro</option>
                  </select>   
                  <input type="hidden" name="verificador" value="mes"/>

            <button type="submit" class="btn btn-pesquisa" name="btnbusca" >Buscar</button>
          </form>
        
        ';  
        
      }else if($_POST['filtro']=="trimestre"){
        

        echo '
              <form class="data" action="#" method="post">
                <label for="">Escolha o ano/trimestre:</label>
                  <select class="form-control" name="ano" style="width:10%;">
                    <option value="">Ano</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    
                  </select>
            
                  <select class="form-control" name="tri" style="width:10%;">
                    <option value="">Trimestre</option>
                    <option value="1">1° - Janeiro, Fevereiro e Março</option>
                    <option value="2">2° - Abril, Maio e Junho</option>
                    <option value="3">3° - Julho, Agosto e Setembro</option>
                    <option value="4">4° - Outubro, Novembro e Dezembro</option>
                  </select>
                  <input type="hidden" name="verificador" value="trimestre"/>

            <button type="submit" class="btn btn-pesquisa" name="btnbusca" >Buscar</button>
        </form>
        ';  
        
      }else if($_POST['filtro']=="ano"){
        

        echo '
        <form class="data" action="#" method="post">
        <label for="">Escolha o ano:</label>
            <select class="form-control" name="ano" style="width:10%;">
                <option value="">Ano</option>
                <option value="2018">2018</option>
                <option value="2019">2019</option>
                <option value="2020">2020</option>
                <option value="2021">2021</option>
                <option value="2022">2022</option>
                
              </select>
            <input type="hidden" name="verificador" value="ano"/>
          <button type="submit" class="btn btn-pesquisa" name="btnbusca" >Buscar</button>
        </form>
        ';  
        
      }
  }   
}






if(isset($_POST['btnbusca'])){

      $verificador = $_POST['verificador'];
      
      
      if($verificador == "hoje"){

      $busca = 0; 
             
      $funcao1  = consultaFinanceiroHoje("totComprado");
      $funcao2  = consultaFinanceiroHoje("totVendido");
      $funcao3  = consultaFinanceiroHoje("totQt");
      $funcao4  = consultaFinanceiroHoje("lucro");
      $funcao5  = consultaFinanceiroHoje("produtosMaisVendidos");
      $funcao6  = consultaFinanceiroHoje("formaPagamento");
      $funcao7  = consultaFinanceiroHoje("clientes");
      $funcao8  = consultaFinanceiroHoje("cores");
      $funcao9  = consultaFinanceiroHoje("modelos");
      $funcao10 = consultaFinanceiroHoje("marcas");
      $funcao11 = consultaFinanceiroHoje("tamanhos");
           

    }else if($verificador == "especifico"){

       $dt = $_POST['dt_inicial'];
       $busca = 0; 
                  if($dt==""){
                    $busca = 1;
                  }else{

                        $nova_data = explode("/", $dt);
                        $data = $nova_data[2] . "-" . $nova_data[1] . "-" . $nova_data[0];

                        $funcao1  = consultaFinanceiroEspecifico("totComprado",$data);
                        $funcao2  = consultaFinanceiroEspecifico("totVendido",$data);
                        $funcao3  = consultaFinanceiroEspecifico("totQt",$data);
                        $funcao4  = consultaFinanceiroEspecifico("lucro",$data);
                        $funcao5  = consultaFinanceiroEspecifico("produtosMaisVendidos",$data);
                        $funcao6  = consultaFinanceiroEspecifico("formaPagamento",$data);
                        $funcao7  = consultaFinanceiroEspecifico("clientes",$data);
                        $funcao8  = consultaFinanceiroEspecifico("cores",$data);
                        $funcao9  = consultaFinanceiroEspecifico("modelos",$data);
                        $funcao10 = consultaFinanceiroEspecifico("marcas",$data);
                        $funcao11 = consultaFinanceiroEspecifico("tamanhos",$data);

                  }          

    }else if($verificador == "intervalo"){


    $dt_i = $_POST['dt_inicial'];
    $dt_f = $_POST['dt_final'];
    $busca = 0; 

                if($dt_i=="" && $dt_f==""){
                  $busca = 1;
                }else{

                    $nova_data_i = explode("/", $dt_i);
                    $data_i = $nova_data_i[2] . "-" . $nova_data_i[1] . "-" . $nova_data_i[0];
                    $nova_data_f = explode("/", $dt_f);
                    $data_f = $nova_data_f[2] . "-" . $nova_data_f[1] . "-" . $nova_data_f[0];

                    $funcao1  = consultaFinanceiroIntervalo("totComprado",$data_i,$data_f);
                    $funcao2  = consultaFinanceiroIntervalo("totVendido",$data_i,$data_f);
                    $funcao3  = consultaFinanceiroIntervalo("totQt",$data_i,$data_f);
                    $funcao4  = consultaFinanceiroIntervalo("lucro",$data_i,$data_f);
                    $funcao5  = consultaFinanceiroIntervalo("produtosMaisVendidos",$data_i,$data_f);
                    $funcao6  = consultaFinanceiroIntervalo("formaPagamento",$data_i,$data_f);
                    $funcao7  = consultaFinanceiroIntervalo("clientes",$data_i,$data_f);
                    $funcao8  = consultaFinanceiroIntervalo("cores",$data_i,$data_f);
                    $funcao9  = consultaFinanceiroIntervalo("modelos",$data_i,$data_f);
                    $funcao10 = consultaFinanceiroIntervalo("marcas",$data_i,$data_f);
                    $funcao11 = consultaFinanceiroIntervalo("tamanhos",$data_i,$data_f);                }
  
      }else if($verificador == "mes"){


        $mes = $_POST['mes'];
        $ano = $_POST['ano'];
        $busca = 0; 
    
                    if($mes=="" && $ano==""){
                      $busca = 1;
                    }else{
                      $funcao1  = consultaFinanceiroMes("totComprado",$mes,$ano);
                      $funcao2  = consultaFinanceiroMes("totVendido",$mes,$ano);
                      $funcao3  = consultaFinanceiroMes("totQt",$mes,$ano);
                      $funcao4  = consultaFinanceiroMes("lucro",$mes,$ano);
                      $funcao5  = consultaFinanceiroMes("produtosMaisVendidos",$mes,$ano);
                      $funcao6  = consultaFinanceiroMes("formaPagamento",$mes,$ano);
                      $funcao7  = consultaFinanceiroMes("clientes",$mes,$ano);
                      $funcao8  = consultaFinanceiroMes("cores",$mes,$ano);
                      $funcao9  = consultaFinanceiroMes("modelos",$mes,$ano);
                      $funcao10 = consultaFinanceiroMes("marcas",$mes,$ano);
                      $funcao11 = consultaFinanceiroMes("tamanhos",$mes,$ano);  
                    }
      
        }
        else if($verificador == "trimestre"){

            $ano = $_POST['ano'];
            $index = $_POST['tri'];  
            if($index == 1){
              $select = "BETWEEN '$ano-01-01' and '$ano-03-31'";
            }else if($index==2){
              $select = "BETWEEN '$ano-04-01' and '$ano-06-30'";
            }else if($index==3){
              $select = "BETWEEN '$ano-07-01' and '$ano-09-30'";
            }else if($index==4){
              $select = "BETWEEN '$ano-10-01' and '$ano-12-31'";
            }

            $busca = 0; 
        
                        if($ano=="" && $index==""){
                          $busca = 1;
                        }else{
                          $funcao1  = consultaFinanceiroTrimestre("totComprado",$select);
                          $funcao2  = consultaFinanceiroTrimestre("totVendido",$select);
                          $funcao3  = consultaFinanceiroTrimestre("totQt",$select);
                          $funcao4  = consultaFinanceiroTrimestre("lucro",$select);
                          $funcao5  = consultaFinanceiroTrimestre("produtosMaisVendidos",$select);
                          $funcao6  = consultaFinanceiroTrimestre("formaPagamento",$select);
                          $funcao7  = consultaFinanceiroTrimestre("clientes",$select);
                          $funcao8  = consultaFinanceiroTrimestre("cores",$select);
                          $funcao9  = consultaFinanceiroTrimestre("modelos",$select);
                          $funcao10 = consultaFinanceiroTrimestre("marcas",$select);
                          $funcao11 = consultaFinanceiroTrimestre("tamanhos",$select);
                        }
          
            }else if($verificador == "ano"){


              $ano = $_POST['ano'];
              $busca = 0; 
          
                          if($ano==""){
                            $busca = 1;
                          }else{
                            $funcao1  = consultaFinanceiroAno("totComprado",$ano);
                            $funcao2  = consultaFinanceiroAno("totVendido",$ano);
                            $funcao3  = consultaFinanceiroAno("totQt",$ano);
                            $funcao4  = consultaFinanceiroAno("lucro",$ano);
                            $funcao5  = consultaFinanceiroAno("produtosMaisVendidos",$ano);
                            $funcao6  = consultaFinanceiroAno("formaPagamento",$ano);
                            $funcao7  = consultaFinanceiroAno("clientes",$ano);
                            $funcao8  = consultaFinanceiroAno("cores",$ano);
                            $funcao9  = consultaFinanceiroAno("modelos",$ano);
                            $funcao10 = consultaFinanceiroAno("marcas",$ano);
                            $funcao11 = consultaFinanceiroAno("tamanhos",$ano); 
                          }
            
              }




          

      if($busca > 0){
        echo '<div class="errobusca">Preencha o(s) campo(s) para ocorrer a busca. Tente Novamente.</div>';
      }else{

      
      

?>


          <div class="row" style="margin:4%;">
            <div class="column">
              <div class="card">
                <div class="desc">Gasto Total</div>
                  <div class="dnhComprado"></div>
            
                <div class="valor"> <!--total valor comprado -->
                <span class="cifrao">R$</span>
                <?php      

                  $linhas=mysqli_query($conexao, $funcao1);
                  mysqli_affected_rows($conexao);
                  $dados=mysqli_fetch_array($linhas);
                  if($dados['tot']!=""){
                    echo $dados['tot'];
                  }else{
                    echo 0;
                  }
                  
              
              ?>     
            
            </div>
          </div>  
            
          <!-- </div> --></div>
        <div class="column">
          <div class="card">
            <div class="desc">Total Vendido</div>
              <div class="dnhVendido"></div>
                <div class="valor"> <!--total valor vendido -->
                  <span class="cifrao">R$</span>

                  <?php      
                  $linhas=mysqli_query($conexao, $funcao2);
                  mysqli_affected_rows($conexao);
                  $dados=mysqli_fetch_array($linhas);
                  $totVendido = $dados['tot'];

                  if($dados['tot']!=""){
                    echo $dados['tot'];
                  }else{
                    echo 0;
                  }
              
                  ?>

            </div>    
          </div>
        </div>

        <div class="column">
          <div class="card">
          <div class="desc">Quantidade Total</div>
            <div class="qt"></div>
            <div class="valor"> <!--quantidade total -->
            <span class="cifrao"></span>

            <?php      
                

                  $linhas=mysqli_query($conexao, $funcao3);
                  mysqli_affected_rows($conexao);
                  $dados=mysqli_fetch_array($linhas);
                  if($dados['totquant']!=""){
                    echo $dados['totquant'];
                  }else{
                    echo 0;
                  }
              
              ?>

            </div>
            
          </div>
        </div>
          
        <div class="column">
          <div class="card">
            <div class="desc">Lucro</div>
             <div class="dnh"></div>
              <div class="valorLucro"><!--lucro-->
                <span class="cifrao">R$</span>

                <?php      
                  

                  $linhas=mysqli_query($conexao,  $funcao4);
                  mysqli_affected_rows($conexao);
                  $dados=mysqli_fetch_array($linhas);
                  
                    
                  
                  if($dados['lucro']!="" && $totVendido > 0){
                    
                    $lucro = $dados['lucro'];
                    $porc = ($lucro*100)/$totVendido;    
                    $porcLucro = number_format($porc,2,",",".");    
                      echo $dados['lucro'];
                    }else{
                      echo 0;
                      $porcLucro = 0;
                      }
              
              ?>
            
            </div>
                    <span class="porc">
                    <?php
                    if($dados['lucro']!=""){
                    echo $porcLucro."%";
                    }
                    ?>
                    </span>

          </div>
        </div>
      </div>


        <div class="tabelas">

          <div class="divmaisvendidos" id="customers">
                  <?php      
                  
        
                  $linhas=mysqli_query($conexao, $funcao5);
                  if(mysqli_affected_rows($conexao) > 0){
                          echo '<table class="tb" style="width:100%;margin: 0;font-weight:bold;">';
                          echo '<tr><td colspan="8" class="backRed">Produtos mais vendidos</td></tr>';
                          echo '<tr  class="backGray"><td>Codigo</td><td>Referencia</td><td>Marca</td><td>Cor</td><td>Modelo</td><td>Tamanho</td><td>Quantidade total</td><td>Valor Total</td></tr>';
                    while ($dados=mysqli_fetch_array($linhas)){
                      echo "<tr>";
                      echo "<td> ".$dados['codigo']."</td>";
                      echo "<td> ".$dados['referencia']."</td>";
                      echo "<td> ".$dados['marca']."</td>";
                      echo "<td> ".$dados['cor']."</td>";
                      echo "<td> ".$dados['modelo']."</td>";
                      echo "<td> ".$dados['tamanho']."</td>";
                      echo "<td> ".$dados['quant']."</td>";
                      echo "<td> ".$dados['valor']."</td>";
                      echo "</tr>";
                      

                    }
                  }else{
                      echo '<table class="tb" style="width:100%;margin: 0;font-weight:bold;">';
                          echo '<tr><td colspan="8" class="backRed">Produtos mais vendidos</td></tr>';
                          echo '<tr  class="backGray"><td>Codigo</td><td>Referencia</td><td>Marca</td><td>Cor</td><td>Modelo</td><td>Tamanho</td><td>Quantidade total</td><td>Valor Total</td></tr>';
                          echo '<tr><td colspan="8" style="text-align:center;">Sem registros.</td></tr>';

                        echo '</table>';
                  
                        }
                      
                  echo '</table>';
                ?>     
                </div>                
                
                <div class="formaPagamento" id="customers">            
                    <?php

                            $linhas=mysqli_query($conexao, $funcao6);
                            if(mysqli_affected_rows($conexao) > 0){
                              echo '<table class="tb2" border="1" style="font-weight:bold;">';
                              echo '<tr><td colspan="3" class="backRed">Forma de pagamento</td></tr>';
                              echo '<tr class="backGray"><td>Dinheiro</td><td>Débito</td><td>Crédito</td></tr>';
                              echo "<tr>"; 
                              while ($dados=mysqli_fetch_array($linhas)){
                              echo "<td> ".$dados['valor']."</td>";
                              }
                              echo "</tr>";
                            }else{
                                  echo '<table class="tb2" border="1" style="font-weight:bold;">';
                                  echo '<tr><td colspan="3" class="backRed">Forma de pagamento</td></tr>';
                                  echo '<tr class="backGray"><td>Dinheiro</td><td>Débito</td><td>Crédito</td></tr>';
                                  echo '<tr><td colspan="3" style="text-align:center;">Sem registros.</td></tr>';
                                  "</table>";
                                  
                            }
                        

                            echo "</table>";
                            ?>
                  </div>                
        

                <div class="clientes" id="customers">
                <?php
                              

                                    $linhas=mysqli_query($conexao, $funcao7);
                                    if(mysqli_affected_rows($conexao) > 0){
                                      echo '<table class="tb2" border="1" style="font-weight:bold;">';
                                      echo '<tr><td colspan="3" class="backRed">Clientes</td></tr>';
                                      echo '<tr class="backGray"><td>Nome</td><td>Quantidade</td><td>Valor</td></tr>';
                                            while ($dados=mysqli_fetch_array($linhas)){
                                              echo "<tr>"; 
                                              echo "<td> ".$dados['cliente']."</td>";
                                              echo "<td> ".$dados['quant']."</td>";
                                              echo "<td> ".$dados['valor']."</td>";
                                              echo "</tr>";
                                            }
                                    }else{
                                      echo '<table class="tb2" border="1" style="font-weight:bold;">';
                                      echo '<tr><td colspan="3" class="backRed">Clientes</td></tr>';
                                      echo '<tr class="backGray"><td>Nome</td><td>Quantidade</td><td>Valor</td></tr>';
                                      echo '<tr><td colspan="3" style="text-align:center;">Sem registros.</td></tr>';
                                      "</table>";
                                    }
                                

                                    echo "</table>";
                                  
                              ?>
                </div>



          <div class="quatrotabelas"  >
                <div class="um" id="customers">
                  <?php

                      

                        $linhascor=mysqli_query($conexao, $funcao8);
                        if(mysqli_affected_rows($conexao) > 0){
                          echo '<table class="tb2" border="1" style="font-weight:bold;">';
                          echo '<tr><td colspan="3" class="backRed">Cores</td></tr>';
                          echo '<tr class="backGray"><td>Cor</td><td>Quantidade</td><td>Valor</td></tr>';
                          while ($dadoscor=mysqli_fetch_array($linhascor)){
                            echo "<tr>";
                            echo "<td> ".$dadoscor['cor']."</td>";
                            echo "<td> ".$dadoscor['quant']."</td>";
                            echo "<td> ".$dadoscor['valor']."</td>";
                            echo "</tr>";
                            
                          }
                        }else{
                          echo '<table class="tb2" border="1" style="font-weight:bold;">';
                          echo '<tr><td colspan="3" class="backRed">Cores</td></tr>';
                          echo '<tr class="backGray"><td>Cor</td><td>Quantidade</td><td>Valor</td></tr>';
                          echo '<tr><td colspan="3" style="text-align:center;">Sem registros.</td></tr>';
                          "</table>";
                        }
                    
                        
                        
                        echo "</table>";
                        ?>

                  </div>    


              <div class="um" id="customers">
                <?php

                  

                      $linhastipo=mysqli_query($conexao, $funcao9);
                      if(mysqli_affected_rows($conexao) > 0){
                        echo '<table class="tb2" border="1" style="font-weight:bold;">';
                        echo '<tr><td colspan="3" class="backRed">Modelos</td></tr>';
                        echo '<tr class="backGray"><td>Modelo</td><td>Quantidade</td><td>Valor</td></tr>';
                        while ($dadostipo=mysqli_fetch_array($linhastipo)){
                          echo "<tr>";
                          echo "<td> ".$dadostipo['modelo']."</td>";
                          echo "<td> ".$dadostipo['quant']."</td>";
                          echo "<td> ".$dadostipo['valor']."</td>";
                          echo "</tr>";
                          
                        }
                      }else{
                        echo '<table class="tb2" border="1" style="font-weight:bold;">';
                        echo '<tr><td colspan="3" class="backRed">Modelos</td></tr>';
                        echo '<tr class="backGray"><td>Modelo</td><td>Quantidade</td><td>Valor</td></tr>';
                        echo '<tr><td colspan="3" style="text-align:center;">Sem registros.</td></tr>';
                        "</table>";
                      }
                  
                      

                      echo "</table>";
                  
                ?>
              </div>
              
                <div class="um" id="customers">
                  <?php

                  

                        $linhasmarca=mysqli_query($conexao, $funcao10);
                        if(mysqli_affected_rows($conexao) > 0){
                          echo '<table class="tb2" border="1" style="font-weight:bold;">';
                          echo '<tr><td colspan="3" class="backRed">Marcas</td></tr>';
                          echo '<tr class="backGray"><td>Marca</td><td>Quantidade</td><td>Valor</td></tr>';
                          while ($dadosmarca=mysqli_fetch_array($linhasmarca)){
                            echo "<tr>";
                            echo "<td> ".$dadosmarca['marca']."</td>";
                            echo "<td> ".$dadosmarca['quant']."</td>";
                            echo "<td> ".$dadosmarca['valor']."</td>";
                            echo "</tr>";
                            
                          }
                        }else{
                          echo '<table class="tb2" border="1" style="font-weight:bold;">';
                          echo '<tr><td colspan="3" class="backRed">Marcas</td></tr>';
                          echo '<tr class="backGray"><td>Marca</td><td>Quantidade</td><td>Valor</td></tr>';
                          echo '<tr><td colspan="3" style="text-align:center;">Sem registros.</td></tr>';
                          "</table>";
                        }
                    
                        
                        
                        echo "</table>";
                  ?>
                </div>

              <div class="um" id="customers">
                <?php

              

                      $linhastamanho=mysqli_query($conexao, $funcao11);
                      if(mysqli_affected_rows($conexao) > 0){
                        echo '<table class="tb2" border="1" style="font-weight:bold;">';
                        echo '<tr><td colspan="3" class="backRed">Tamanhos</td></tr>';
                        echo '<tr class="backGray"><td>Tamanho</td><td>Quantidade</td><td>Valor</td></tr>';
                        while ($dadostamanho=mysqli_fetch_array($linhastamanho)){
                          echo "<tr>";
                          echo "<td> ".$dadostamanho['tamanho']."</td>";
                          echo "<td> ".$dadostamanho['quant']."</td>";
                          echo "<td> ".$dadostamanho['valor']."</td>";
                          echo "</tr>";
                          
                        }
                      }else{
                        echo '<table class="tb2" border="1" style="font-weight:bold;">';
                        echo '<tr><td colspan="3" class="backRed">Tamanhos</td></tr>';
                        echo '<tr class="backGray"><td>Tamanho</td><td>Quantidade</td><td>Valor</td></tr>';
                        echo '<tr><td colspan="3" style="text-align:center;">Sem registros.</td></tr>';
                        "</table>";
                      }
                  
                  
        
                      echo "</table>";
                ?>
            </div>

        
        
            </div>             
        </div>    
      </div>

  <?php
        
      }                 
  }
  ?>

<script type="text/javascript">

if ( $( ".divErro" ).is( ":hidden" ) ) {
  $( ".divErro" ).slideDown(1000);
}
else {
  $( "#divErro" ).hide();
}



$('#x').click(function(){
  if ( $(".divErro").slideUp(1000)) {

  }
  return true;
});
</script>

  </body>
</html>




