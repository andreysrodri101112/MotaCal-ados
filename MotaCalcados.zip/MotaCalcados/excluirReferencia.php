<div id="c2" class="containerTab" >
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
  
    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-50">
          <label for="cname">Marca</label>
          <select class="form-control" name="marca" id="marca" style="height:75%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT tb_referencia.cd_marca as codigo,tb_marca.nm_marca as nome from tb_referencia,tb_marca 
              where tb_marca.cd_marca=tb_referencia.cd_marca
              group by tb_referencia.cd_marca";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['nome'].'</option>';
                  }       
              }  
            ?>
          </select>

        </div>

        <div class="col-50">
          <label for="cname">Referência</label>
          <select class="form-control" name="ref" id="ref" style="height:75%;">
            <option value=""></option>
          </select>
          <script type="text/javascript">
                                $('#marca').on("change",function(){
                                    var codigo = $('#marca').val();                                     
                                            $.ajax({
                                            type: "GET", //método escolhido
                                            url: "busca_referencia.php?cod="+codigo, //arquivo php chamado                        
                                            dataType: "html",//tipo de função a ser retornada
                                                beforeSend: function(){
                                                    $("#bt").text("Carregando...");
                                                },
                                                error: function(){
                                                    $("#data").html("Erro ao carregar HTML! Tente de novo!");
                                                },
                                                success: function(html){
                                                    $("#ref").html(html);

                                                }
                                            });

                                });
            </script>

        </div>

      </div>
      <br>
      <br>
    

      <input type="submit" value="Excluir" class="btn" name="btnExcluirReferencia" id="excluir">

    </form>
  
</div>


<?php



if(isset($_POST['btnExcluirReferencia'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['marca'] == ""){
        $vazio = 1;
    }else if($_POST['ref'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $marca = $_POST['marca'];
        $ref = $_POST['ref'];
                    
                $query = "DELETE FROM tb_referencia WHERE cd_marca=$marca  AND cd_referencia=$ref";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Referencia excluída com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaExclusao.php' />";

                    }  
            
                
            }     
            
    

   
}

?>    