<div id="c2" class="containerTab" style="display:none;background:#F5F5F5;height:50%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
  
    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-50">
          <label for="cname">Marca</label>
          <select class="form-control" name="marcaReferencia" id="marca" style="height:80%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT tb_referencia.cd_marca as codigo,tb_marca.nm_marca as nome from tb_referencia,tb_marca 
              where tb_marca.cd_marca=tb_referencia.cd_marca
              group by tb_referencia.cd_marca";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['codigo'].'">'.$dados['nome'].'</option>';
                  }       
              }  
            ?>
          </select>

        </div>

        <div class="col-50">
          <label for="cname">Referência</label>
          <select class="form-control" name="ref" id="ref" style="height:80%;">
            <option value=""></option>
          </select>
          <script type="text/javascript">
                                $('#marca').on("change",function(){
                                    var codigo = $('#marca').val();
                                            
                                            $.ajax({    
                                            type: "GET", //método escolhido
                                            url: "busca_todasReferencia.php?cod="+codigo, //arquivo php chamado                        
                                            dataType: "html",//tipo de função a ser retornada
                                                beforeSend: function(){
                                                    $("#bt").text("Carregando...");
                                                },
                                                error: function(){
                                                    $("#ref").html("Erro ao carregar HTML! Tente de novo!");
                                                },
                                                success: function(html){
                                                    $("#ref").html(html);
                                                    
                                                    
                                                }
                                            });

                                });
            </script>

        </div>

      </div>
      <br>
      <br>
      <div class="row">
    

        <div class="col-50">
          <label for="cname">Nova Referência</label>
          <input class="form-control" name="novaReferencia" style="height:80%;" maxlength="30">

        </div>
      </div>

      <input type="submit" value="Atualizar" class="btn"name="btnAtualizarReferencia" style="background:#00E676;width:50%;margin-left:25%;margin-top:5%;">

    </form>
  
</div>

<?php

if(isset($_POST['btnAtualizarReferencia'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['marcaReferencia'] == ""){
        $vazio = 1;
    }else if($_POST['ref'] == ""){
        $vazio = 1;
    }else if($_POST['novaReferencia'] == ""){
      $vazio = 1;
    }
    $consulta = "SELECT Desc_Referencia as Referencia FROM TB_Referencia 
    WHERE Desc_Referencia="."'".$_POST['novaReferencia']."'"." 
    and cd_marca ="."'".$_POST['marcaReferencia']."'";
    
    $linhas=mysqli_query($conexao, $consulta);
    mysqli_num_rows($linhas);
    $dados=mysqli_fetch_array($linhas);
    $exists = $dados['Referencia'];
    

    if($vazio > 0){
    echo "<div class='divErro'>
    <p>Preencha todos os campos</p>
    <div id='x'>X</div>
    </div>";
    }else if($exists != ""){
    echo "<div class='divErro'>
    <p>Referencia já existente!</p>
    <div id='x'>X</div>
    </div>";     
    }else{
        $novaReferencia = $_POST['novaReferencia'];
        $ref = $_POST['ref'];
        
        

            
                $query = "UPDATE TB_Referencia SET desc_referencia='$novaReferencia'
                where cd_referencia=$ref
                ";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Referencia atualizada com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaEdicao.php' />";

                        

                    }  
            
                
            }     
            
    

   
}

?>    