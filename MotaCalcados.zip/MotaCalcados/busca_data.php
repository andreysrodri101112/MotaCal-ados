<?php



  $conexao = mysqli_connect("localhost","root","","tcc");
  if (!$conexao) {
    die("Erro".mysql_error());

  }

                    $html = "";
                    echo $_GET['cod'];

                    $consulta = "SELECT dt_entrada as dataEntrada FROM tb_entrada where cd_produto=". $_GET['cod'];
                    echo $consulta;                    
                    $linhas=mysqli_query($conexao, $consulta);
                    if(mysqli_affected_rows($conexao) > 0){
                      while ($dados=mysqli_fetch_array($linhas)){
                        
        $options ="<option value='".$dados['dataEntrada']."'>".$dados['dataEntrada']."</option>";
        echo $options; // com o echo, o valor da variável é o retorno da minha função ajax do tipo HTML.
        
   
       // com o echo, o valor da variável é o retorno da minha função ajax do tipo HTML.


}
}




 ?>
