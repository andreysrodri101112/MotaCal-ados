<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}

?>


<div id="c1" class="containerTab" style="display:none;background:#F5F5F5;height:60%;">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
  
    <form class="" action="#" method="post">
    <div class="row">
        <div class="col-50">
          <label for="cname">Código</label>
          <select class="form-control" name="codigoEntrada" id="codigo" style="height:80%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT cd_produto from tb_entrada group by cd_produto";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['cd_produto'].'">'.$dados['cd_produto'].'</option>';
                  }       
              }  
            ?>
          </select>

        </div>

        <div class="col-50">
          <label for="cname">Data</label>
          <select class="form-control" name="dataEntrada" id="data" style="height:80%;">
         </select>
         <script type="text/javascript">
                                $('#codigo').on("change",function(){
                                    var codigo = $('#codigo').val();                                     
                                            $.ajax({
                                            type: "GET", //método escolhido
                                            url: "busca_data.php?cod="+codigo, //arquivo php chamado                        
                                            dataType: "html",//tipo de função a ser retornada
                                                beforeSend: function(){
                                                    $("#bt").text("Carregando...");
                                                },
                                                error: function(){
                                                    $("#data").html("Erro ao carregar HTML! Tente de novo!");
                                                },
                                                success: function(html){
                                                    $("#data").html(html);

                                                }
                                            });

                                });
            </script>   
        </div>

      </div>
      <br>
      <br>
      <div class="row">
        <div class="col-50">
          <label for="cname">Quantidade</label>
          <input class="form-control" name="qtEntrada" style="height:80%;" maxlength="2">
        </div>

        <div class="col-50">
          <label for="cname">Valor</label>
          <input class="form-control" name="valorEntrada" style="height:80%;" maxlength="6">

        </div>
      </div>
    <input type="submit" value="Atualizar" class="btn" name="btnAtualizarEntrada" style="background:#00E676;width:50%;margin-left:25%;margin-top:5%;">


  </form>
</div>


<?php

if(isset($_POST['btnAtualizarEntrada'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['codigoEntrada'] == ""){
        $vazio = 1;
    }else if($_POST['dataEntrada'] == ""){
        $vazio = 1;
    }else if($_POST['qtEntrada'] == ""){
      $vazio = 1;
    }else if($_POST['valorEntrada'] == ""){
      $vazio = 1;
    }

    
    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['codigoEntrada'];
        $data = $_POST['dataEntrada'];
        $qt = $_POST['qtEntrada'];
        $valor = $_POST['valorEntrada'];
        

            
                $query = "UPDATE TB_ENTRADA SET vl_compra=$valor,qt_compra=$qt
                where cd_produto=$codigo and dt_entrada='$data'
                ";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Entrada atualizada com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=paginaEdicao.php' />";

                        

                    }  
            
                
            }     
            
    

   
}

?>    