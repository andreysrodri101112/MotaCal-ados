<div id="c6" class="containerTab" style="display:none;background:#F5F5F5;height:60%;">
    <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
    <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
    <br>
    <br>
      <form class="" action="#" method="post">

        <div class="row">
              <div class="col-50">
                <label for="cname">Nome</label>
                <input type="text" name="nomeCliente" value="" maxlength="60">
              </div>

              
                  <div class="col-25">
                    <label for="state">CEP</label>
                    <input type="text" id="state" name="cep" maxlength="8">
                  </div>
                  <div class="col-25">
                    <label for="zip">CPF</label>
                    <input type="text" id="zip" name="cpf" maxlength="11">
                  </div>
              
          </div>

      <div class="row">
                  <div class="col-50">
                    <label for="cname">Email *</label>
                    <input type="text" name="email" value="" maxlength="60">
                  </div>
         
                  <div class="col-25">
                    <label for="state">Telefone *</label>
                    <input type="text" id="state" name="telefone" maxlength="11">
                  </div>
                  <div class="col-25">
                    <label for="zip">Data Aniversário *</label>
                    <input type="text" class="datepicker" id="zip" name="aniver" >
                  </div>
          
      </div>


      <input type="submit" value="Cadastrar" class="btn" name="cadastrarCliente" id="btnCadastrar">

    </form>
  </div>
  </div>

  
<?php



if(isset($_POST['cadastrarCliente'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['nomeCliente'] == ""){
        $vazio = 1;
    }else if($_POST['cep'] == ""){
        $vazio = 1;
    }else if($_POST['cpf'] == ""){
        $vazio = 1;
    }else if($_POST['email'] == ""){
        $vazio = 1;
    }else if($_POST['telefone'] == ""){
      $vazio = 1;
    }else if($_POST['aniver'] == ""){
    $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $nome = $_POST['nomeCliente'];
        $cpf = $_POST['cpf'];
        $cep = $_POST['cep'];
        $email = $_POST['email'];
        $tel = $_POST['telefone'];
        $dt = $_POST['aniver'];

        $nova_data = explode("/", $dt);
        $dataAniver = $nova_data[2] . "-" . $nova_data[1] . "-" . $nova_data[0];

            $consulta = "SELECT count(cpf) as cont from tb_cliente WHERE cpf=".$cpf;
            echo "<script>alert($consulta);</script>";
            $linhas=mysqli_query($conexao, $consulta);
            if(mysqli_num_rows($linhas) > 0){
                while ($dados=mysqli_fetch_array($linhas)){
                        if($dados['cont'] > 0){
                            $erro = 1;
                        }
                }       
            }else{
             $erro = 0; 
            }
            

            if($erro == 0) {
              
            
                $query = "INSERT INTO `tb_cliente`(`nm_cliente`,`ds_email`,`tl_telefone`,`cep`,`cpf`,`dt_aniversario`)
                 VALUES('$nome','$email','$tel','$cep','$cpf','$dataAniver')";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao inserir".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Cliente cadastrado com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url=cadastroNovo.php' />";

                    }  
            }else{
                echo "<div class='divErro'>
                <p>Cliente já cadastrado com este CPF</p>
                <div id='x'>X</div>
                </div>";
            }     
            
    

    }
}

?>    