<?php

function consultaVendas($tipoConsulta, $p1 = '',$p2 = ''){
        
    
    if($tipoConsulta == "vendasEspecifico"){
            $consulta = "SELECT 
            id_venda as id,
            fl_operacao as op,
            vl_venda as valor,
            dt_operacao as data_venda,
            (SELECT nm_cliente FROM tb_cliente WHERE cd_cliente=tb_venda.cd_cliente) as cliente 
            FROM tb_venda WHERE dt_operacao='$p1'";
            

        return $consulta;

        }
        
        else if($tipoConsulta == "vendasIntervalo"){
                $consulta = "SELECT 
                id_venda as id,
                fl_operacao as op,
                vl_venda as valor,
                dt_operacao as data_venda,
                (SELECT nm_cliente FROM tb_cliente WHERE cd_cliente=tb_venda.cd_cliente) as cliente 
                FROM tb_venda WHERE dt_operacao BETWEEN '$p1' AND '$p2'";
        
        return $consulta;
        }
        
        else if($tipoConsulta == "vendasMes"){
            $consulta = "SELECT 
            id_venda as id,
            fl_operacao as op,
            vl_venda as valor,
            dt_operacao as data_venda,
            (SELECT nm_cliente FROM tb_cliente WHERE cd_cliente=tb_venda.cd_cliente) as cliente 
            FROM tb_venda WHERE MONTH(tb_venda.dt_operacao) = '$p1' AND YEAR(tb_venda.dt_operacao) = '$p2'";
    
        return $consulta;
        }
        
        else if($tipoConsulta == "vendasTrimestre"){
            $consulta = "SELECT 
            id_venda as id,
            fl_operacao as op,
            vl_venda as valor,
            dt_operacao as data_venda,
            (SELECT nm_cliente FROM tb_cliente WHERE cd_cliente=tb_venda.cd_cliente) as cliente 
            FROM tb_venda WHERE dt_operacao $p1";

        return $consulta;
        }
        else if($tipoConsulta == "vendasHoje"){
            $consulta = "SELECT 
            id_venda as id,
            fl_operacao as op,
            vl_venda as valor,
            dt_operacao as data_venda,
            (SELECT nm_cliente FROM tb_cliente WHERE cd_cliente=tb_venda.cd_cliente) as cliente 
            FROM tb_venda WHERE DATE_FORMAT(dt_operacao, '%Y-%m-%d') = CURDATE() order by dt_operacao desc";

        return $consulta;
        }
        else if($tipoConsulta == "vendasAno"){
            $consulta = "SELECT 
            id_venda as id,
            fl_operacao as op,
            vl_venda as valor,
            dt_operacao as data_venda,
            (SELECT nm_cliente FROM tb_cliente WHERE cd_cliente=tb_venda.cd_cliente) as cliente 
            FROM tb_venda
            WHERE YEAR(tb_venda.dt_operacao) = '$p1'";

        return $consulta;
        }
}





function consultaQtCdVenda($id){
    
    $consulta = "SELECT qt_venda,cd_produto from tb_itemvenda where id_venda=".$id;


return $consulta;
 
}





function consultaProdutosVenda($cd_produto){
    
        $consulta = "SELECT 
       tb_produto.cd_produto as codigo,
       (SELECT nm_cor FROM tb_cor where cd_cor=(tb_produto.cd_cor)) as cor,
       (SELECT nm_marca FROM tb_marca where cd_marca=(tb_produto.cd_marca)) as marca,
       (SELECT nm_tipoproduto FROM tb_tipoproduto where cd_tipoproduto=(tb_produto.cd_tipoproduto)) as modelo,
       tb_produto.tm_tamanho as tamanho,
       vl_venda as valor
       FROM tb_produto
       WHERE cd_produto=".$cd_produto;

    return $consulta;
     
}


?>