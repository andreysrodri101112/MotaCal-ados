<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style/not/index.css">
</head>
<body>



<div class="mota">
  Mota Calçados
</div>
<div class="login">


<form class="login" action="index.php" method="post" id="testao">
  <div class="form-group">

    <div style="width:100%;text-align:left">
      <label for="nome" align="center">Usuário:</label>
        <input type="text" name="user" class="form-control" id="exampleInputEmail1" placeholder="Nome do usuário" style="text-transform:uppercase" >
    </div>

  </div>

  <div class="form-group">
    <label for="nome" align="center">Senha:</label>
    <input type="password" name="senha" class="form-control" id="exampleInputPassword1" placeholder="Senha" style="text-transform:uppercase" >
  </div>
  <!-- <a href="logado.html"><button type="submit" class="btn">Entrar</button></a> -->
  <input type="submit" class="btn" id="b" name="login" value="Entrar">


</form>

</div>



<?php
if (isset($_POST['login'])) {


  if ($_POST['user']=="" || $_POST['senha']=="") {
    // echo "<script>alert('Preencha todos os campos')</script>";
    echo "<div class='divErro'>
    <p>Preencha todos os campos</p>
    <div id='x'>X</div>
    </div>";

  }else {
    // echo $_POST['user'];
    // echo $_POST['senha'];
    if (trim($_POST['user'])=="adm" && trim($_POST['senha'])=="123") {
      $username = $_POST['user'];
      session_start();
      $_SESSION['username'] = $username;
      header("Location:cadastroNovo.php");

    }else if (trim($_POST['user'])=="func" && trim($_POST['senha'])=="123") {
      $username = $_POST['user'];
      session_start();
      $_SESSION['username'] = $username;
      header("Location:listagemFuncionario.php");
    }else {
      echo "<div class='divErro'>
      <p>O nome de usuário e a senha fornecidos não correspondem às informações em nossos registros. Verifique-as e tente novamente</p>
      <div id='x'>X</div>
      </div>";


    }
  }

}


?>


<script type="text/javascript">

if ( $( ".divErro" ).is( ":hidden" ) ) {
  $( ".divErro" ).slideDown(1000);
}
else {
  $( "#divErro" ).hide();
}


$('#x').click(function(){
  if ( $(".divErro").slideUp(1000)) {
  }
  return true;
});
</script>
<style media="screen">


</style>
</body>
</html>
