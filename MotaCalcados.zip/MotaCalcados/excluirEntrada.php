<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}
?>
<div id="c1" class="containerTab" >
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <!-- <h2 style="text-align:center;">Informações complementares</h2> -->
  <br>
  <br>
  
    <form class="" action="#" method="post">

      <div class="row">
        <div class="col-50">
          <label for="cname">Codigo</label>
          <select class="form-control" name="codigoEntrada" id="codigo" style="height:75%;">
            <option value=""></option>
            <?php
              $consulta = "SELECT cd_produto from tb_entrada group by cd_produto";
              $linhas=mysqli_query($conexao, $consulta);
              if(mysqli_num_rows($linhas) > 0){
                  while ($dados=mysqli_fetch_array($linhas)){
                    echo '<option value="'.$dados['cd_produto'].'">'.$dados['cd_produto'].'</option>';
                  }       
              }  
            ?>

          </select>

        </div>
          <div class="col-50">
            <label for="zip" >Data</label>
            <select class="form-control" name="dataEntrada" id="data" style="height:75%;">
            <option value=""></option>
            </select>
            <script type="text/javascript">
                                $('#codigo').on("change",function(){
                                    var codigo = $('#codigo').val();                                     
                                            $.ajax({
                                            type: "GET", //método escolhido
                                            url: "busca_data.php?cod="+codigo, //arquivo php chamado                        
                                            dataType: "html",//tipo de função a ser retornada
                                                beforeSend: function(){
                                                    $("#bt").text("Carregando...");
                                                },
                                                error: function(){
                                                    $("#data").html("Erro ao carregar HTML! Tente de novo!");
                                                },
                                                success: function(html){
                                                    $("#data").html(html);

                                                }
                                            });

                                });
            </script> 
          </div>
    </div>
      
  
    <input type="submit" value="Excluir" class="btn" name="btnExcluirEntrada" id="excluir">


  </form>
</div>



<?php



if(isset($_POST['btnExcluirEntrada'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['codigoEntrada'] == ""){
        $vazio = 1;
    }else if($_POST['dataEntrada'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['codigoEntrada'];
        $data = $_POST['dataEntrada'];
        

            
                $query = "DELETE FROM tb_entrada where cd_produto=$codigo  AND dt_entrada='$data'";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Entrada excluída com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='0;url=paginaExclusao.php' />";

                    }  
            
                
            }     
            
    

   
}

?>    