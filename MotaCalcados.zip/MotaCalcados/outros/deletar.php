<?php

$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}


$consult = "DELETE  FROM produto WHERE codigo=".$_POST['id'];
if (!mysqli_query($conexao, $consult)) {
  echo "erro ao deletar".$consult."<br><br><br>";
  echo "code: | ".mysqli_errno($conexao)." |";
}else {
    header("Location:listagem.php");


}


echo $_POST['id'];

 ?>
