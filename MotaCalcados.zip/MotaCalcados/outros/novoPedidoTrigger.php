

<?php

session_start();
// if (isset($_SESSION['username'])) {
//   echo $_SESSION['username'];
// }else {
// echo "nao deu nada";
// }

$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}
$soma=0;

if (isset($_POST['add'])) {
  $produto = $_POST['produto'];
  $quant = $_POST['quant'];



    date_default_timezone_set('America/Sao_paulo');
    $data = date('Y-m-d H:i:s');
    $dataa = date('Y-m-d ');




      //teste de quantidade
      // echo "produtos adicionados no pedido:". $quant_adicionada."<br>produtos no estoque: $quant_estoque<br>quan solic: $quant<br>";
      // $quant_pedido = $dados12['totpedido'];
      // echo $dados12['totpedido'];

      $query = "INSERT INTO temp_venda (cod_pedido,cod_produto,data_pedido,quant_pedido) VALUES ('2','$produto','$data','$quant')";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";
        // echo "$query";
      }




}





//listagem dos pedidos que estao sendoa adicionados
// $consulta1 = "SELECT cod_pedido FROM pedido ORDER BY cod_pedido DESC LIMIT 1";
// $linhas1=mysqli_query($conexao, $consulta1);
// if(mysqli_num_rows($linhas1) > 0){
//   while ($dados1=mysqli_fetch_array($linhas1)){
//     $ultimo = $dados1['cod_pedido'];
//     echo "$ultimo";


    $consulta3 = "SELECT sum(quant_pedido) as tot,produto.* from produto,temp_venda
    where produto.codigo=temp_venda.cod_produto and cod_pedido=1 group by cod_produto";
    echo "<table class='table table-bordered'>";
    echo "<tr class='corlinha' class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Tipo</td><td>Valor</td><td>Data de Entrada</td><td class='quant'>Quantidade</td></tr>";
    $linhas3=mysqli_query($conexao, $consulta3);
    if(mysqli_num_rows($linhas3) > 0){
      while ($dadosmf=mysqli_fetch_array($linhas3)){


        echo "<tr><td>".$dadosmf['codigo']."</td>";
        echo "<td>".$dadosmf['referencia']."</td>";
        echo "<td>".$dadosmf['marca']."</td>";
        echo "<td>".$dadosmf['tamanho']."</td>";
        echo "<td>".$dadosmf['cor']."</td>";
        echo "<td>".$dadosmf['genero']."</td>";
        echo "<td>".$dadosmf['tipo']."</td>";
        echo "<td>".$dadosmf['valor']."</td>";
        echo "<td>".$dadosmf['data_entrada']."</td>";
        echo "<td >".$dadosmf['tot']."</td>";
        echo "</tr>";


    }
  }


//   }
// }





if (isset($_POST['f'])) {

//valor do pedido
  $consultt = "SELECT SUM(produto.valor * pedido_produto.quant_pedido) AS total FROM pedido_produto LEFT JOIN produto
  ON pedido_produto.cod_produto = produto.codigo WHERE cod_pedido=$ultimo";

  $linhastt=mysqli_query($conexao, $consultt);
  mysqli_num_rows($linhastt);
  $dadostt=mysqli_fetch_array($linhastt);
  $total = $dadostt['total'];

  // echo "Valor Total:".$dadostt['total'];

  $query = "UPDATE pedido_produto SET valor_pedido=$total  where cod_pedido=$ultimo";
  if (!mysqli_query($conexao, $query)) {
    echo "erro ao inserir".$query."<br><br><br>";
    echo "code: | ".mysqli_errno($conexao)." |";
  }

//opcao do pedido
  $op = $_POST['op'];
  if ($_POST['op']=="") {
    echo "<script>alert('Escolha uma opção de pagamento!')</script>";
  }else {

    if ($_POST['op']=="Credito") {
      $query = "UPDATE pedido_produto SET pagamento='$op' where cod_pedido=$ultimo";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";
      }
    }else{
      $query = "UPDATE pedido_produto SET pagamento='$op' where cod_pedido=$ultimo";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";
      }
    }




    if ($_SESSION['username']=="funcionario") {
      // echo $_SESSION['username'];
      header("Location:listagemFuncionario.php");
    }elseif ($_SESSION['username']=="adm") {
      header("Location:listaPedidosNovo.php");
    }
  } //chave else
} //chave finalizar







if (isset($_POST['cancelar'])) {
?>
<?php
// exit;
// echo "a";

$consult = "DELETE FROM pedido_produto WHERE cod_pedido=$ultimo";
if (!mysqli_query($conexao, $consult)) {
  echo "erro ao inserir".$consult."<br><br><br>";
  echo "code: | ".mysqli_errno($conexao)." |";
}else {
  // echo "EXCLUIU";
  if ($_SESSION['username']=="funcionario") {
    // echo $_SESSION['username'];
    header("Location:listagemFuncionario.php");
  }elseif ($_SESSION['username']=="adm") {
    header("Location:listaPedidosNovo.php");
  }

}


if (isset($_POST['nao'])) {
  echo "nao";
}


}
?>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
</head>

<body>

</form>
<div class="add">

<form action="#" method="post">
  <span class="fontes">Código:</span><input class="pedido" type="number" name="produto" value="" required>
  <!-- <input type="submit" class="btn btn-defaulta" name="verificar" value="Verificar"> -->

  <span class="fontes">Quantidade:</span><input class="" type="number" name="quant" value="" required>

  <button type="submit" class="btn btn-default" name="add">Adicionar</button>

</form>
</div>

<form class="" action="#" method="post">

  <div class="finalizar">

    <div class="maxl">
      <label class="radio inline">
        <input type="radio" name="op" value="dinheiro" checked>
        <span> Dinheiro </span>
      </label>
      <label class="radio inline">
        <input type="radio" name="op" value="debito">
        <span>Débito </span>
      </label>
      <label class="radio inline">
        <input type="radio" name="op" value="credito">
        <span>Crédito </span>
      </label>
    </div>

    <div class="total">
      <?php
      $consultsoma = "SELECT SUM(produto.valor * temp_venda.quant_pedido) AS somatotal FROM temp_venda LEFT JOIN produto
ON temp_venda.cod_produto = produto.codigo WHERE cod_pedido=1";

      $linhasoma=mysqli_query($conexao, $consultsoma);
      mysqli_num_rows($linhasoma);
        $dadosoma=mysqli_fetch_array($linhasoma);
          $somatotal= $dadosoma['somatotal'];

      echo "Valor Total:".$somatotal;



      // botarb o total position absolute e o finalizar relative
      ?>
    </div>
  </div>


  <button type="submit" class="btn btn-defaultf" name="f">Finalizar</button>
</form>
<button type="button" class="btn btn-primaryy" data-toggle="modal" data-target="#exampleModalCenter">
Cancelar Pedido</button>


<style media="screen">
.total{
  /* background-color: red; */
  width: 40px;
  /* height: 40px; */
}
input{
  text-transform: uppercase;
}
</style>

<?php

?>




<script type="text/javascript">

if ( $( ".divErro" ).is( ":hidden" ) ) {
  $( ".divErro" ).slideDown(1000);
}
else {
  $( "#divErro" ).hide();
}



$('#x').click(function(){
  if ( $(".divErro").slideUp(1000)) {

  }
  return true;
});
</script>

<style media="screen">

.divErro{

  background-color: white;
  position: absolute;
  top: 0;
  left: 25%;
  width: 50%;
  height: 15%;

  border-top: 0;

  border-color: #bdc3c7;;
  border-style: solid;


  /* display: none; */
  /*visibility: hidden;*/
  border-radius: 0 0 8px 8px ;

}
#x{
  position: absolute;
  right: 2%;
  top: 5%;
  color: #7f8c8d;
}
#x:hover{
  cursor: pointer;
  color: black;

}
p{
  text-align: center;
  color:#bdc3c7;
  font-family: arial;
  font-weight: 500;
  position: relative;
  top: 35%;


}
</style>

<style media="screen">
.quant{
  background-color: #00C853;

}
.total{
  font-size: 150%;
  font-weight: 600;
  width: 200px;
  height: 30px;
  /* background-color: red; */
  position: absolute;
  top: 27%;
  left: 55%;
  color: #999;

}

.finalizar{
  margin-left: 18%;
  margin-top:4%;
  width: 50%;
  height: 10%;
  background-color:#ECEFF1;
  border-radius: 10px;
  /* text-align: center; */

}
.maxl{
  margin:25px ;
}
.inline{
  display: inline-block;
}
.inline + .inline{
  margin-left:10px;
}
.radio{
  color:#999;
  font-size:15px;
  position:relative;
  margin-left: 5%;
  margin-top: 3%;
}
.radio span{
  position:relative;
  padding-left:20px;
}
.radio span:after{
  content:'';
  width:15px;
  height:15px;
  border:3px solid;
  position:absolute;
  left:0;
  top:1px;
  border-radius:100%;
  -ms-border-radius:100%;
  -moz-border-radius:100%;
  -webkit-border-radius:100%;
  box-sizing:border-box;
  -ms-box-sizing:border-box;
  -moz-box-sizing:border-box;
  -webkit-box-sizing:border-box;
}
.radio input[type="radio"]{
  cursor: pointer;
  position:absolute;
  width:100%;
  height:100%;
  z-index: 1;
  opacity: 0;
  filter: alpha(opacity=0);
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"
}
.radio input[type="radio"]:checked + span{
  color: #D32F2F;
}
.radio input[type="radio"]:checked + span:before{
  content:'';
  width:5px;
  height:5px;
  position:absolute;
}
.table{
  width: 70%;
  margin-top: 5%;
  margin-left: 15%;
  /* position: absolute; */
  /* top:40%; */
}
.corlinha{
  background-color: #D32F2F;
}

.btn-default{
  background-color: #00C853;
}
.btn-defaulta{
  background-color: #7f8c8d;
}
.btn-defaultf{
  height: 5%;
  width: 15%;
  background-color: #D32F2F;
  position: absolute;
  top:23.5%;
  left: 70%;
}
.btn-primaryy{
  margin-top: 3%;
  height: 5%;
  width: 15%;
  /* background-color: #D32F2F; */
  position: absolute;
  top:23.5%;
  left: 70%;
}
.f{
}
.add{
  margin-left: 30%;
  margin-top: 5%;
}

</style>





</body>
</html>
