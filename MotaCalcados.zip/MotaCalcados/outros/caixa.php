
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
</head>

<body>




  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Mota Calçados</a>
      </div>
      <ul class="nav navbar-nav">
        <!-- <li class="active"><a href="paginaAdm.php">Home</a></li> -->
        <li><a href="cadastro.php">Cadastro</a></li>
        <li><a href="listagem.php">Produtos</a></li>
        <li><a href="caixa.php">Pedidos</a></li>
        <li><a href="listaPedidos.php">Vendas</a></li>


        <!-- <li><a href="#">Page 3</a></li> -->
      </ul>
    </div>
  </nav>

  <!-- <form class="" action="caixa.php" method="post">

    <input type="submit" class="btnadd" name="btnadd" value="Adicionar pedido">
  </form>

  <form class="add" action="caixa.php" method="post">
    <span class="fontes">Código:</span><input class="pedido" type="number" name="produto" value="">
    <input type="submit" name="verificar" value="Verificar">

    <span class="fontes">Quantidade:</span><input class="" type="number" name="quant" value="">
    <input type="submit" name="add" class="btnpedido" value="Adicionar produto">
  </form>
 -->

  <?php

  $conexao = mysqli_connect("localhost","root","","tcc");
  if (!$conexao) {
    die("Erro".mysql_error());

  }


  if (isset($_POST['btnadd'])) {
    $query = 'INSERT INTO pedido () VALUES ()';
    if (!mysqli_query($conexao, $query)) {
      echo "erro ao inserir " . $query;
    }else {
      echo "insira";
    }
  }

  //verifica a quantidade de produtos disponiveis para adicionar

  $quant = 0;
  $novaquant=0;


  if (isset($_POST['add'])) {
    $produto = $_POST['produto'];
    $quant = $_POST['quant'];
    if ($_POST['produto']=="" || $_POST['quant']=="") {
      echo "<script>alert('Preencha todos os campos!')</script>";
    }else{




      $produto = $_POST['produto'];

      $consulta = "SELECT codigo,quantidade FROM produto where codigo=$produto";
      $linhas=mysqli_query($conexao, $consulta);
      mysqli_num_rows($linhas);
      $dados=mysqli_fetch_array($linhas);
      if ($dados['codigo']=="" || $dados['quantidade']<0) {
        echo "<script>alert('Produto Indisponível')</script>";

      }else {



        date_default_timezone_set('America/Sao_paulo');
        $data = date('Y-m-d H:i:s');
        $dataa = date('Y-m-d ');


        //verifica se nao tem mais produtos no pedido no que no estoque

        //pega o ultimo pedido da lista
        $consulta13 = "SELECT cod_pedido FROM pedido ORDER BY cod_pedido DESC LIMIT 1";
        $linhas13=mysqli_query($conexao, $consulta13);
        mysqli_num_rows($linhas13);
        $dados13=mysqli_fetch_array($linhas13);
        $ultimo = $dados13['cod_pedido'];
        //seleciona a quantidade de produtos daquele codigo no estoque
        $consulta11 = "SELECT quantidade FROM produto where codigo=$produto";
        $linhas11=mysqli_query($conexao, $consulta11);
        mysqli_num_rows($linhas11);
        $dados11=mysqli_fetch_array($linhas11);
        $quant_estoque = $dados11['quantidade'];
        //verificar se o where e com codigo produto ou pedido
        $consulta12 = "SELECT SUM(quant_pedido) as totpedido FROM pedido_produto where cod_pedido=$ultimo and cod_produto=$produto";
        // echo "$consulta12<br>";
        $linhas12=mysqli_query($conexao, $consulta12);
        mysqli_num_rows($linhas12);
        $dados12=mysqli_fetch_array($linhas12);
        $quant_adicionada=$dados12['totpedido']+1;
        //verifica a condição e so adiciona se nao for maior


        if ($quant_adicionada>$quant_estoque) {

          echo "Numero de produtos excedidos:";



        }else {



        //teste de quantidade
        echo "produtos adicionados no pedido:". $quant_adicionada."<br>produtos no estoque: $quant_estoque<br>quan solic: $quant<br>";
        // $quant_pedido = $dados12['totpedido'];
        // echo $dados12['totpedido'];

          $query = "INSERT INTO pedido_produto (cod_pedido,cod_produto,data_pedido,quant_pedido,valor_pedido,pagamento) VALUES ('".$dados13['cod_pedido']."','".$dados['codigo']."','$data','$quant','45.5','0')";
          if (!mysqli_query($conexao, $query)) {
            echo "erro ao inserir".$query."<br><br><br>";
            echo "code: | ".mysqli_errno($conexao)." |";
            echo "$query";
          }

          $consulta12 = "SELECT SUM(quant_pedido) as totpedido FROM pedido_produto where cod_pedido=$ultimo and cod_produto=$produto";
          // echo "$consulta12<br>";
          $linhas12=mysqli_query($conexao, $consulta12);
          mysqli_num_rows($linhas12);
          $dados12=mysqli_fetch_array($linhas12);



        }//else excedidos


          //so lista se ele estiver adicionado
          //listagem dos pedidos que estao sendoa adicionados
          $consulta1 = "SELECT cod_pedido FROM pedido ORDER BY cod_pedido DESC LIMIT 1";
          $linhas1=mysqli_query($conexao, $consulta1);
          if(mysqli_num_rows($linhas1) > 0){
            while ($dados1=mysqli_fetch_array($linhas1)){
              $ultimo = $dados1['cod_pedido'];
              // echo "$ultimo";

              $consulta2 = "SELECT cod_produto FROM pedido_produto where cod_pedido=$ultimo";
              $linhas2=mysqli_query($conexao, $consulta2);
              if(mysqli_num_rows($linhas2) > 0){
                while ($dados2=mysqli_fetch_array($linhas2)){
                    // echo $dados2['cod_produto'];

                  // $consulta = "SELECT cod_produto,sum(quant_pedido) as quantPorCode FROM pedido_produto where cod_produto=".$dados2['cod_produto']." AND cod_pedido=$ultimo group by cod_produto";
                  // echo "$consulta";
                  // $linhas=mysqli_query($conexao, $consulta);/
                  // if(mysqli_num_rows($linhas) > 0){
                    // while ($dados=mysqli_fetch_array($linhas)){
                      // echo $dados['cod_produto'].":".$dados['quantPorCode'];


                  //ver como listar isso

                  $consulta3 = "SELECT * FROM produto where codigo=".$dados2['cod_produto'];
                  // echo "$consulta3";
                  $linhas3=mysqli_query($conexao, $consulta3);
                  if(mysqli_num_rows($linhas3) > 0){
                    while ($dados3=mysqli_fetch_array($linhas3)){

                      //---------------------------------------------------------------------------------------------------------------------------------
                      //ver como essa quant deve ser trocada para a quantidade que ta no sql
                      //---------------------------------------------------------------------------------------------------------------------------------
                      for ($i=0; $i < $quant ; $i++) {

                        echo "<table border=1 class='add'>";
                        echo "<tr><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Tipo</td><td>Valor</td></tr>";
                        echo "<tr><td>".$dados3['codigo']."</td>";
                        echo "<td>".$dados3['referencia']."</td>";
                        echo "<td>".$dados3['marca']."</td>";
                        echo "<td>".$dados3['tamanho']."</td>";
                        echo "<td>".$dados3['cor']."</td>";
                        echo "<td>".$dados3['genero']."</td>";
                        echo "<td>".$dados3['tipo']."</td>";
                        echo "<td>".$dados3['valor']."</td>";
                        // echo "<td class='quant'>".$dados3['quantPorCode']."</td>
                        echo "</tr>";
                        // echo "<td>".$quant."</td></tr>";
                        echo "</table>";

                      }//for
                    }
                  }
                }
              }

            }
          }


      }

    }//chave teste campos vazios
  }//chave add produto



  // pega o codigo do ultimo pedido feito
  $total = 0;
  $consulta1 = "SELECT cod_pedido FROM pedido ORDER BY cod_pedido DESC LIMIT 1";
  $linhas1=mysqli_query($conexao, $consulta1);
  mysqli_num_rows($linhas1);
  $dados1=mysqli_fetch_array($linhas1);
  $ultimo = $dados1['cod_pedido'];

  $consulta = "SELECT SUM(produto.valor * pedido_produto.quant_pedido) AS soma FROM pedido_produto LEFT JOIN produto ON pedido_produto.cod_produto = produto.codigo WHERE cod_pedido=$ultimo";
  $linhas=mysqli_query($conexao, $consulta);
  mysqli_num_rows($linhas);
  $dados=mysqli_fetch_array($linhas);


  $soma = $dados['soma'];
  $x1x = $soma;
  $x2x = $soma/2;
  $x3x = $soma/3;
  $x4x = $soma/4;
  $x5x = $soma/5;
  $x6x = $soma/6;
  $x7x = $soma/7;
  $x8x = $soma/8;
  $x9x = $soma/9;
  $x10x = $soma/10;
  $x11x = $soma/11;
  $x12x = $soma/12;

  echo "<div class='areafinalizar'>";



  echo "
  <form action='caixa.php' method='post'>

  <div class='radio'>
  <label class='radio-inline'><input type='radio' name='op' value='Credito'>Crédito</label>
  </div>

  <select class='vezes' name='opparc'>
  <option>1 x $x1x</option>
  <option>2 x ".number_format($x2x,2,'.','.')."</option>
  <option>3 x ".number_format($x3x,2,'.','.')."</option>
  <option>4 x ".number_format($x4x,2,'.','.')."</option>
  <option>5 x ".number_format($x5x,2,'.','.')."</option>
  <option>6 x ".number_format($x6x,2,'.','.')."</option>
  <option>7 x ".number_format($x7x,2,'.','.')."</option>
  <option>8 x ".number_format($x8x,2,'.','.')."</option>
  <option>9 x ".number_format($x9x,2,'.','.')."</option>
  <option>10 x ".number_format($x10x,2,'.','.')."</option>
  <option>11 x ".number_format($x11x,2,'.','.')."</option>
  <option>12 x ".number_format($x12x,2,'.','.')."</option>

  </select><br>


  <div class='radio'>
  <label class='radio-inline'><input type='radio' name='op' value='Debito'>Débito</label>
  </div>
  <div class='radio'>
  <label class=radio-inline'><input type='radio' name='op' value='Debito'>Dinheiro</label>
  </div>
  <input type='submit' name='finalizar' class='finalizar' value='Finalizar pedido'>

  </form>

  ";
  echo "<div class='fontes2'>Valor total:". $dados['soma']."<br></div>";
  echo "</div>";





  //salvar forma de pagamento
  
  if (isset($_POST['finalizar'])) {






    if ($_POST['op']=="") {
      echo "<script>alert('Escolha uma opção de pagamento!')</script>";
    }else {
      // $opp=$_POST['opparc'];
      // echo "$op:$opp";



      if ($_POST['op']=="Credito") {
        $query = "UPDATE pedido_produto SET pagamento='$op:$opp' where cod_pedido=$ultimo";
        if (!mysqli_query($conexao, $query)) {
          echo "erro ao inserir".$query."<br><br><br>";
          echo "code: | ".mysqli_errno($conexao)." |";
        }
      }else{
        $query = "UPDATE pedido_produto SET pagamento='$op' where cod_pedido=$ultimo";
        if (!mysqli_query($conexao, $query)) {
          echo "erro ao inserir".$query."<br><br><br>";
          echo "code: | ".mysqli_errno($conexao)." |";
        }
      }
      $query = "UPDATE pedido_produto SET valor_pedido=$soma where cod_pedido=$ultimo";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";
      }

      //dar baixa na quantidade do estoque
      $consult = "SELECT cod_produto,SUM(quant_pedido)AS total_produto FROM pedido_produto where cod_pedido=$ultimo AND cod_produto GROUP BY cod_produto";
      $linhast=mysqli_query($conexao, $consult);
      if(mysqli_num_rows($linhast)>0){
        while($dadost=mysqli_fetch_array($linhast)){
          $tot= $dadost['total_produto'];

          // $consult22 = "UPDATE produto SET quantidade=0 WHERE quantidade<=1";
          $q = "SELECT quantidade AS quantidade_v FROM produto where codigo=".$dadost['cod_produto'];

          $linhasq=mysqli_query($conexao, $q);
          if(mysqli_num_rows($linhasq)>0){
            while($dadosq=mysqli_fetch_array($linhasq)){
              $qt = $dadosq['quantidade_v'];
              if ($qt<=0) {
                $consult100 = "UPDATE produto SET quantidade=0 where codigo=" . $dadost['cod_produto'];
                // echo "aqui:$qt";
                // echo "aqui:$consult100";
                if (!mysqli_query($conexao, $consult100)) {
                  echo "erro ao inserir".$consult100."<br><br><br>";
                  echo "code: | ".mysqli_errno($conexao)." |";
                }
              }
            }
          }


          // CORRIGIR
          // SE FICAR RECARREGANDO A PAGINA ELE CONTINUA SETANDO, TEM QUE FAZER ELE PARAR DEPOIS QUE FINALIZAR O PEDIDO
          $consult = "UPDATE produto SET quantidade=quantidade-" . $tot . " where codigo=" . $dadost['cod_produto'];
          if (!mysqli_query($conexao, $consult)) {
            echo "erro ao inserir".$consult."<br><br><br>";
            echo "code: | ".mysqli_errno($conexao)." |";
          }else {
            echo "setou";
          }

        }
      }
    } //chave else
  } //chave finalizar



  if (isset($_POST['verificar'])) {


if ($_POST['produto']=="") {
  echo "Preencha o campo código para fazer a verificação";
}else {

    $consultaverificacao = "SELECT codigo,quantidade FROM produto WHERE codigo=".$_POST['produto'];

    $linhasverificacao=mysqli_query($conexao, $consultaverificacao);
    if(mysqli_affected_rows($conexao) > 0){
      while ($dadosv=mysqli_fetch_array($linhasverificacao)){


        if ( $dadosv['quantidade']<=0 || $dadosv['codigo']=="") {

          echo "Produto Indisponível";
        } else if($dadosv['quantidade']==1){
          echo $dadosv['quantidade']." produto disponível";
        }else {
          echo $dadosv['quantidade']." produtos disponíveis";
        }

      }
    }
  }
  }




  if (isset($_POST['entrar'])) {

    $login = $_POST['login'];
    $senha = $_POST['senha'];

    if ($login=="ronaldo" && $senha='010203') {
      header("Location: adm.php");
    }else{
      // echo "<script>";
      // echo  "alert('Usuario ou senha incorretos')";
      // echo "</script>";

      //ver isso, porque quando recarrega a pagina ele mostra o alert
    }
  }
  ?>


  <style media="screen">
  .pedido{
    width: 10%;
  }
</style>

</body>



<style media="screen">

.quant{
  background-color: gray;
}
.cred{
  font-weight: 600;
  font-size: 80%;

  position: absolute;
  top: 5%;
}

.opparcelamento{
  position: absolute;
  top: 5%;
  left: 30%;
}
.finalizar{
  font-weight: 600;
  font-size: 100%;
  margin-left: 30%;
}
.areafinalizar{
  width: 25%;
  height: 30%;
  /* border:  3px solid black; */
  position: absolute;
  right: 0%;
  top: 30%;

}

.fontes2{
  font-weight: 600;
  font-size: 150%;
  margin-top: 0;
  position: relative;
  top:-50%;
  left: 40%;

}

.pedido{
  width: 20%;
  font-weight: 600;

}

.fontes{
  font-weight: 600;
  font-size: 80%;

}
.fontes3{
  font-weight: 600;
  font-size: 80%;

  position: absolute;
  top: 5%;
  /* left: 20%; */
}
.btnpedido{
  /* font-weight: 600; */
  /* font-size: 80%; */
  /* margin-left: 40%; */
  /* margin-left: 90%;
  margin-top: -10%; */
}

.btnadd{
  font-weight: 600;
  font-size: 180%;
  margin-left: 40%;
}
.add{
  /* visibility: hidden; */
  width: 60%;
  margin-left: 25%;
  margin-top: 2%;
  /* border:  1px solid black; */

}
body,html{
  height: 100%;
  width: 100%;

  /* overflow:hidden; */
}
p{
  text-align: center;
  font-size: 200%;
  color: white;
}
.login{
  position: absolute;
  top: 35%;
  left: 30%;

}
.senha{
  position: absolute;
  top: 55%;
  left: 30%;
}
.btnlogin{
  color:#d32f2f;
  position: absolute;
  top: 70%;
  left: 43%;
  background-color: white;
}
.botaoadm{

  position: absolute;
  top: 3%;
  right: 0%;
  width: 5%;
  height: 5%;
  /* background-color: black; */
  z-index: 10;
  border-radius: 5px 5px 5px 5px;
}
.menu{
  /* text-align: center; */
  /* background-color: #d32f2f; */
  width: 10%;
  height: 70%;
  position: absolute;
  top: 15%;
  /* z-index: 5; */

}

.caixa{
  background-color: #d32f2f;
  width: 100%;
  height: 33.333%;
  position: absolute;
}

.buscar{
  background-color: #d32f2f;
  width: 100%;
  height: 33.333%;
  position: absolute;
  top: 33.333%;
}

.compras{

  background-color: #d32f2f;
  width: 100%;
  height: 33.333%;
  position: absolute;
  top: 66.66%;
}

.adm{
  margin-bottom: 2%;
  background-color: #d32f2f;
  width: 25%;
  height: 30%;
  margin-left: 73%;
  position: relative;
  border-radius: 5px 5px 5px 5px;

}
</style>

<script>
$('btnadd').click(function{
  $('add').css('visibility:','visible');

});
</script>


<?php
// $consulta1 = "SELECT cod_pedido FROM pedido ORDER BY cod_pedido DESC LIMIT 1";
// $linhas1=mysqli_query($conexao, $consulta1);
// mysqli_num_rows($linhas1);
//   $dados1=mysqli_fetch_array($linhas1);
//     $ultimo = $dados1['cod_pedido'];
//
//           $consulta = "SELECT SUM(produto.valor * pedido_produto.quant_pedido) AS soma FROM pedido_produto LEFT JOIN produto ON pedido_produto.cod_produto = produto.codigo WHERE cod_pedido=$ultimo";
//           $linhas=mysqli_query($conexao, $consulta);
//           mysqli_num_rows($linhas);
//             $dados=mysqli_fetch_array($linhas);
//               echo "Soma total:". $dados['soma']."<br>";

// $consulta = "SELECT cod_pedido,cod_produto, produto.* FROM pedido LEFT JOIN produto ON produto.codigo=pedido.cod_produto";
// $linhas=mysqli_query($conexao, $consulta);
// if(mysqli_affected_rows($conexao) > 0){
//
//   echo "<div class='todos'><table border=1>";
//
//   while ($dados=mysqli_fetch_array($linhas)){
//     // $cod=$dados['codigo'];
//     echo "<tr><td>".$dados['cod_pedido']."</td>";
//     echo "<td>".$dados['cod_produto']."</td></tr>";
//
//
//
// }
// }



//   $consulta = "SELECT * FROM pedido";
//   $linhas=mysqli_query($conexao, $consulta);
//   if(mysqli_affected_rows($conexao) > 0){
//
//   echo "<div class='todos'><table border=1>";
//   echo "<tr class='nomes'><td>Pedido</td><td>Código</td><td>Nome</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Valor</td></tr>";
//     while ($dados=mysqli_fetch_array($linhas)){
//       $cod=$dados['codigo'];
//
//       echo "<tr><td>".$dados['cod_pedido']."</td>";
//       echo "<td>".$dados['codigo']."</td>";
//       echo "<td>".$dados['nome']."</td>";
//       echo "<td>".$dados['marca']."</td>";
//       echo "<td>".$dados['tamanho']."</td>";
//       echo "<td>".$dados['cor']."</td>";
//       echo "<td>".$dados['genero']."</td>";
//       echo "<td>".$dados['valor']."</td>";
//
//       // echo "<form action='site.php' method='post'>";
//       // echo "<td><button type='submit' name='excluir' class='excluir' id='$cod'>X</button><td></tr>";
//       echo "<form action='adm.php' method='post'>";
//       echo "<input type='hidden' name='id' value='$cod'>
//       <td><input type='submit' name='deletar' value='X' /></td></tr>";
//       echo "</form>";
//       //  header("Location: site.php");
//
//
//     }
//   }
//     echo "</table></div>";
//
// }



// echo "<table><tr><td>".$dados1['cod_pedido']."</td></tr></table>";
// $quant = $_POST['quant'];
// $referencia = $_POST['camporef'];

//consultando pra ver se tem mais de um prdouto com a mesma refrencia pra dar as opcoes e qual vai ser o escolhido
// $consulta0 = "SELECT COUNT(*) AS referencia FROM produto WHERE referencia=$produto";
// $linhas0=mysqli_query($conexao, $consulta0);
// if(mysqli_num_rows($linhas0) > 0){
//     while ($dados0=mysqli_fetch_array($linhas0)){
//       // echo "<table><tr><td>".$dados0['referencia']."</td></tr></table>";
//       if ($dados0['referencia']>1) {
//
//         $consulta5 = "SELECT * FROM produto WHERE referencia=$produto";
//         $linhas5=mysqli_query($conexao, $consulta5);
//         echo "<select name='op'>";
//         if(mysqli_num_rows($linhas5) > 0){
//             while ($dados5=mysqli_fetch_array($linhas5)){
//
//               echo "<option>";
//               echo "Codigo:".$dados5['codigo']." | Marca:".$dados5['marca']." | Tamanho:".$dados5['tamanho']." | Cor:".$dados5['cor']." | Genero:".$dados5['genero']." | Valor:".$dados5['valor'];
//               echo "</option>";
//
//             }
//           }
//           echo "</select>";
//         }
//       }
//     }
// $quant = $novaquant;

// ele so mostra o pedido quando a quantidade for maior arrumar isso




?>
</html>
