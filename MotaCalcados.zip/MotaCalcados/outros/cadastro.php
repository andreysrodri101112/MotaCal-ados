
<?php

session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="adm") {
    $sessao = "Administrador";
  }elseif ($_SESSION['username']=="func") {
    header("Location: listagemfuncionario.php");
  }
  // echo $sessao;
}else {
  header("Location: index.php");
}

if (isset($_POST['logout'])) {
  header("Location:index.php");
}
 ?>

<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style/not/cadastro2.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>



<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Mota Calçados</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="position"><a href="cadastro.php">Cadastro</a></li>
      <li><a href="listagem.php">Estoque</a></li>
      <li><div class="dropdown">
  <button onclick="myFunction()" class="dropbtn" style="background:none;color:black;">Vendas</button>
  <div id="myDropdown1" class="dropdown-content">
    <a href="#">Hoje</a>
    <a href="#">Específico</a>
    <a href="#">Pedíodo</a>
    <a href="#">Mensal</a>
    <a href="#">Trimestral</a>
    <a href="#">Anual</a>
  </div>
</div></li>
      <li><div class="dropdown">
  <button onclick="myFunction()" class="dropbtn" style="background:none;color:black;">Faturamento</button>
  <div id="myDropdown2" class="dropdown-content">
    <a href="financeiroNovo.php">Hoje</a>
    <a href="#">Específico</a>
    <a href="#">Pedíodo</a>
    <a href="#">Mensal</a>
    <a href="#">Trimestral</a>
    <a href="#">Anual</a>
  </div>
</div></li>

    </ul>



    <div class="dropdown" style="float:right;">
      <?php
       echo "<button class='dropbtn'>$sessao</button>";
      ?>
      <div class="dropdown-content">
        <a href="logout.php">Sair</a>

      </div>
    </div>

  </div>

</nav>



<!-- <script type="text/javascript">
function myFunction() {
  document.getElementById("myDropdown2").classList.toggle("show");
  // document.getElementById("myDropdown2").classList.toggle("show");

}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
if (!event.target.matches('.dropbtn')) {

  var dropdowns = document.getElementsByClassName("dropdown-content");
  var i;
  for (i = 0; i < dropdowns.length; i++) {
    var openDropdown = dropdowns[i];
    if (openDropdown.classList.contains('show')) {
      openDropdown.classList.remove('show');
    }
  }
}
}
</script> -->
    

<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="#" method="post">

        <div class="row">
          <div class="col-50">
            <label for="fname">Código</label>
            <input type="text" id="fname" name="cod" placeholder="">
            <label for="email">Referencia</label>
            <input type="text" id="email" name="ref" placeholder="">

            <label for="city">Marca</label>
            <input type="text" id="city" name="marca" placeholder="">

            <div class="row">
              <div class="col-50">
                <label for="state">Tamanho</label>
                <input type="text" id="state" name="tamanho" placeholder="">
              </div>
              <div class="col-50">
                <label for="zip">Quantidade</label>
                <input type="text" id="zip" name="quantidade" placeholder="">
              </div>
            </div>
          </div>

          <div class="col-50">
            <label for="adr">Cor</label>
            <input type="text" id="adr" name="cor" placeholder="">



            <label for="cname">Tipo</label>
            <select class="form-control" name="tipo">
              <option value=""></option>
              <option value="Tenis">Tenis</option>
              <option value="Sapato">Sapato</option>
              <option value="Bota">Bota</option>
              <option value="Sandalia">Sandália</option>
            </select>


            <label for="ccnum">Gênero</label>
            <select class="form-control" name="genero">
              <option value=""></option>
              <option value="Masculino">Masculino</option>
              <option value="Feminino">Feminino</option>
              <option value="Unissex">Unissex</option>
            </select>
            <label for="expmonth">Valor</label>
            <input type="text" id="expmonth" name="valor" placeholder="">


        </div>

        <input type="submit" value="Cadastrar" class="btn"name="cadastrar">
      </form>
    </div>
  </div>

</div>


<?php



$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}




if (isset($_POST['cadastrar'])) {
  date_default_timezone_set('America/Sao_paulo');
  $data = date('Y-m-d H:i:s');
  $dataa = date('Y-m-d ');

  $erro=0;
  $errocod=0;
  $codigo = $_POST['cod'];
  $ref = $_POST['ref'];
  $marca = $_POST['marca'];
  $valor = $_POST['valor'];
  $tipo = $_POST['tipo'];
  $cor =  $_POST['cor'];
  $quant =  $_POST['quantidade'];
  $tamanho =  $_POST['tamanho'];


  if (!isset($_POST['cod']) || $_POST['cod']=="") {
    ++$erro;
  }
  if (!isset($_POST['ref']) || $_POST['ref']=="") {
    ++$erro;
  }
  if (!isset($_POST['marca']) || $_POST['marca']=="") {
    ++$erro;
  }
  if (!isset($_POST['tamanho']) || $_POST['tamanho']=="") {
    ++$erro;
  }
  if (!isset($_POST['tipo']) || $_POST['tipo']=="") {
    ++$erro;
  }
  if (!isset($_POST['genero']) || $_POST['genero']=="") {
    ++$erro;
  }else {
    $genero = $_POST['genero'];

  }
  if (!isset($_POST['valor']) || $_POST['valor']=="") {
    ++$erro;
  }
  if (!isset($_POST['cor']) || $_POST['cor']=="") {
    ++$erro;
  }
  if (!isset($_POST['quantidade']) || $_POST['quantidade']=="") {
    ++$erro;
  }



  $errocode=0;
  $consulta3 = "SELECT codigo from produto";
  $linhas3=mysqli_query($conexao, $consulta3);
  if(mysqli_num_rows($linhas3) > 0){
    while ($dadosmf=mysqli_fetch_array($linhas3)){
      if ($dadosmf['codigo']==$codigo) {
        ++$errocode;

    }
  }

  if ($erro>0 ) {

    echo "<div class='divErro'>
    <p>Prenncha todos os campos</p>
    <div id='x'>X</div>
    </div>";
  }else if ($errocode>0) {


        echo "<div class='divErro'>
        <p>Códido já existente</p>
        <div id='x'>X</div>
        </div>";

  }else {


    //
    // foreach($_POST["quantidade"] AS $indice => $q) {
    //
    //   // echo "$indice:$t<br>";
    //   if ($indice==0) {
    //     $indice=25;
    //   }elseif ($indice==1) {
    //     $indice=26;
    //   }elseif ($indice==2) {
    //     $indice=27;
    //   }elseif ($indice==3) {
    //     $indice=28;
    //   }elseif ($indice==4) {
    //     $indice=29;
    //   }elseif ($indice==5) {
    //     $indice=30;
    //   }elseif ($indice==6) {
    //     $indice=31;
    //   }elseif ($indice==7) {
    //     $indice=32;
    //   }elseif ($indice==8) {
    //     $indice=33;
    //   }elseif ($indice==9) {
    //     $indice=34;
    //   }elseif ($indice==10) {
    //     $indice=35;
    //   }elseif ($indice==11) {
    //     $indice=36;
    //   }elseif ($indice==12) {
    //     $indice=37;
    //   }elseif ($indice==13) {
    //     $indice=38;
    //   }elseif ($indice==14) {
    //     $indice=39;
    //   }elseif ($indice==15) {
    //     $indice=40;
    //   }elseif ($indice==16) {
    //     $indice=41;
    //   }elseif ($indice==17) {
    //     $indice=42;
    //   }elseif ($indice==18) {
    //     $indice=43;
    //   }elseif ($indice==19) {
    //     $indice=44;
    //   }
      // $codigo = $ref.$indice.$cor;
      // $codigo = 1;
      // if ($q!=0) {

        $query = "INSERT INTO `produto`(`codigo`,`referencia`, `marca`,`tamanho`,`cor`,`genero`,`tipo`,`valor`,`quantidade`,`data_entrada`) VALUES('$codigo','$ref','$marca','$tamanho','$cor','$genero','$tipo','$valor','$quant','$data')";
        // echo $query;
        if (!mysqli_query($conexao, $query)) {
          echo "erro ao inserir".$query."<br><br><br>";
          echo "code: | ".mysqli_errno($conexao)." |";
        }
      // }
    }
  }
}





// $myArray = array();
//Adicionando elementos a nosso Array dinamicamente,
//sem definir sua chave, assim ela será gerada automaticamente:
// $myArray[] = 'blue';
// $myArray[] = 'red';
//Adicionado elementos definindo sua chave de acesso:
// $myArray['ge'] = 'green';
// $myArray['gy'] = 'gray';
// print_r($myArray);


// $lista = array();
//
// if (isset($_POST['cadastrar'])) {
//
//   if ($_POST['t1']=!"") {
//     // $lista[] = $_POST['t1'];
//     echo $_POST['t1'];
//   }

// print_r($lista);

//
// for ($i=0; $i < $lista; $i++) {
//   echo $lista[$i];
// }




?>

<script type="text/javascript">

if ( $( ".divErro" ).is( ":hidden" ) ) {
  $( ".divErro" ).slideDown(1000);
}
else {
  $( "#divErro" ).hide();
}



$('#x').click(function(){
  if ( $(".divErro").slideUp(1000)) {

  }
  return true;
});
</script>



</body>
</html>
