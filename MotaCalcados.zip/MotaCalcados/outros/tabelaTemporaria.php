<?php
$conn = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}




   function($tabela){

          $sql = 'Create table'.$tabela.'(
                                `campo1`,`campo2` )';

                 mysql_query( $sql, $conn );

   }
   function($tabela){
          $sql = 'drop table'.$tabela;

   mysql_query( $sql, $conn );
   }





?>
