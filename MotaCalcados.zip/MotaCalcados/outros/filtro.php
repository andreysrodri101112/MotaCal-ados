<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <style type="text/css">
  label { display: block; }
  </style>

  <form action="" method="post">
    <label>Codifo: <input type="text" name="n" /></label>
    <label>Marca: <input type="text" name="c" /></label>
    <label>Tipo: <input type="text" name="b" /></label>

    <label><input type="submit" name="ok" value="Ok" /></label>
  </form>

  <body>

    <?php
    $conexao = mysqli_connect("localhost","root","","tcc");
    if (!$conexao) {
      die("Erro".mysql_error());

    }


	if( $_SERVER['REQUEST_METHOD']=='POST' )
	{
		$where = Array();

		$codigo = getPost('n');
		$marca = getPost('c');
		$tipo = getPost('b');


		if( $codigo ){ $where[] = " `codigo` = '{$codigo}'"; }
		if( $marca ){ $where[] = " `marca` = '{$marca}'"; }
		if( $tipo ){ $where[] = " `tipo` = '{$tipo}'"; }

		$sql = "SELECT * FROM produto ";
		if( sizeof( $where ) )
			$sql .= ' WHERE '.implode( ' AND ',$where );

		echo $sql;//execute a query aqui
	}
	//a cargo do leitor melhorar o filtro anti injection
	function filter( $str ){
		return addslashes( $str );
	}
	function getPost( $key ){
		return isset( $_POST[ $key ] ) ? filter( $_POST[ $key ] ) : null;
	}

  
?>

  </body>
</html>
