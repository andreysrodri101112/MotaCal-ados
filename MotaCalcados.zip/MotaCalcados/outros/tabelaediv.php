<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<div class="teste">

    <table width="300px" border="1">
 <tr>
  <td>1</td>
  <td>1</td>
 </tr>
 <tr>
  <td>1</td>
  <td>1</td>
 </tr>
 <tr>
  <td>1</td>
  <td>1</td>
 </tr>
</table>
</div>


<div class="table">
 <div>
  <div class="td"></div>
  <div class="td"></div>
 </div>
 <div>
  <div class="td"></div>
  <div class="td"></div>
 </div>
 <div>
  <div class="td"></div>
  <div class="td"></div>
 </div>
</div>



<style media="screen">
html,body{
  width: 100%;
  height: 100%;

}
  .teste{
    width: 30%;
    height: 20%;
    background-color: black;
    margin-left:20%;

  }
</style>

  </body>
</html>
