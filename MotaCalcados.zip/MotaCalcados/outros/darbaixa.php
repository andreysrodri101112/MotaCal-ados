<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>


    <?php


     ?>



     <form class="" action="teste.php" method="post">
      <input type='hidden' name='id' value='1'>
      <input type="submit" name="t" value="clique aqui">
    </form>
    <?php


     ?>
  </body>
</html>
