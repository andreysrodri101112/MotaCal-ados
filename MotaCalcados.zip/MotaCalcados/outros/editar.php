<?php

header('Content-type: text/html; charset=utf-8');

// echo $_POST['id'];
$cod=$_GET['id'];

$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}


$consultamf = "SELECT * FROM produto WHERE codigo=".$cod;

$linhasmf=mysqli_query($conexao, $consultamf);
if(mysqli_affected_rows($conexao) > 0){

  if ($dadosmf=mysqli_fetch_array($linhasmf)){
    $codigo=$dadosmf['codigo'];
    $ref=$dadosmf['referencia'];
    $marca=$dadosmf['marca'];
    $tamanho=$dadosmf['tamanho'];
    $cor=$dadosmf['cor'];
    $genero=$dadosmf['genero'];
    $tipo=$dadosmf['tipo'];
    $quant=$dadosmf['quantidade'];
    $valor=$dadosmf['valor'];
    $_data = $dadosmf['data_entrada'];

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8"/>
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>


  <body>


        <div class="row">
          <div class="col-75">
            <div class="container">
              <form action="#" method="post">

                <div class="row">
                  <div class="col-50">
                    <label for="fname">Código</label>
                    <input type="text" id="fname" name="cod" placeholder="" value="<?php echo $codigo ?>">
                    <label for="email">Referencia</label>
                    <input type="text" id="email" name="ref" placeholder="" value="<?php echo $ref ?>">

                    <label for="city">Marca</label>
                    <input type="text" id="city" name="marca" placeholder="" value="<?php echo $marca ?>">

                    <div class="row">
                      <div class="col-50">
                        <label for="state">Tamanho</label>
                        <input type="text" id="state" name="tamanho" placeholder="" value="<?php echo $tamanho ?>">
                      </div>
                      <div class="col-50">
                        <label for="zip">Quantidade</label>
                        <input type="text" id="zip" name="quantidade" placeholder="" value="<?php echo $quant ?>">
                      </div>
                    </div>
                  </div>

                  <div class="col-50">
                    <label for="adr">Cor</label>
                    <input type="text" id="adr" name="cor" placeholder="" value="<?php echo $cor ?>">



                    <label for="cname">Tipo</label>
                    <select class="form-control" name="tipo">
                      <?phpecho "<option value='$tipo'>$tipo</option>";?>
                      <option value="Tenis">Tenis</option>
                      <option value="Sapato">Sapato</option>
                      <option value="Bota">Bota</option>
                      <option value="Sandalia">Sandália</option>
                    </select>


                    <label for="ccnum">Gênero</label>
                    <select class="form-control" name="genero">
                      <?phpecho "<option value='$genero'>$genero</option>";?>
                      <option value="Masculino">Masculino</option>
                      <option value="Feminino">Feminino</option>
                      <option value="Unissex">Unissex</option>
                    </select>
                    <label for="expmonth">Valor</label>
                    <input type="text" id="expmonth" name="valor" placeholder="" value="<?php echo $valor?>">
                    <label for="expmonth">Imagem</label>
                    <input type="file" id="expmonth" name="img" placeholder="">
                  </div>

                </div>

                <input type="submit" value="Salvar alterações" class="btn"name="cadastrar">
                <input type="submit" value="Cancelar" class="btn-cancelar" name="canc"/>


              </form>
            </div>
          </div>

        </div>

      </body>
    </html>

        <style media="screen">

        .btn {
          background-color: #D32F2F;
          color: white;
          padding: 15px;
          margin: 10px 0;
          border: none;
          width: 100%;
          border-radius: 3px;
          cursor: pointer;
          font-size: 17px;
          margin-top: 3%;
        }
        .btn-cancelar {
          float: left;
          background-color: green;
          color: white;
          padding: 15px;
          margin: 10px 0;
          border: none;
          width: 100%;
          border-radius: 3px;
          cursor: pointer;
          font-size: 17px;
          margin-top: 3%;
        }
        .btn:hover {
          background-color: #B71C1C;
          color: white;
        }
        .form-control{
          border-radius: 1px;
          height: 12%;
        }
          body {
          /* font-family: Arial;
          font-size: 17px;
          padding: 8px; */
        }

        * {
          box-sizing: border-box;
        }

        .row {
          display: -ms-flexbox; /* IE10 */
          display: flex;
          -ms-flex-wrap: wrap; /* IE10 */
          flex-wrap: wrap;
          margin: 0 -16px;
        }

        .col-25 {
          -ms-flex: 25%; /* IE10 */
          flex: 25%;
        }

        .col-50 {
          -ms-flex: 50%; /* IE10 */
          flex: 50%;
        }

        .col-75 {
          -ms-flex: 75%; /* IE10 */
          flex: 75%;
        }

        .col-25,
        .col-50,
        .col-75 {
          padding: 0 16px;
        }

        .container {
          background-color: #f2f2f2;
          padding: 5px 20px 15px 20px;
          border: 1px solid lightgrey;
          border-radius: 3px;
          margin-top: 5%;
        }

        input[type=text] {
          width: 100%;
          margin-bottom: 20px;
          padding: 12px;
          border: 1px solid #ccc;
          border-radius: 3px;
        }

        label {
          margin-bottom: 10px;
          display: block;
        }

        .icon-container {
          margin-bottom: 20px;
          padding: 7px 0;
          font-size: 24px;
        }


        /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
        @media (max-width: 800px) {
          .row {
            flex-direction: column-reverse;
          }
          .col-25 {
            margin-bottom: 20px;
          }
        }
        </style>


<?php

if (isset($_POST['canc'])) {
header("Location: listagem.php");
}
if (isset($_POST['cadastrar'])) {
  $codigo_novo=$_POST['cod'];
  $ref_novo=$_POST['ref'];
  $marca_novo=$_POST['marca'];
  $tamanho_novo=$_POST['tamanho'];
  $cor_novo=$_POST['cor'];
  $genero_novo=$_POST['genero'];
  $tipo_novo=$_POST['tipo'];
  $quant_novo=$_POST['quantidade'];
  $valor_novo=$_POST['valor'];
  // $_data_novo=$_POST['data'];

  $query = "UPDATE produto SET codigo='$codigo_novo',referencia='$ref_novo',marca='$marca_novo',tamanho='$tamanho_novo',cor='$cor_novo',genero='$genero_novo',tipo='$tipo_novo',quantidade='$quant_novo',valor='$valor_novo' where codigo='$cod'";
  header("Location: listagem.php");
  // echo "<br>atualizou";
  // echo $query;
  if (!mysqli_query($conexao, $query)) {
    echo "erro ao inserir".$query."<br><br><br>";
    echo "code: | ".mysqli_error($conexao)." |";
  }
}


}
}

// }
//
// echo "<tr><td>".$dadosmf['codigo']."</td>";
// echo "<td>".$dadosmf['referencia']."</td>";
// echo "<td>".$dadosmf['marca']."</td>";
// echo "<td>".$dadosmf['tamanho']."</td>";
// echo "<td>".$dadosmf['cor']."</td>";
// echo "<td>".$dadosmf['genero']."</td>";
// echo "<td>".$dadosmf['tipo']."</td>";
// echo "<td>".$dadosmf['quantidade']."</td>";
// echo "<td>".$dadosmf['valor']."</td>";
// echo "<td>".$dadosmf['data_entrada']."</td>";
//TENTAR BOTAR OS LI COMO SUBMIT COM ID
// echo "</tr>";
//
// echo "<button type='submit' name='deletar'>Deletar</button>";
//
// echo "</form>";
//


?>
