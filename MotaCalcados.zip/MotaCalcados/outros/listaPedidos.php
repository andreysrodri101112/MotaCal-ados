


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>


  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Mota Calçados</a>
      </div>
      <ul class="nav navbar-nav">
        <!-- <li class="active"><a href="paginaAdm.php">Home</a></li> -->
        <li><a href="cadastro.php">Cadastro</a></li>
        <li><a href="listagem.php">Produtos</a></li>
        <li><a href="listaPedidos.php">Pedidos</a></li>
        <li><a href="financeiro.php">Financeiro</a></li>
        <li><a href="financeiro.php">Clientes</a></li>



        <!-- <li><a href="#">Page 3</a></li> -->
      </ul>
    </div>
  </nav>

  <form  action="#" method="post">
    <button type="submit" class="btn btn-defaulta" class="a" name="novoPedido">Novo Pedido</button>
  </form>

  <style media="screen">
  .btn-defaulta{
    margin-left: 45%;
    background-color: #00C853;
  }

</style>

<!-- <div class="tudo"></div> -->


<?php
$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}


if (isset($_POST['novoPedido'])) {
  $query = 'INSERT INTO pedido () VALUES ()';
  if (!mysqli_query($conexao, $query)) {
    echo "erro ao inserir " . $query;
  }
  header("Location: novoPedido.php");
}


$consulta = "SELECT *, sum(valor_pedido) as valor_total FROM pedido_produto group by cod_pedido";
// echo "$consulta<br>";
$linhas=mysqli_query($conexao, $consulta);
if(mysqli_affected_rows($conexao) > 0){

  echo "<table class='table table-bordered'>";
  echo "<tr class='corlinha' class='nomes'><td>Código</td><td>Pagamento</td><td>Valor Total</td><td>Data</td><td>Detalhes</td></tr>";
  while ($dados=mysqli_fetch_array($linhas)){
    // echo "CÓDIGO:".$dados2['cod_pedido'];
    $cod=$dados['cod_pedido'];
    echo "<tr><td>".$dados['cod_pedido']."</td>";
    echo "<td>".$dados['pagamento']."</td>";
    echo "<td>".$dados['valor_pedido']."</td>";
    echo "<td>".$dados['data_pedido']."</td>";

    echo "<td>";
    // echo "<form action='listaPedidos.php' method='post' id='mais'>";
    // echo "<input type='hidden' name='id' value='$cod'>
    // <input  class='btn btn-default dropdown-toggle' type='submit'  id='btnmais' name='mais' value='+' />";
    echo "</form>";
    echo "</td></tr>";

    //   }
    // }
  }
}
//




   ?>



<style media="screen">
  .conteudo .aquis{
    background-color: black;
    width: 100px;
    height: 100px;

  }
  .conteudo table.a{
    width: 60%;
    height: auto;
    position: absolute;
    /* top: 20%; */
    /* border-radius: 15px 15px 15px 15px; */
    /* padding: 5px 5px 5px 5px; */
    z-index: 10000;
   }
   .a td{
     /* font-weight: bold; */
     font-size: 20px;
     padding-top: 2%;
   }
  .corlinhamais{
    background-color: #D32F2F;
  }
  .x{
    position: absolute;
    top:21%;
    right: 20%;
    color: gray;
    z-index: 5;
    font-weight: bold;
    font-size: 150%;


  }
  .x:hover{
    cursor: pointer;
    transform: rotate(500deg);
    transition-duration: 2s;
  }
</style>

     <div class="x">
       X
     </div>
     <div class="mais">
   </div>






<?php


 // if (isset($_POST['mais'])) {


echo "<div class='conteudo'>";

echo "<div class='osinputs'>";
echo "<input type='text' class='inputs2' value='Código'>";
echo "<input type='text' class='inputs2' value='Marca'>";
echo "<input type='text' class='inputs2' value='Tamanho'>";
echo "<input type='text' class='inputs2' value='Valor'>";
echo "<input type='text' class='inputs2' value='Quantidade'>";
echo "</div>";

$consulta1 = "SELECT cod_pedido FROM pedido where cod_pedido=".$_POST['id'];
$linhas1=mysqli_query($conexao, $consulta1);
if(mysqli_num_rows($linhas1) > 0){
  while ($dados1=mysqli_fetch_array($linhas1)){
    $cod_ped = $dados1['cod_pedido'];

    $consultamf = "SELECT cod_produto,sum(quant_pedido) as quantpedi from pedido_produto where cod_pedido=$cod_ped group by cod_produto";

    $linhasmf=mysqli_query($conexao, $consultamf);
    if(mysqli_affected_rows($conexao) > 0){
      while ($dadosmf=mysqli_fetch_array($linhasmf)){


        $consulta = "SELECT * from produto where codigo=".$dadosmf['cod_produto'];
        $linhas=mysqli_query($conexao, $consulta);
        if(mysqli_affected_rows($conexao) > 0){
          while ($dados=mysqli_fetch_array($linhas)){

            echo "<input type='text' class='inputs' disabled='disabled' value='".$dados['codigo']."'>";
            echo "<input type='text' class='inputs' disabled='disabled' value='".$dados['marca']."'>";
            echo "<input type='text' class='inputs' disabled='disabled' value='".$dados['tamanho']."'>";
            echo "<input type='text' class='inputs' disabled='disabled' value='".$dados['valor']."'>";
            echo "<input type='text' class='inputs' disabled='disabled' value='".$dadosmf['quantpedi']."'>";




          }
        }


      }
    }


  }
}


echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";

echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";
echo "<input type='text' class='inputs' value='1'>";


echo "</div>";

// }



?>
<style media="screen">
  .inputs{
    width: 20%;
    padding-top: 2%;
    padding-bottom: 2%;
  }
  .inputs2{
    /* position: fixed; */
    background-color: gray;
    padding-top: 2%;
    padding-bottom: 2%;
    width: 20%;
  }
  .osinputs{
    /* position: fixed; */
  }
</style>
<!-- <div class="aquis">

<table class="aquis">

</table>
</div> -->




<?php


// echo "<table>";
// // echo "<table class='a' align='center'>";
// echo "<tr class='corlinhamais' class='nomes'><td>Código do Produto</td><td>Marca</td><td>Tamanho</td><td>Valor</td><td>Quantidade</td></tr>";
// $consulta1 = "SELECT cod_pedido FROM pedido where cod_pedido=".$_POST['id'];
// $linhas1=mysqli_query($conexao, $consulta1);
// if(mysqli_num_rows($linhas1) > 0){
//   while ($dados1=mysqli_fetch_array($linhas1)){
//     $cod_ped = $dados1['cod_pedido'];
//
//     $consultamf = "SELECT cod_produto,sum(quant_pedido) as quantpedi from pedido_produto where cod_pedido=$cod_ped group by cod_produto";
//
//     $linhasmf=mysqli_query($conexao, $consultamf);
//     if(mysqli_affected_rows($conexao) > 0){
//       while ($dadosmf=mysqli_fetch_array($linhasmf)){
//
//
//         $consulta = "SELECT * from produto where codigo=".$dadosmf['cod_produto'];
//         $linhas=mysqli_query($conexao, $consulta);
//         if(mysqli_affected_rows($conexao) > 0){
//           while ($dados=mysqli_fetch_array($linhas)){
//
//
//
//             echo "<tr><td>".$dados['codigo']."</td>";
//             echo "<td>".$dados['marca']."</td>";
//             echo "<td>".$dados['tamanho']."</td>";
//             echo "<td>".$dados['valor']."</td>";
//             echo "<td>".$dadosmf['quantpedi']."</td></tr>";
//
//           }
//         }
//
//
//       }
//     }
//
//
//   }
// }
//
// echo "</table>";
// echo "</div>";
//
// }


   ?>
</div>

<style media="screen">

</style>
<script type="text/javascript">
  <!--
// jQuery(document).ready(function(){
  // jQuery('#filtro').submit(function(){
  //   var dados = jQuery( this ).serialize();
  //
  //   jQuery.ajax({
  //     type: "POST",
  //     url: "teste.php",
  //     data: dados,
  //     success: function( data )
  //     {
  //       $('.t').fadeOut();
        // alert( data );
//       }
//     });
//
//     return false;
//   });
// });

    jQuery('#mais').submit(function(){
    $(".x").show();
    $(".mais").show();
    $(".conteudo").show();
    return false;
    // e.prevenventDefault();


  });
  // return true;

  $(".x").click(function(){
    $(".x").hide();
    $(".mais").hide();
    $(".conteudo").hide();

  });


  //
  // $('.x').click(function(){
  //   if ( $(".conteudo").hide()) {
  //   }if ( $(".x").hide()) {
  //   }if ( $(".mais").hide()) {
  //   }
  //
  //   return true;
  // });




</script>
<!--
<button type="button" name="" class="a" value=""></button>
<div id="div1" style="width:80px;height:80px;background-color:red;display:none;"></div><br>
<script type="text/javascript">
$(document).ready(function(){
    $(".a").click(function(){
        $("#div1").fadeIn();
        $("#div1").slow("2");


    });
}); -->
</script>



<style media="screen">
html,body{
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
}
.fechar{
/* po */
  margin-left: 97%;
}
.fechar:hover{
  cursor: pointer;
}


.conteudo{
  position: relative;
  background-color: white;
  border: 1px solid black;
  width: 60%;
  height: 40%;
  left: 20%;
  top: 10%;
   opacity: 2;
  border-radius: 20px;
  z-index: 3;
  overflow: auto;
  display: none;
 }
.x{
  display: none;
}

.mais{
  display: none;
  height: 100%;
  width: 100%;
z-index:2;
position: absolute;
background-color: #757575;
opacity: 0.5;
top:0;
}

.teste{
  width: 20px;
  height: 20px;
  background-color: black;
  /* visibility: hidden; */
}

.x{
  float: right;
}
.tudo{
  /* opacity: 0.6; */
  position: absolute;
  top: 2%;
  margin-left: 25%;
  /* margin-top: 10%; */
  width: 50%;
  height: 50%;
  border-radius: 10px 10px 10px 10px;
  background-color: #b2bec3;
  border-color: black;
}

.form-control{
  width: 20%;
}

.table{
  width: 100%;
  z-index: 1;
  position: absolute;
  top:20%;
  overflow: auto;
}
.corlinha{
  background-color: #D32F2F;
}

.container{
  width: 25%;
  height: 60%;
  margin-left: 5%;
  margin-top: 2%;
}
.btn-default{
  background-color: #D32F2F;
  cursor: pointer;
}

.botaotodos{
  width: 10%;
  height: 5%;
  position: absolute;
  left: 90%;
  top: 10%;
}
.table-bordered{
  text-align: center;
}
.config{
  background-image: url(img/config.png);
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
</body>
</html>
