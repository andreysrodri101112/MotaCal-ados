




<html>
 <head>
 	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
 	<script type="text/javascript">
 jQuery(document).ready(function(){
   jQuery('#ajax_form').submit(function(){
     var dados = jQuery( this ).serialize();

     jQuery.ajax({
       type: "POST",
       url: "teste.php",
       data: dados,
       success: function( data )
       {
         $string = file_get_contents('$_POST['nome']');
         
       }
     });

     return false;
   });
 });
	</script>
 </head>
 <body>
 	<form method="post" action="" id="ajax_form">
	<label><input type="hidden" name="id" value="" /></label>
 		<label>Nome: <input type="text" name="nome" value="" /></label>
		<label>Email: <input type="text" name="email" value="" /></label>
		<label>Telefone: <input type="text" name="numero" value="" /></label>
		<label><input type="submit" name="enviar" value="Enviar" /></label>
	</form>


  <div class="result">

  </div>


 <!-- // $conexao = mysqli_connect("localhost","root","","tcc");
 // if (!$conexao) {
 //   die("Erro".mysql_error());

 // }
 // $nome= $_POST['nome'];
 // $e = $_POST['email'];
 // $n = $_POST['numero'];
 //
 // $query = "INSERT INTO `t`(`nome`,`email`, `numero`) VALUES('$nome','$e','$n')";
 // if (!mysqli_query($conexao, $query)) {
 //   echo "erro ao inserir".$query."<br><br><br>";
 //   echo "code: | ".mysqli_errno($conexao)." |";
 // } -->



</body>
 </html>
