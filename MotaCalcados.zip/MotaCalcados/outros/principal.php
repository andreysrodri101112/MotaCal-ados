
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
</head>
<body>











  <div class="adm">
    <p>Admnistrativo</p>
    <form class="" action="principal.php" method="post">
      <input class="login" type="text" name="login" placeholder="Usuário">
      <input class="senha" type="password" name="senha" placeholder="Senha">
      <input class="btnlogin" type="submit" name="entrar" value="Entrar">
    </form>
  </div>

  <div class="menu">
    <a href="caixa.php"><input type="button" class="caixa" value="Caixa"/></a>
    <input type="button" class="buscar" value="Buscar"/>
    <input type="button" class="compras" value="Compras"/>

  </div>



  <?php


  if (isset($_POST['entrar'])) {

    $login = $_POST['login'];
    $senha = $_POST['senha'];

    if ($login=="ronaldo" && $senha='010203') {
      header("Location: adm.php");
    }else{
    // echo "<script>";
    // echo  "alert('Usuario ou senha incorretos')";
    // echo "</script>";

    //ver isso, porque quando recarrega a pagina ele mostra o alert
  }
}
  ?>




</body>
<script type="text/javascript">


$('.botaoadm').click(function () {

  if ($( ".adm" ).is(":hidden")) {

  $( ".adm" ).show();
  $( ".botaoadm" ).hide();
}

});
</script>



<style media="screen">
body,html{
  height: 100%;
  width: 100%;

  overflow:hidden;
}
p{
  text-align: center;
  font-size: 200%;
  color: white;
}
.login{
  position: absolute;
  top: 35%;
  left: 30%;

}
.senha{
  position: absolute;
  top: 55%;
  left: 30%;
}
.btnlogin{
  color:#d32f2f;
  position: absolute;
  top: 70%;
  left: 43%;
  background-color: white;
}
.botaoadm{

  position: absolute;
  top: 3%;
  right: 0%;
  width: 5%;
  height: 5%;
  /* background-color: black; */
  z-index: 10;
  border-radius: 5px 5px 5px 5px;
}
.menu{
  /* text-align: center; */
  /* background-color: #d32f2f; */
  width: 10%;
  height: 70%;
  position: absolute;
  top: 15%;
  /* z-index: 5; */

}

.caixa{
  background-color: #d32f2f;
  width: 100%;
  height: 33.333%;
  position: absolute;
}

.buscar{
  background-color: #d32f2f;
  width: 100%;
  height: 33.333%;
  position: absolute;
  top: 33.333%;
}

.compras{

  background-color: #d32f2f;
  width: 100%;
  height: 33.333%;
  position: absolute;
  top: 66.66%;
}

.adm{
  margin-bottom: 2%;
  background-color: #d32f2f;
  width: 25%;
  height: 30%;
  margin-left: 73%;
  position: relative;
  border-radius: 5px 5px 5px 5px;

}
</style>



</html>
