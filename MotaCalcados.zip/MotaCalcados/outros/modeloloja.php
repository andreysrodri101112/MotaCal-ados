<?php

$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());

}

 ?>


<html>

  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="boot/bootstrap.min.css">
    <script src="boot/jquery.min.js"></script>
    <script src="boot/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  </head>

<body>


  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Mota Calçados</a>
      </div>
      <ul class="nav navbar-nav">
        <li ><a href="#" id="home">Home</a></li>
        <li><a type="button" id="masculino">Masculino</a></li>
        <li><a type="button" id="feminino">Feminino</a></li>
        <li><a href="#" id="infantil">Infantil</a></li>
        <li><a href="#" id="promocoes">Promoções</a></li>
      </ul>

      <button class="btn btn-danger navbar-btn">Entrar</button>
    </div>
  </nav>
  <!-- <div class="topo"> -->
    <!-- <div class="login" style="text-align:center;"><h2>Login</h2></div> -->
  <!-- </div> -->

  <!-- <div class="sexo">
    <div class="scrollmenu">
      <a type="button" id="masculino">Masculino</a>
      <a type="button" id="feminino">Feminino</a>
    </div> -->
    <!-- <a class="masc" id="masculino"><h2>Masculino</h2></button>
    <a class="femi" id="feminino"><h2>Feminino</h2></button> -->
  </div>


</div>

  <div id="filtroM">
    <form class="" action="" id="filtro" method="post">
      <h3>Tamanho</h3>
      <?php
      $marca="";
      $consulta1 = "SELECT tamanho FROM produto where genero='Masculino'";
      $linhas1=mysqli_query($conexao, $consulta1);
      if(mysqli_num_rows($linhas1) > 0){
        while ($dados1=mysqli_fetch_array($linhas1)){
          // $marca = $_POST['marca'];
          echo "<div class='radio'><label><input type='radio' name='marca'>".$dados1['tamanho']."</label></div>";
        }
      }
      ?>




      <h3>Tipo</h3>
      <div class="radio"><label><input type="radio" name="tipo">Tênis</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Sapato</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Chinelo</label></div>


      <h3>Valor</h3>
      <div class="radio"><label><input type="radio" name="valor">Menos de R$ 50</label></div>
      <div class="radio"><label><input type="radio" name="valor">R$ 50 - R$ 100</label></div>
      <div class="radio"><label><input type="radio" name="valor">R$ 100 - R$ 200</label></div>
      <div class="radio"><label><input type="radio" name="valor">Acima de R$ 200</label></div>

      <h3>Marca</h3>

          <?php
          $marca="";
          $consulta1 = "SELECT marca FROM produto  where genero='Masculino'";
          $linhas1=mysqli_query($conexao, $consulta1);
          if(mysqli_num_rows($linhas1) > 0){
            while ($dados1=mysqli_fetch_array($linhas1)){
              // $marca = $_POST['marca'];
              echo "<div class='radio'><label><input type='radio' name='marca'>".$dados1['marca']."</label></div>";
            }
          }
          ?>

          <input type="submit" name="aplicar" value="Aplicar">

    </form>
  </div>


  <div id="filtroF">
    <form class="" action="#" id="filtro" method="post">
      <h3>Tamanho</h3>
      <?php
      $marca="";
      $consulta1 = "SELECT tamanho FROM produto where genero='Feminino'";
      $linhas1=mysqli_query($conexao, $consulta1);
      if(mysqli_num_rows($linhas1) > 0){
        while ($dados1=mysqli_fetch_array($linhas1)){
          // $marca = $_POST['marca'];
          echo "<div class='radio'><label><input type='radio' name='marca'>".$dados1['tamanho']."</label></div>";
        }
      }
      ?>


      <h3>Tipo</h3>
      <div class="radio"><label><input type="radio" name="tipo">Tênis</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Bota</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Sandália</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Salto</label></div>

      <h3>Valor</h3>
      <div class="radio"><label><input type="radio" name="valor">Menos de R$ 50</label></div>
      <div class="radio"><label><input type="radio" name="valor">R$ 50 - R$ 100</label></div>
      <div class="radio"><label><input type="radio" name="valor">R$ 100 - R$ 200</label></div>
      <div class="radio"><label><input type="radio" name="valor">Acima de R$ 200</label></div>

      <h3>Marca</h3>

          <?php
          $marca="";
          $consulta1 = "SELECT marca FROM produto where genero='Feminino'";
          $linhas1=mysqli_query($conexao, $consulta1);
          if(mysqli_num_rows($linhas1) > 0){
            while ($dados1=mysqli_fetch_array($linhas1)){
              // $marca = $_POST['marca'];
              echo "<div class='radio'><label><input type='radio' name='marca'>".$dados1['marca']."</label></div>";
            }
          }
          ?>

          <input type="submit" name="filtrar" value="Filtrar">

    </form>
  </div>

  <div id="filtroI">
    <form class="" action="#" id="filtro" method="post">
      <h3>Tamanho</h3>
      <?php
      $marca="";
      $consulta1 = "SELECT tamanho FROM produto where genero='Infantil'";
      $linhas1=mysqli_query($conexao, $consulta1);
      if(mysqli_num_rows($linhas1) > 0){
        while ($dados1=mysqli_fetch_array($linhas1)){
          // $marca = $_POST['marca'];
          echo "<div class='radio'><label><input type='radio' name='marca'>".$dados1['tamanho']."</label></div>";
        }
      }
      ?>


      <h3>Tipo</h3>
      <div class="radio"><label><input type="radio" name="tipo">Tênis</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Bota</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Sandália</label></div>
      <div class="radio"><label><input type="radio" name="tipo">Salto</label></div>

      <h3>Valor</h3>
      <div class="radio"><label><input type="radio" name="valor">Menos de R$ 50</label></div>
      <div class="radio"><label><input type="radio" name="valor">R$ 50 - R$ 100</label></div>
      <div class="radio"><label><input type="radio" name="valor">R$ 100 - R$ 200</label></div>
      <div class="radio"><label><input type="radio" name="valor">Acima de R$ 200</label></div>

      <h3>Marca</h3>

          <?php
          $marca="";
          $consulta1 = "SELECT marca FROM produto where genero='Infantil'";
          $linhas1=mysqli_query($conexao, $consulta1);
          if(mysqli_num_rows($linhas1) > 0){
            while ($dados1=mysqli_fetch_array($linhas1)){
              // $marca = $_POST['marca'];
              echo "<div class='radio'><label><input type='radio' name='marca'>".$dados1['marca']."</label></div>";
            }
          }
          ?>

          <input type="submit" name="filtrar" value="Filtrar">

    </form>
  </div>


  <div class="produtos">
    <div class="div">1</div>
    <div class="div">2</div>
    <div class="div">3</div>
    <div class="div">4</div>
    <div class="div">5</div>
    <div class="div">6</div>
    <div class="div">7</div>
    <div class="div">8</div>
    <div class="div">9</div>
    <div class="div">1</div>
    <div class="div">2</div>
    <div class="div">3</div>
    <div class="div">4</div>
    <div class="div">5</div>
    <div class="div">6</div>
    <div class="div">7</div>
    <div class="div">8</div>
    <div class="div">9</div>

  </div>

<div class="home">

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="img/1.jpg" alt="Chania">
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>LA is always so much fun!</p>
      </div>
    </div>

    <div class="item">
      <img src="img/2.jpg" alt="Chicago">
      <div class="carousel-caption">
        <h3>Chicago</h3>
        <p>Thank you, Chicago!</p>
      </div>
    </div>

    <div class="item">
      <img src="img/3.jpg" alt="New York">
      <div class="carousel-caption">
        <h3>New York</h3>
        <p>We love the Big Apple!</p>
      </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div class="div">1</div>
<div class="div">2</div>
<div class="div">3</div>
</div>

<script type="text/javascript" src="boot/jquery.min.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
  jQuery('#filtro').submit(function(){
    var dados = jQuery( this ).serialize();

    jQuery.ajax({
      type: "POST",
      url: "teste.php",
      data: dados,
      success: function( data )
      {
        $('.t').fadeOut();
        // alert( data );
      }
    });

    return false;
  });
});
</script>

  <!-- <button type="button" name="" class="a" value=""></button>
  <div id="div1" style="width:80px;height:80px;background-color:red;"></div><br> -->

  <script type="text/javascript">


  $(document).ready(function(){
      $("#home").click(function(){
          $("#filtroM").hide();
          $("#filtroF").hide();
          $(".produtos").hide();
          $("#filtroF").hide();
          $("#filtroI").hide();
          $(".home").show();
          $(".promocoes").hide();

      });
  });

//esconder geral
  $(document).ready(function(){
    $("#filtroF").hide();
    $("#filtroM").hide();
    $(".produtos").hide();
    $("#filtroI").hide();
    $(".promocoes").hide();

  });
  //click masculino
  $(document).ready(function(){
      $("#masculino").click(function(){
          $("#filtroM").show();
          $(".produtos").show();
          $("#filtroF").hide();
          $("#filtroI").hide();
          $(".home").hide();
          $(".promocoes").hide();
        });
      });

//click feminino
  $(document).ready(function(){
      $("#feminino").click(function(){
        $("#filtroF").show();
        $(".produtos").show();
          $("#filtroM").hide();
          $("#filtroI").hide();
          $(".home").hide();
          $(".promocoes").hide();
        });
      });
    //click infantil
        $(document).ready(function(){
            $("#infantil").click(function(){
              $("#filtroI").show();
              $(".produtos").show();
                $("#filtroM").hide();
                $("#filtroF").hide();
                $(".home").hide();
                $(".promocoes").hide();

              });
            });
            //click promocoes
                $(document).ready(function(){
                    $("#promocoes").click(function(){
                      $("#filtroI").hide();
                      $(".produtos").hide();
                        $("#filtroM").hide();
                        $("#filtroF").hide();
                        $(".home").hide();

                      });
                    });


      // $(document).ready(function(){
      //     $(".filtrar").submit(function(){
      //         $("#home").hide();
      //         $("#filtroF").show();
      //         $(".produtos").show();
      //       });
      //     });


  </script>


</body>


<!-- <label class="checkbox-inline"><input type="radio" name="tam" value="33">33</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="34">34</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="35">35</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="36">36</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="37">37</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="38">38</label><br>
<label class="checkbox-inline"><input type="radio" name="tam" value="39">39</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="40">40</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="41">41</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="42">42</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="43">43</label>
<label class="checkbox-inline"><input type="radio" name="tam" value="44">44</label> -->


<style>
.carousel{
  /* border: 1px solid black; */
  height: 50%;
}
.carousel-control.right {
  background-image: -webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.0000)),to(rgba(0,0,0,.0))); */
}
.carousel-control.left {
  background-image: -webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.0000)),to(rgba(0,0,0,.0))); */
}

a:hover{
  cursor: pointer;
}
.navbar-inverse .navbar-nav>li>a{
  color: white;
}
div.scrollmenu {
  color: black;
  font-family: "Courier New";
  font-size: 100%;
  text-align: center;
    background-color: #E0E0E0;
    overflow: auto;
    white-space: nowrap;
}

div.scrollmenu a {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px;
    text-decoration: none;
}

div.scrollmenu a:hover {
    background-color:#BDBDBD;
}
</style>
<style media="screen">
html,body{
  width: 100%;
  height: 100%;
}
.nav>li {
    position: relative;
    display: block;
    font-size: 25;
    /* font-family: "Courier New"; */
    margin-left: 40;
    margin-top: 50;
    font-weight: 500;
    /* color: white; */
}
.login{
  height: 100%;
  width: 20%;
  background-color: pink;
  float: right;
}
.div{
  width: 25%;
  margin-left: 5%;
  margin-top: 2%;
  height: 25%;
  border: 1px solid red;
  position: relative;
  float: left;


}
.navbar {
    border-radius: 0;
}
.navbar-inverse{
  height: 15%;
  background-color: #e41010;
  border-color: #e41010;
}
.sexo{
  height: 10%;
  /* background-color: red; */
  position: relative;
}

#filtroM{
  width: 20%;
  height: 100%;
  /* background-color: black; */
  /* border:1px; */

  position: relative;
  float: left;
}
#filtroF{
  width: 20%;
  height: 100%;
  /* background-color: black; */
  /* border:1px; */
  position: relative;
  float: left;
}
#filtroI{
  width: 20%;
  height: 100%;
  /* background-color: black; */
  /* border:1px; */
  position: relative;
  float: left;
}

.produtos{
  width: 80%;
  height: 100%;
  /* background-color: green; */
  margin-left: 20%;
  position: relative;
}
.masc{
  width: 50%;
  height: 100%;
  background-color: #E0E0E0;
  position: relative;
  float: left;

}
.femi{
  width: 50%;
  height: 100%;
  background-color: #E0E0E0;
  position: relative;
  float: right;


}
.masc:hover{
  background-color: #BDBDBD;
}
.femi:hover{
  background-color: #BDBDBD;
}
.home{
  width: 100%;
  height: 100%;
  /* background-color: black; */
}


</style>
</html>
