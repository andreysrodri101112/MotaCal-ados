<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
</head>


<!-- <div class="cad">
  <form class="" action="adm.php" method="post"><br>
    <!-- Código:<input type="number" name="codigo" value=""><br> -->
    <!-- Referencia:<input type="number" name="ref" value=""><br>
    Marca:<input type="text" name="marca" value=""><br>
    Tamanho:<input type="number" name="tamanho" value=""><br>
    Cor:<input type="text" name="cor" value=""><br>
    Gênero:<input type="radio" name="genero" value="Masculino">Masculino
    <input type="radio" name="genero" value="Feminino">Feminino<br>
    Quantidade:<input type="number" name="quantidade" value=""><br>
    Valor:<input type="number" name="valor" value=""><br>
    <input type="submit" name="cadastrar" value="Cadastrar">
  </form>
</div> -->

<div class="botaotodos">
  <form class="" action="adm.php" method="post">
    <button type="submit" class="btn btn-default" name="todos">Todos</button>

  </form>
</div>


<div class="container">
  <form action="adm.php" method="post">
    <div class="form-group">
      <label for="ref">Referencia:</label>
      <input type="number" class="form-control" name="ref">
    </div>
    <div class="form-group">
      <label for="marca">Marca:</label>
      <input type="text" class="form-control" name="marca">
    </div>
    <div class="form-group">
      <label for="t">Tamanho:</label>
      <input type="number" class="form-control" name="tamanho">
    </div>
    <div class="form-group">
      <label for="c">Cor:</label>
      <input type="text" class="form-control" name="cor">
    </div>
    <div class="form-group">
      <label for="g">Gênero:</label><br>
      Masculino:<input type="radio" class="form-control" name="genero">
      Feminino:<input type="radio" class="form-control" name="genero">
    </div>
    <div class="form-group">
      <label for="q">Quantidade:</label>
      <input type="number" class="form-control" name="quantidade">
    </div>
    <div class="form-group">
      <label for="v">Valor:</label>
      <input type="number" class="form-control" name="valor">
    </div>

    <button type="submit" class="btn btn-default" name="cadastrar">Salvar</button>
  </form>
</div>
<!--
<table class="table table-bordered">
  <thead>
    <tr class="corlinha">
      <th scope="col">#</th>
      <th scope="col">Primeiro</th>
      <th scope="col">Último</th>
      <th scope="col">Nickname</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
  </tbody>
</table> -->

<body>
<style media="screen">

.table{
  width: 50%;
  margin-left: 35%;

  position: absolute;
  top:25%;
}
.corlinha{
  background-color: #D32F2F;
}
.container{
  width: 25%;
  height: 60%;
  margin-left: 5%;
  margin-top: 2%;
}
.btn-default{
  background-color: #D32F2F;
}



.cad{
    /* border: 2px solid black; */
  }
  .nomes{
    font-size: 120%;
    font-weight: bold;
  }
  .todos{
      width: 30.5%;
      height: 40%;
      left: 50%;

      /* border: 2px solid black; */
      position: absolute;
      top: 40%;
  }
.botaotodos{
  width: 10%;
  height: 5%;
  position: absolute;
  left: 90%;
  top: 10%;

  /* border: 2px solid black; */

}
  .campos{
    width: 15%;
    height: 3%;
    position: absolute;
    left: 50%;
    top: 0%;
    /* border: 2px solid black; */

}

  /* .buscas{
    width: 40%;
    height: 60%;

    border: 2px solid black;

  } */
</style>

  <?php

  $conexao = mysqli_connect("localhost","root","","tcc");
  if (!$conexao) {
    die("Erro".mysql_error());

  }

  $cont=0;
  if (isset($_POST['cadastrar'])) {
    $erro=0;
    $ref = $_POST['ref'];
    $marca = $_POST['marca'];
    $valor = $_POST['valor'];
    // $codigo = $_POST['codigo'];
    $tamanho = $_POST['tamanho'];
    $genero = $_POST['genero'];
    $cor =  $_POST['cor'];
    $q =  $_POST['quantidade'];

    if (!isset($_POST['ref']) || $_POST['ref']=="") {
      ++$erro;
    }
    if (!isset($_POST['marca']) || $_POST['marca']=="") {
      ++$erro;
    }
    if (!isset($_POST['tamanho']) || $_POST['tamanho']=="") {
      ++$erro;
    }
    // if (!isset($_POST['codigo']) || $_POST['codigo']=="") {
    //   ++$erro;
    // }
    if (!isset($_POST['genero']) || $_POST['genero']=="") {
      ++$erro;
    }
    if (!isset($_POST['valor']) || $_POST['valor']=="") {
      ++$erro;
    }
    if (!isset($_POST['cor']) || $_POST['cor']=="") {
      ++$erro;
    }
    if (!isset($_POST['quantidade']) || $_POST['quantidade']=="") {
      ++$erro;
    }

    $corteste=0;
    if ($cor=="azul") {
      $corteste=1;
    }



    // $codigo = $ref.$tamanho;

    // echo "$codigo";




    if ($erro==0) {

      // for ($i=0; $i < $q; $i++) {
      //   $cont = $cont + 1;
        $codigo = $ref.$tamanho.$corteste.$valor.$cont;
        // echo "$codigo<br>";
        date_default_timezone_set('America/Sao_paulo');
        $data = date('Y-m-d H:i:s');
        $dataa = date('Y-m-d ');
      $query = "INSERT INTO `produto`(`codigo`,`referencia`, `marca`,`tamanho`,`cor`,`genero`,`valor`,`quantidade`,`data_entrada`) VALUES('$codigo','$ref','$marca','$tamanho','$cor','$genero','$valor','$q','$data')";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";

      }else {
        echo "$query";
      // echo "<script>";
      // echo  "alert('Algum(ns) dos campos não foi(ram) preenchido(s). Tente novamnete!')";
      // echo "</script>";

    }
  }
// }

}

  if (isset($_POST['todos'])) {

    $consulta = "SELECT * FROM produto";
    $linhas=mysqli_query($conexao, $consulta);
    if(mysqli_affected_rows($conexao) > 0){

    echo "<table class='table table-bordered'>";
    echo "<tr class='corlinha' class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Quantidade</td><td>Valor</td><td>Data de Entrada</td><td>#</td></tr>";
      while ($dados=mysqli_fetch_array($linhas)){
        $cod=$dados['codigo'];
        echo "<tr><td>".$dados['codigo']."</td>";
        echo "<td>".$dados['referencia']."</td>";
        echo "<td>".$dados['marca']."</td>";
        echo "<td>".$dados['tamanho']."</td>";
        echo "<td>".$dados['cor']."</td>";
        echo "<td>".$dados['genero']."</td>";
        echo "<td>".$dados['quantidade']."</td>";
        echo "<td>".$dados['valor']."</td>";
        echo "<td>".$dados['data_entrada']."</td>";

        // echo "<form action='site.php' method='post'>";
        // echo "<td><button type='submit' name='excluir' class='excluir' id='$cod'>X</button><td></tr>";
        echo "<form action='adm.php' method='post'>";
        echo "<input type='hidden' name='id' value='$cod'>
        <td><input type='submit' name='deletar' value='X' /></td></tr>";
        echo "</form>";
        //  header("Location: site.php");


      }
    }
      echo "</table>";

  }

  //
  // if (isset($_POST['btncod'])) {
  //   $campocod = $_POST['campocod'];
  //   echo "$campocod";
  //   $consulta = "SELECT * FROM produto where codigo=$campocod";
  //   $linhas=mysqli_query($conexao, $consulta);
  //   if(mysqli_affected_rows($conexao) > 0){
  //
  //   echo "<div class='todos'><table border=1>";
  //   echo "<tr class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Valor</td></tr>";
  //     while ($dados=mysqli_fetch_array($linhas)){
  //       // $cod=$dados['codigo'];
  //       echo "<tr><td>".$dados['codigo']."</td>";
  //       echo "<td>".$dados['ref']."</td>";
  //       echo "<td>".$dados['marca']."</td>";
  //       echo "<td>".$dados['tamanho']."</td>";
  //       echo "<td>".$dados['cor']."</td>";
  //       echo "<td>".$dados['genero']."</td>";
  //       echo "<td>".$dados['valor']."</td></tr>";
  //     }
  //     echo "</table></div>";
  //
  //   }
  // }



  // if (isset($_POST['btnnome'])) {
  //     $camponome = $_POST['camponome'];
  //     $consulta = "SELECT * FROM produto where nome='$camponome'";
  //     $linhas=mysqli_query($conexao, $consulta);
  //     if(mysqli_affected_rows($conexao) > 0){
  //     echo "<div class='todos'><table border=1>";
  //     echo "<tr class='nomes'><td>Código</td><td>Nome</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Valor</td></tr>";
  //       while ($dados=mysqli_fetch_array($linhas)){
  //         // $cod=$dados['nome'];
  //         echo "<tr><td>".$dados['codigo']."</td>";
  //         echo "<td>".$dados['nome']."</td>";
  //         echo "<td>".$dados['marca']."</td>";
  //         echo "<td>".$dados['tamanho']."</td>";
  //         echo "<td>".$dados['cor']."</td>";
  //         echo "<td>".$dados['genero']."</td>";
  //         echo "<td>".$dados['valor']."</td></tr>";
  //       }
  //       echo "</table></div>";
  //     }
  //   }

  // if (isset($_POST['btnmarca'])) {
  //   $campomarca = $_POST['campomarca'];
  //   echo "$campomarca";
  //   $consulta = "SELECT * FROM produto where marca='$campomarca'";
  //   $linhas=mysqli_query($conexao, $consulta);
  //   if(mysqli_affected_rows($conexao) > 0){
  //
  //   echo "<div class='todos'><table border=1>";
  //   echo "<tr class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Valor</td></tr>";
  //     while ($dados=mysqli_fetch_array($linhas)){
  //       // $cod=$dados['codigo'];
  //       echo "<tr><td>".$dados['codigo']."</td>";
  //       echo "<td>".$dados['ref']."</td>";
  //       echo "<td>".$dados['marca']."</td>";
  //       echo "<td>".$dados['tamanho']."</td>";
  //       echo "<td>".$dados['cor']."</td>";
  //       echo "<td>".$dados['genero']."</td>";
  //       echo "<td>".$dados['valor']."</td></tr>";
  //     }
  //     echo "</table></div>";
  //
  //   }
  // }
  //
  // if (isset($_POST['btntamanho'])) {
  //   $campotamanho = $_POST['campotamanho'];
  //   echo "$campotamanho";
  //   $consulta = "SELECT * FROM produto where tamanho=$campotamanho";
  //   $linhas=mysqli_query($conexao, $consulta);
  //   if(mysqli_affected_rows($conexao) > 0){
  //
  //   echo "<div class='todos'><table border=1>";
  //   echo "<tr class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Valor</td></tr>";
  //     while ($dados=mysqli_fetch_array($linhas)){
  //       // $cod=$dados['codigo'];
  //       echo "<tr><td>".$dados['codigo']."</td>";
  //       echo "<td>".$dados['ref']."</td>";
  //       echo "<td>".$dados['marca']."</td>";
  //       echo "<td>".$dados['tamanho']."</td>";
  //       echo "<td>".$dados['cor']."</td>";
  //       echo "<td>".$dados['genero']."</td>";
  //       echo "<td>".$dados['valor']."</td></tr>";
  //     }
  //     echo "</table></div>";
  //
  //   }
  // }



  ?>
</body>
</html>
