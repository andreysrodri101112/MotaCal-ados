<?php
session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="adm") {
    $sessao = "Admnistrador";
  }elseif ($_SESSION['username']=="funcionario") {
    header("Location: listagemfuncionario.php");
  }
  // echo $sessao;
}else {
  header("Location: index.php");
}


// if (isset($_POST['logout'])) {
//   header("Location:index.php");
// }

?>
<?php
// session_start();
// if (isset($_SESSION['username'])) {
//   echo $_SESSION['username'];
// }else {
// echo "nao deu nada";
// }

$conexao = mysqli_connect("localhost","root","","tcc");
if (!$conexao) {
  die("Erro".mysql_error());
}

$soma=0;

if (isset($_POST['add'])) {
  $produto = $_POST['codigo'];
  $quant = $_POST['quant'];
  // echo "string".$_POST['op'];


  $produto = $_POST['codigo'];
  $consulta = "SELECT codigo,quantidade FROM produto where codigo=$produto";
  $linhas=mysqli_query($conexao, $consulta);
  mysqli_num_rows($linhas);
  $dados=mysqli_fetch_array($linhas);
  if ($dados['quantidade']<=0 || $dados['codigo']==""){
    // echo "<script>alert('Produto Indisponível')</script>";
    echo "<div class='divErro'>
    <p>Produto Indisponível</p>
    <div id='x'>X</div>
    </div>";

  }else {



    date_default_timezone_set('America/Sao_paulo');
    $data = date('Y-m-d H:i:s');
    $dataa = date('Y-m-d ');


    //verifica se nao tem mais produtos no pedido no que no estoque

    //pega o ultimo pedido da lista
    $consulta13 = "SELECT cod_pedido FROM pedido ORDER BY cod_pedido DESC LIMIT 1";
    $linhas13=mysqli_query($conexao, $consulta13);
    mysqli_num_rows($linhas13);
    $dados13=mysqli_fetch_array($linhas13);
    $ultimo = $dados13['cod_pedido'];
    //seleciona a quantidade de produtos daquele codigo no estoque
    $consulta11 = "SELECT quantidade FROM produto where codigo=$produto";
    $linhas11=mysqli_query($conexao, $consulta11);
    mysqli_num_rows($linhas11);
    $dados11=mysqli_fetch_array($linhas11);
    $quant_estoque = $dados11['quantidade'];
    //verificar se o where e com codigo produto ou pedido
    $consulta12 = "SELECT SUM(quant_pedido) as totpedido FROM pedido_produto where cod_pedido=$ultimo and cod_produto=$produto";
    // echo "$consulta12<br>";
    $linhas12=mysqli_query($conexao, $consulta12);
    mysqli_num_rows($linhas12);
    $dados12=mysqli_fetch_array($linhas12);
    $quant_adicionada=$dados12['totpedido'];
    //verifica a condição e so adiciona se nao for maior



    $limite = $quant_adicionada+$quant;

    if ($limite>$quant_estoque || $quant>$quant_estoque) {
      $quant=$quant_estoque;

      echo "<div class='divErro'>
      <p>Quantidade de produtos excedida!</p>
      <div id='x'>X</div>
      </div>";
      // echo "<script>alert('Quantidade de produtos excedida!')</script>";

    }else {

      //teste de quantidade
      // echo "produtos adicionados no pedido:". $quant_adicionada."<br>produtos no estoque: $quant_estoque<br>quan solic: $quant<br>";
      // $quant_pedido = $dados12['totpedido'];
      // echo $dados12['totpedido'];

      $query = "INSERT INTO pedido_produto (cod_pedido,cod_produto,data_pedido,quant_pedido,valor_pedido,pagamento) VALUES ('".$dados13['cod_pedido']."','".$dados['codigo']."','$data','$quant','0','0')";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";
        echo "$query";
      }


    }//else excedidos




  }

}

//listagem dos pedidos que estao sendoa adicionados
$consulta1 = "SELECT cod_pedido FROM pedido ORDER BY cod_pedido DESC LIMIT 1";
$linhas1=mysqli_query($conexao, $consulta1);
if(mysqli_num_rows($linhas1) > 0){
  while ($dados1=mysqli_fetch_array($linhas1)){
    $ultimo = $dados1['cod_pedido'];
    // echo "$ultimo";


    $consulta3 = "SELECT sum(quant_pedido) as tot, quant_pedido,produto.* from pedido_produto,produto
    where produto.codigo=pedido_produto.cod_produto and cod_pedido=$ultimo group by cod_produto";
    echo "<table class='table table-bordered'>";
    echo "<tr class='corlinha' class='nomes'><td>Código</td><td>Referencia</td><td>Marca</td><td>Tamanho</td><td>Cor</td><td>Gênero</td><td>Tipo</td><td>Valor</td><td>Data de Entrada</td><td class='quant'>Quantidade</td></tr>";
    $linhas3=mysqli_query($conexao, $consulta3);
    if(mysqli_num_rows($linhas3) > 0){
      while ($dadosmf=mysqli_fetch_array($linhas3)){


        echo "<tr><td>".$dadosmf['codigo']."</td>";
        echo "<td>".$dadosmf['referencia']."</td>";
        echo "<td>".$dadosmf['marca']."</td>";
        echo "<td>".$dadosmf['tamanho']."</td>";
        echo "<td>".$dadosmf['cor']."</td>";
        echo "<td>".$dadosmf['genero']."</td>";
        echo "<td>".$dadosmf['tipo']."</td>";
        echo "<td>".$dadosmf['valor']."</td>";
        echo "<td>".$dadosmf['data_entrada']."</td>";
        echo "<td >".$dadosmf['tot']."</td>";
        echo "</tr>";


      }
    }


  }
}





if (isset($_POST['f'])) {


  $consultt = "SELECT SUM(produto.valor * pedido_produto.quant_pedido) AS total FROM pedido_produto LEFT JOIN produto
  ON pedido_produto.cod_produto = produto.codigo WHERE cod_pedido=$ultimo";

  $linhastt=mysqli_query($conexao, $consultt);
  mysqli_num_rows($linhastt);
  $dadostt=mysqli_fetch_array($linhastt);
  $total = $dadostt['total'];

  // echo "Valor Total:".$dadostt['total'];

  $query = "UPDATE pedido_produto SET valor_pedido=$total  where cod_pedido=$ultimo";
  if (!mysqli_query($conexao, $query)) {
    echo "erro ao inserir".$query."<br><br><br>";
    echo "code: | ".mysqli_errno($conexao)." |";
  }


  $op = $_POST['op'];
  if ($_POST['op']=="") {
    echo "<script>alert('Escolha uma opção de pagamento!')</script>";
  }else {

    if ($_POST['op']=="Credito") {
      $query = "UPDATE pedido_produto SET pagamento='$op' where cod_pedido=$ultimo";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";
      }
    }else{
      $query = "UPDATE pedido_produto SET pagamento='$op' where cod_pedido=$ultimo";
      if (!mysqli_query($conexao, $query)) {
        echo "erro ao inserir".$query."<br><br><br>";
        echo "code: | ".mysqli_errno($conexao)." |";
      }
    }

    $consult = "SELECT cod_produto,SUM(quant_pedido)AS total_produto FROM pedido_produto where cod_pedido=$ultimo AND cod_produto GROUP BY cod_produto";
    $linhast=mysqli_query($conexao, $consult);
    if(mysqli_num_rows($linhast)>0){
      while($dadost=mysqli_fetch_array($linhast)){
        $tot= $dadost['total_produto'];


        // CORRIGIR
        // SE FICAR RECARREGANDO A PAGINA ELE CONTINUA SETANDO, TEM QUE FAZER ELE PARAR DEPOIS QUE FINALIZAR O PEDIDO
        $consult = "UPDATE produto SET quantidade=quantidade-" . $tot . " where codigo=" . $dadost['cod_produto'];
        if (!mysqli_query($conexao, $consult)) {
          echo "erro ao inserir".$consult."<br><br><br>";
          echo "code: | ".mysqli_errno($conexao)." |";
        }else {
          // echo "setou";
        }

      }
    }
    if ($_SESSION['username']=="funcionario") {
      // echo $_SESSION['username'];
      header("Location:listagemFuncionario.php");
    }elseif ($_SESSION['username']=="adm") {
      header("Location:listaPedidos.php");
    }
  } //chave else
} //chave finalizar







if (isset($_POST['cancelar'])) {
?>
<?php
// exit;
// echo "a";

$consult = "DELETE FROM pedido_produto WHERE cod_pedido=$ultimo";
if (!mysqli_query($conexao, $consult)) {
  echo "erro ao inserir".$consult."<br><br><br>";
  echo "code: | ".mysqli_errno($conexao)." |";
}else {
  // echo "EXCLUIU";
  if ($_SESSION['username']=="funcionario") {
    // echo $_SESSION['username'];
    header("Location:listagemFuncionario.php");
  }elseif ($_SESSION['username']=="adm") {
    header("Location:listaPedidosNovo.php");
  }

}


if (isset($_POST['nao'])) {
  echo "nao";
}


}
?>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="//assets.locaweb.com.br/locastyle/2.0.6/stylesheets/locastyle.css">
<link rel="stylesheet" type="text/css" href="//assets.locaweb.com.br/locastyle/edge/stylesheets/locastyle.css">
<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/edge/javascripts/locastyle.js"></script>
</head>

<body>


</form>
<div class="add">


  <form>

  </form>





<form action="#" method="post" id="teste">


  <span class="fontes">Código:</span>
  <select name="codigo" class="ls-select" id="codigos">
    <option value=""></option>
    <?php
    $consult = "SELECT codigo FROM produto";
    $linhast=mysqli_query($conexao, $consult);
    if(mysqli_num_rows($linhast)>0){
      while($dadost=mysqli_fetch_array($linhast)){
        $cod=$dadost['codigo'] ;
        echo "<option value='$cod'>".$cod."</option>";
    }
  }
    ?>
  </select>

  <span class="fontes">Quantidade:</span>
  <select name="quant" id="quant" class="ls-select" class="pedido">
  </select>

<script type="text/javascript">
  $('#codigos').on("change",function(){
    var idCodigo = $('#codigos').val();
    // alert(idCodigo);
    // $("#quant").html(idCodigo);
    $.ajax({
      type: "GET", //método escolhido
      url: "busca_quant.php?cod="+idCodigo, //arquivo php chamado
      // data: {cod: idCodigo},
      dataType: "html",//tipo de função a ser retornada
      beforeSend: function(){
        $("#bt").text("Carregando...");
      },
      error: function(){
        $("#div").html("Erro ao carregar HTML! Tente de novo!");
      },
      success: function(html){
        $("#quant").html(html);

      }
    });

  });
</script>

    <?php
    // if (isset($_POST['s'])) {

  //   $consult = "SELECT quantidade FROM produto where codigo=".$_POST['codigo'];
  //   $linhast=mysqli_query($conexao, $consult);
  //   if(mysqli_num_rows($linhast)>0){
  //     while($dadost=mysqli_fetch_array($linhast)){
  //       if ($dadost['quantidade']<=0) {
  //             echo "<option value='0'>0</option>";
  //       }
  //         for ($i=1; $i < $dadost['quantidade']+1; $i++) {
  //           echo "<option value='$i'>$i</option>";
  //         }
  //
  //   }
  // }
// }
    ?>

  <button type="submit" class="btn btn-default" name="add">Adicionar</button>

</div>

</form>






<form class="" action="#" method="post">

  <div class="finalizar">



    <!-- <div class="maxl"> -->
      <label class="radio inline">
        <input type="radio" name="op" value="dinheiro" checked>
        <span> Dinheiro </span>
      </label>
      <label class="radio inline">
        <input type="radio" name="op" value="debito">
        <span>Débito</span>
      </label>
      <label class="radio inline">
        <input type="radio" name="op" value="credito">
        <span>Crédito </span>
      </label>
    <!-- </div> -->

    <div class="total">
      <?php
      $consultsoma = "SELECT SUM(produto.valor * pedido_produto.quant_pedido) AS somatotal FROM pedido_produto LEFT JOIN produto
ON pedido_produto.cod_produto = produto.codigo WHERE cod_pedido=$ultimo";

      $linhasoma=mysqli_query($conexao, $consultsoma);
      mysqli_num_rows($linhasoma);
        $dadosoma=mysqli_fetch_array($linhasoma);
          $somatotal= $dadosoma['somatotal'];

      echo "Valor Total:".$somatotal;



      // botarb o total position absolute e o finalizar relative
      ?>
    </div>
  </div>


  <button type="submit" class="btn btn-defaultf" name="f">Finalizar</button>
</form>
<button type="button" class="btn btn-primaryy" data-toggle="modal" data-target="#exampleModalCenter">
Cancelar Pedido</button>

<form class="" action="#" method="post">
<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Cancelar Pedido</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Você confirma o cancelamento do pedido?
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-secondary" name="cancelar" >Sim</button>
        <button type="submit" class="btn btn-secondary" name="nao" data-dismiss="modal">Não</button>

      </div>
    </div>
  </div>
</div>
</form>
<!-- <form class="" action="#" method="post">
  <button name="cancelar" type="submit" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
    Cancelar Pedido
  </button></form> -->


<style media="screen">
.total{
  /* background-color: red; */
  width: 40px;
  /* height: 40px; */
}
</style>

<?php

?>




<script type="text/javascript">

if ( $( ".divErro" ).is( ":hidden" ) ) {
  $( ".divErro" ).slideDown(1000);
}
else {
  $( "#divErro" ).hide();
}



$('#x').click(function(){
  if ( $(".divErro").slideUp(1000)) {

  }
  return true;
});
</script>

<style media="screen">

.divErro{

  background-color: white;
  position: absolute;
  top: 0;
  left: 25%;
  width: 50%;
  height: 15%;

  border-top: 0;

  border-color: #bdc3c7;;
  border-style: solid;


  /* display: none; */
  /*visibility: hidden;*/
  border-radius: 0 0 8px 8px ;

}
#x{
  position: absolute;
  right: 2%;
  top: 5%;
  color: #7f8c8d;
}
#x:hover{
  cursor: pointer;
  color: black;

}
p{
  text-align: center;
  color:#bdc3c7;
  font-family: arial;
  font-weight: 500;
  /* position: relative;
  top: 35%; */


}
</style>

<style media="screen">
.quant{
  background-color: #00C853;

}
.total{
  font-size: 150%;
  font-weight: 600;
  width: 20%;
  height: 5%;
  /* background-color: red; */
  /* position: absolute;
  top: 27%;
  left: 55%; */
  color: #999;
  margin-left: 70%;
  margin-top: -2%;
}

.finalizar{
  margin-left: 18%;
  margin-top:4%;
  width: 50%;
  height: 10%;
  background-color:#ECEFF1;
  border-radius: 10px;
  /* text-align: center; */

}
.maxl{
  /* margin:25px ; */
}
.inline{
  display: inline-block;
}
.inline + .inline{
  margin-left:10px;
}
.radio{
  color:#999;
  font-size:15px;
  /* position:relative; */
  /* margin-left: 5%; */
  /* margin-top: 3%; */
}
.radio span{
  position:relative;
  padding-left:20px;
}
.radio span:after{
  content:'';
  width:15px;
  height:15px;
  border:3px solid;
  position:absolute;
  left:0;
  top:1px;
  border-radius:100%;
  -ms-border-radius:100%;
  -moz-border-radius:100%;
  -webkit-border-radius:100%;
  box-sizing:border-box;
  -ms-box-sizing:border-box;
  -moz-box-sizing:border-box;
  -webkit-box-sizing:border-box;
}
.radio input[type="radio"]{
  cursor: pointer;
  position:absolute;
  width:100%;
  height:100%;
  z-index: 1;
  opacity: 0;
  filter: alpha(opacity=0);
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"
}
.radio input[type="radio"]:checked + span{
  color: #D32F2F;
}
.radio input[type="radio"]:checked + span:before{
  content:'';
  width:5px;
  height:5px;
  position:absolute;
}
.table{
  width: 100%;
  margin-top: 5%;
  /* margin-left: 15%; */
  /* position: absolute; */
  /* top:40%; */
}
.corlinha{
  background-color: #D32F2F;
  color: black;
}

.btn-default{
  background-color: #00C853;
}
.btn-defaulta{
  background-color: #7f8c8d;
}
.btn-defaultf{
  margin-top: -5%;
  margin-left: 70%;
  height: 5%;
  width: 15%;
  background-color: #D32F2F;
  /* position: absolute;
  top:23.5%;
  left: 70%; */
}
.btn-primaryy{
  margin-top: -2%;
  margin-left: 70%;
  height: 5%;
  width: 15%;

  /* background-color: #D32F2F; */
  /* position: absolute;
  top:23.5%;
  left: 70%; */
}
.f{
}
.add{
  margin-left: 30%;
  margin-top: 5%;
}

</style>

<!--
<script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
<script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
 -->


</body>
</html>
