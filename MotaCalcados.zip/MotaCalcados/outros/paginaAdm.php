<!DOCTYPE html>
<html lang="en">
<head>
  <title>Mota Calçados</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#paginaAdm.php">Mota Calçados</a>
    </div>
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="paginaAdm.php">Home</a></li> -->
      <li><a href="cadastro.php">Cadastro</a></li>
      <li><a href="listagem.php">Produtos</a></li>
      <li><a href="listaPedidosNovo.php">Pedidos</a></li>
      <li><a href="financeiro.php">Financeiro</a></li>

      <!-- <li><a href="#">Page 3</a></li> -->
    </ul>
  </div>
  <form class="" action="#" method="post">
    <input type="submit" name="logout"  class="logout" value="Sair"/>

  </form>
</nav>







<style media="screen">

 .logout {
float: right;
}


</style>
<?php
if (isset($_POST['logout'])) {
  header("Location:index.php");
}

session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="adm") {
    $sessao = "Admnistrador";
  }
  echo $sessao;
}

?>

</body>
</html>
