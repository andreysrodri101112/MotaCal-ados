<div id="c7" class="containerTab" >
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  
  <br>
  <br>


        <form action="#" method="post">

          <div class="row">
            <div class="col-50">
              <label for="fname">Código</label>
              <select class="form-control" name="produto" style="height:75%;">
                <option value=""></option>
                <?php
                  $consulta = "SELECT P.CD_PRODUTO AS codigo
                  FROM TB_PRODUTO AS P
                  WHERE NOT EXISTS(SELECT CD_PRODUTO FROM TB_ENTRADA AS E WHERE E.CD_PRODUTO = P.CD_PRODUTO)
                  AND
                  NOT EXISTS(SELECT CD_PRODUTO FROM TB_ITEMVENDA AS I WHERE I.CD_PRODUTO = P.CD_PRODUTO)
                  ";
                  $linhas=mysqli_query($conexao, $consulta);
                  if(mysqli_num_rows($linhas) > 0){
                      while ($dados=mysqli_fetch_array($linhas)){
                        echo '<option value="'.$dados['codigo'].'">'.$dados['codigo'].'</option>';
                      }       
                  }  
                ?>
              </select>
            </div>
        </div> 
 

          <input type="submit" value="Excluir" class="btn"name="btnExcluirProduto" id="excluir">

    </form>
</div>


<?php

if(isset($_POST['btnExcluirProduto'])){

    $erro = 0;
    $vazio = 0;
    
    if($_POST['produto'] == ""){
        $vazio = 1;
    }

    if($vazio > 0){
        echo "<div class='divErro'>
        <p>Preencha todos os campos</p>
        <div id='x'>X</div>
        </div>";
    }else{
        $codigo = $_POST['produto'];
        
        

            
                $query = "DELETE FROM tb_produto where cd_produto=$codigo";
                    if (!mysqli_query($conexao, $query)) {
                        echo "erro ao deletar".$query."<br><br><br>";
                    }else{
                        echo "<div class='divErro'>
                        <p>Produto excluída com sucesso</p>
                        <div id='x'>X</div>
                        </div>";
                        echo "<meta HTTP-EQUIV='REFRESH' CONTENT='1';url='paginaExclusao.php' />";

                    }  
            
                
            }     
            
    

   
    }

?>    