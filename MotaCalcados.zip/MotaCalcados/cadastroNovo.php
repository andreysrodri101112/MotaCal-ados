
<?php

session_start();
if (isset($_SESSION['username'])) {
  if ($_SESSION['username']=="adm") {
    $sessao = "Administrador";
  }elseif ($_SESSION['username']=="func") {
    header("Location: listagemfuncionario.php");
  }
  // echo $sessao;
}else {
  header("Location: index.php");
}

if (isset($_POST['logout'])) {
  header("Location:index.php");
}
?>

<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/bootstrap.min.css">
  <script src="boot/jquery.min.js"></script>
  <script src="boot/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style/not/cadastroNovo.css">
  
  <script src="js/bootstrap-datepicker.js"></script>
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />

</head>



<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Mota Calçados</a>
    </div>
    <ul class="nav navbar-nav">
              <li  class="position"><a href="cadastroNovo.php">Cadastro</a></li>
              <li  ><a href="listagem.php">Estoque</a></li>
              <li><a href="vendas.php">Vendas</a></li>
              <li ><a href="financeiro.php">Financeiro</a></li>
              <li ><div class="dropdown">
                <button  class="dropbtn" style="background:none;color:black;">Configurações</button>
                <div id="myDropdown1" class="dropdown-content">
                  <a href="paginaEdicao.php">Editar</a>
                  <a href="paginaExclusao.php">Excluir</a>                  
                </div>
             
            </li>
    </ul>



    <div class="dropdown" style="float:right;">
      <?php
      echo "<button class='dropbtn'>$sessao</button>";
      ?>
      <div class="dropdown-content">
        <a href="logout.php">Sair</a>

      </div>
    </div>

  </div>

</nav>

            <script type="text/javascript">
            $(document).ready(function () {
              $('.datepicker').datepicker({
                format: 'dd/mm/yyyy',
                language: 'pt-BR'
              });
            });
            </script>
            <!-- <script>
  function formatar(mascara, documento){
    var i = documento.value.length;
    var saida = mascara.substring(0,1);
    var texto = mascara.substring(i);
  
    if (texto.substring(0,1) != saida){
              documento.value += texto.substring(0,1);
    }
  
  }
</script> -->

<!-- <div class="row" >
<div class="col-75">
<div class="container" > -->
<div class="column" onclick="openTab('c1');">
  Entrada
</div>
<div class="column" onclick="openTab('c2');">
  Referência
</div>
<div class="column" onclick="openTab('c3');" >
  Marca
</div>
<div class="column" onclick="openTab('c4');">
  Cor
</div>
<div class="column" onclick="openTab('c5');">
  Modelo
</div>
<div class="column" onclick="openTab('c6');" >
  Cliente
</div>
<div class="column" onclick="openTab('c7');">
  Produto
</div>
<!-- </div>
</div>
</div> -->
    <?php
        include_once("cadastroEntrada.php");

    ?>
<!-- --------------------------------------------------------------------------- -->
    <?php
        include_once("cadastroReferencia.php");

    ?>
<!-- --------------------------------------------------------------------------- -->
    <?php
        include_once("cadastroMarca.php");

    ?>

<!-- --------------------------------------------------------------------------- -->
    <?php
        include_once("cadastroCor.php");

    ?>

    <!-- --------------------------------------------------------------------------- -->

   <?php
        include_once("cadastroModelo.php");

    ?>

  <!-- --------------------------------------------------------------------------- -->

     <?php
        include_once("cadastroCliente.php");

    ?>
  <!-- ----------------------------------------------------------------------------- -->
            
  <?php
        include_once("cadastroProduto.php");

    ?>

<script>
function openTab(tabName) {
  var i, x;
  x = document.getElementsByClassName("containerTab");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  document.getElementById(tabName).style.display = "block";
}
</script>







<script type="text/javascript">

if ( $( ".divErro" ).is( ":hidden" ) ) {
  $( ".divErro" ).slideDown(1000);
}
else {
  $( "#divErro" ).hide();
}



$('#x').click(function(){
  if ( $(".divErro").slideUp(1000)) {

  }
  return true;
});
</script>



</body>
</html>
